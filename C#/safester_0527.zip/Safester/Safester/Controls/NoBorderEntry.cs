﻿using System;
using Xamarin.Forms;

namespace Safester.Controls
{
    public class RoundedBorderEntry : Entry
    {
        public RoundedBorderEntry()
        {
        }
    }
}
