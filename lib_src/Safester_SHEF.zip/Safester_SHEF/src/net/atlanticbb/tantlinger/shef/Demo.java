
package net.atlanticbb.tantlinger.shef;

import com.keyoti.rapidSpell.LanguageType;
import com.keyoti.rapidSpell.desktop.RapidSpellAsYouType;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.InputStream;
import java.util.Locale;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import net.atlanticbb.tantlinger.i18n.I18n;
import net.atlanticbb.tantlinger.io.IOUtils;

/**
 *
 * @author Bob Tantlinger
 */
public class Demo {

    
    public HTMLEditorPane editor = null;
    JFrame frame = new JFrame();

    private int language = LanguageType.ENGLISH;
    private String dictionaryPath = null;

   private static RapidSpellAsYouType rapidAYT = null;

    public Demo() {

        HTMLEditorPane.setLanguage("fr");
        
        if (editor == null)
        {
            editor = new HTMLEditorPane();

            /*
            // add a CSS rule to force body tags to use the default label font
            // instead of the value in javax.swing.text.html.default.csss
            Font font = UIManager.getFont("Label.font");
            
            String bodyRule = "body { font-family: " + font.getFamily() + "; " +
                    "font-size: " + font.getSize() + "pt; }";
            ((HTMLDocument)editor.getEditor().getDocument()).getStyleSheet().addRule(bodyRule);
            */
        }
        
        Font font = UIManager.getFont("Label.font");
        System.out.println("font.getName(): " + font.getName());
        System.out.println("font.getSize(): " + font.getSize());

        //HTMLEditorPane editor = new HTMLEditorPane();

        if (rapidAYT == null)
        {
            System.out.println("new RapidSpellAsYouType()");
            rapidAYT = new RapidSpellAsYouType();
        }

        rapidAYT.setLanguageParser(language);
        rapidAYT.setGUILanguage(language);
        if(dictionaryPath != null){
            rapidAYT.setDictFilePath(dictionaryPath);
        }
        rapidAYT.setTextComponent(editor.getEditor());
        rapidAYT.forceCheckAll();
        
        boolean load = true;

        if (load)
        {        
            InputStream in = Demo.class.getResourceAsStream("/net/atlanticbb/tantlinger/shef/htmlsnip.txt");
            try{
                editor.setText(IOUtils.read(in));
                editor.setText("ssi");
            }catch(Exception ex) {
                ex.printStackTrace();
            } finally {
                IOUtils.close(in);
            }
        }

        frame = new JFrame();
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(editor.getEditMenu());
        menuBar.add(editor.getFormatMenu());
        menuBar.add(editor.getInsertMenu());
        //frame.setJMenuBar(menuBar);

        frame.setTitle("HTML Editor Demo");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                frame.dispose();
            }
        });


        frame.setSize(800, 600);
        frame.getContentPane().add(editor);
        frame.setVisible(true);
        
    }

    public static void main(String args[]) {

        try {
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName());
        } catch(Exception ex){}


        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
               new Demo();
            }
        });
    }

}
