
package net.atlanticbb.tantlinger.shef;

/**
 *
 * @author Nicolas de Pomereu
 */
public class Version {
        /** Version value to increment */    
    public static String VERSION    = "v1.1";

    /** Version date to increment */
    public static String DATE       = "02-Nov-19";
    
}
