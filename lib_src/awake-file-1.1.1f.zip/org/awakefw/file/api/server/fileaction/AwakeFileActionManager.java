/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api.server.fileaction;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.awakefw.file.api.server.AwakeFileConfigurator;

/**
 * The Action Manager for files: define how all concrete operations will be done
 * on files.
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */

public interface AwakeFileActionManager {

    /**
     * Action: creates the uploaded file on the server.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param inputStream
     *            the input stream of the multipart uploaded file
     * @param username
     *            the client username
     * @param filename
     *            the full path of filename to create
     * 
     * @throws IOException
     *             if any IOException occurs
     */
    public abstract void upload(
	    AwakeFileConfigurator awakeFileConfigurator,
	    InputStream inputStream, String username, String filename)
	    throws IOException;

    /**
     * Action: deletes a file.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the full path of filename to delete
     * 
     * @return true if the file is deleted
     * @throws IOException
     *             if any IOException occurs
     */
    public abstract boolean delete(
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws IOException;

    /**
     * Action: says if a file exists.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the full path of filename to delete
     * 
     * @return true if the file exists
     * @throws IOException
     *             if any IOException occurs
     */    
    public abstract boolean exists(
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws IOException;    
    
    
    /**
     * Action: creates a directory or sub-directory.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the full path of filename to create the sub-dir for
     * 
     * @return true if the directory or sub-directory is created
     * @throws IOException
     *             if any IOException occurs
     */
    public abstract boolean mkdir(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException;
    
    /**
     * Action: creates a directory or sub-directory.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the full path of filename to create the sub-dir for
     * 
     * @return true if the directory or sub-directory is created
     * @throws IOException
     *             if any IOException occurs
     */
    public abstract boolean mkdirs(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException;

    /**
     * Action: returns the file length in bytes.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the filename to get the size from
     * 
     * @return the file size or 0 if it not exists
     */
    public abstract long length(
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws IOException;

    /**
     * Action: downloads a file on the Servlet response output stream.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the filename to download
     * @param out
     *            the Servlet response output stream
     * 
     * @return true if the filename content is copied to the output stream, else
     *         false
     */
    public abstract boolean download(OutputStream out,
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws FileNotFoundException, IOException;

    /**
     * Action: Lists all files of a directory.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the full path of the directory into which to search for files
     * 
     * @return the list of files in the sub-directory
     * 
     * @throws IOException
     */
    public abstract List<File> listFiles(
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws IOException;

    /**
     * Action: Lists all sub-directories of a directory.
     * 
     * @param awakeFileConfigurator
     *            the user configuration
     * @param username
     *            the client username
     * @param filename
     *            the full path of the directory into which to search for
     *            sur-directories
     * 
     * @return the list of files in the sub-directory
     * 
     * @throws IOException
     */

    public abstract List<File> listDirectories(
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws IOException;

}
