/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.awakefw.commons.api.client.AwakeProgressManager;
import org.awakefw.commons.api.client.HttpProtocolParameters;
import org.awakefw.commons.api.client.HttpProxy;
import org.awakefw.commons.api.client.Invalid2faCodeException;
import org.awakefw.commons.api.client.InvalidLoginException;
import org.awakefw.commons.api.client.RemoteException;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.api.util.HtmlConverter;
import org.awakefw.file.http.HttpTransfer;
import org.awakefw.file.http.HttpTransferOne;
import org.awakefw.file.http.exception.HttpTransferInterruptedException;
import org.awakefw.file.json.ListHolder;
import org.awakefw.file.json.ListOfStringTransport;
import org.awakefw.file.util.AwakeClientLogger;
import org.awakefw.file.util.AwakeFileUtil;
import org.awakefw.file.util.KeepTempFilePolicyParms;
import org.awakefw.file.util.StringUtil;
import org.awakefw.file.util.Tag;
import org.awakefw.file.util.parms.Action;
import org.awakefw.file.util.parms.Parameter;
import org.awakefw.file.util.parms.ReturnCode;
import org.awakefw.file.version.AwakeFileVersion;

/**
 * Main class for executing from a Client (typically a PC) all sorts of
 * operations on remote files or remote classes through a Http or Https session.
 * <p>
 * Class includes methods to:
 * <ul>
 * <li>Get remote files size.</li>
 * <li>Delete remote files or directories.</li>
 * <li>Test if a remote file or directory exists.</li>
 * <li>Create a remote directory.</li>
 * <li>Get the list of files of a remote directory.</li>
 * <li>Get the list of sub-directories of a remote directory.</li>
 * <li>Upload files.</li>
 * <li>Download files.</li>
 * <li>Call remote Java methods.</li>
 * </ul>
 * Example: <blockquote>
 * 
 * <pre>
 * // Create an AwakeFile instance and username on the remote server
 * // using the URL of the path to the AwakeFileManager Servlet
 * String url = &quot;https://www.acme.org/AwakeFileManager&quot;;
 * 
 * // The login info for strong authentication on server side:
 * String username = &quot;myUsername&quot;;
 * char[] password = { 'm', 'y', 'P', 'a', 's', 's', 'w', 'o', 'r', 'd' };
 * 
 * AwakeFileSession awakeFileSession = new AwakeFileSession(url, username, password);
 * 
 * // OK: upload a file
 * awakeFileSession.upload(new File(&quot;c:\\myFile.txt&quot;), &quot;myFile.txt&quot;);
 * </pre>
 * 
 * </blockquote>
 * <p>
 * Communication via an (authenticating) proxy server is done using a
 * {@link org.awakefw.commons.api.client.HttpProxy} instance: <blockquote>
 * 
 * <pre>
 * HttpProxy httpProxy = new HttpProxy(&quot;myproxyhost&quot;, 8080);
 * String url = &quot;https://www.acme.org/AwakeFileManager&quot;;
 * 
 * // The login info for strong authentication on server side:
 * String username = &quot;myUsername&quot;;
 * char[] password = { 'm', 'y', 'P', 'a', 's', 's', 'w', 'o', 'r', 'd' };
 * 
 * AwakeFileSession awakeFileSession = new AwakeFileSession(url, username, password, httpProxy);
 * 
 * // Etc.
 * 
 * </pre>
 * 
 * </blockquote>
 * <p>
 * All long operations that need to be run on a separated thread may be followed
 * in Swing using a Java Progress Bar or Progress Monitor: just implement the
 * {@link org.awakefw.commons.api.client.AwakeProgressManager} interface.
 * <p>
 * 
 * @see org.awakefw.commons.api.client.HttpProxy
 * @see org.awakefw.commons.api.client.AwakeProgressManager
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */

public final class AwakeFileSession implements Cloneable {

    private static final String AWAKE_SESSION_IS_CLOSED = "Awake Session is closed.";

    /** For debug info */
    private static boolean DEBUG = AwakeDebug.isSet(AwakeFileSession.class);

    /** Defines if we must use base64 or html encode when using call() */
    private static boolean USE_HTML_ENCODING = true;

    /** The url to use to connectet to the Awake File Server */
    private String url = null;

    /**
     * The username is stored in static memory to be passed to upload file servlet
     */
    private String username = null;

    /**
     * Token is stored in static to be available during all session and contains
     * SHA-1(userId + ServerClientLogin.SECRET_FOR_LOGIN) computed by server. Token
     * is re-send and checked at each send or recv command to be sure user is
     * authenticated.
     */
    private String authenticationToken = null;

    /** The Http Proxy instance */
    private HttpProxy httpProxy = null;

    /** The Http Parameters instance */
    private HttpProtocolParameters httpProtocolParameters = null;

    /** The calling/owner thread */
    private AwakeProgressManager awakeProgressManager = null;

    /** The http transfer instance */
    private HttpTransfer httpTransfer = null;

    /**
     * Says if we wan to use base64 encoding for parameters passed to call() - This
     * is a method for legacy applications prior to v1.0.
     */
    public static void setUseBase64EncodingForCall() {
	USE_HTML_ENCODING = false;
    }

    /**
     * Private constructor for clone().
     * 
     * @param url                    the URL of the path to the AwakeFileManager
     *                               Servlet
     * @param username               the username for authentication on the Awake
     *                               Server (may be null for call() or
     *                               downloadUrl())
     * @param authenticationToken    the actual token of the Awake File session to
     *                               clone
     * @param httpProxy              the http proxy to use
     * @param httpProtocolParameters the http parameters to use
     */
    private AwakeFileSession(String url, String username, String authenticationToken, HttpProxy httpProxy,
	    HttpProtocolParameters httpProtocolParameters) {
	this.url = url;
	this.username = username;
	this.authenticationToken = authenticationToken;
	this.httpProxy = httpProxy;
	this.httpProtocolParameters = httpProtocolParameters;
    }

    /**
     * Creates an AwakeFile session with a proxy and protocol parameters.
     * <p>
     * 
     * @param url                    the URL of the path to the AwakeFileManager
     *                               Servlet
     * @param username               the username for authentication on the Awake
     *                               Server (may be null for <code>call()</code>
     * @param password               the user password for authentication on the
     *                               Awake Server (may be null)
     * @param httpProxy              the http proxy to use (null if none)
     * @param httpProtocolParameters the http parameters to use (may be null)
     * @param double2faCode          the 2FA code
     * @throws MalformedURLException   if the url is malformed
     * @throws UnknownHostException    if Host url (http://www.acme.org) does not
     *                                 exists or no Internet Connection..
     * @throws ConnectException        if the Host is correct but the
     *                                 AwakeFileManager Servlet is not reachable
     *                                 (http://www.acme.org/AwakeFileManager) and
     *                                 access failed with a status != OK (200). (If
     *                                 the host is incorrect, or is impossible to
     *                                 connect to - Tomcat down - the
     *                                 ConnectException will be the sub exception
     *                                 HttpHostConnectException.)
     * @throws InvalidLoginException   the username or password is invalid
     * @throws Invalid2faCodeException the 2FA code is invalid
     * @throws SecurityException       Scheme is required to be https (SSL/TLS)
     * @throws RemoteException         an exception has been thrown on the server
     *                                 side. This traps an Awake product failure and
     *                                 should not happen.
     * @throws IOException             For all other IO / Network / System Error
     */
    public AwakeFileSession(String url, String username, char[] password, HttpProxy httpProxy,
	    HttpProtocolParameters httpProtocolParameters, String double2faCode)
	    throws MalformedURLException, UnknownHostException, ConnectException, InvalidLoginException,
	    RemoteException, SecurityException, IOException {

	if (url == null) {
	    throw new MalformedURLException("url can not be null!");
	}

	@SuppressWarnings("unused")
	URL asUrl = new URL(url); // Try to raise a MalformedURLException;

	this.username = username;
	this.url = url;

	this.httpProxy = httpProxy;
	this.httpProtocolParameters = httpProtocolParameters;

	// username & password may be null: for call()
	if (username == null) {
	    return;
	}

	// if (password == null) {
	// throw new IllegalArgumentException("password can not be null!");
	// }

	// Test if SSL required by host
	if (this.url.toLowerCase().startsWith("http://") && isForceHttps()) {

	    this.url = rewriteUrlToHttps(url);
	}

	String passwordStr = new String(password);

	// Launch the Servlet
	httpTransfer = new HttpTransferOne(url, httpProxy, httpProtocolParameters, null);

	// Prepare the request parameters
//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.TEST_CRYPTO, Parameter.TEST_CRYPTO));
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, Action.LOGIN_ACTION));
//	requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	requestParams.add(new BasicNameValuePair(Parameter.PASSWORD, passwordStr));
//	requestParams.add(new BasicNameValuePair(Parameter.DOUBLE2FA_CODE, double2faCode));

	Map<String,String> requestParams = new HashMap<>();
	requestParams.put(Parameter.TEST_CRYPTO, Parameter.TEST_CRYPTO);
	requestParams.put(Parameter.ACTION, Action.LOGIN_ACTION);
	requestParams.put(Parameter.LOGIN, username);
	requestParams.put(Parameter.PASSWORD, passwordStr);
	requestParams.put(Parameter.DOUBLE2FA_CODE, double2faCode);
	
	httpTransfer.send(requestParams);

	// If everything is OK, we have in our protocol a response that
	// 1) starts with "OK". 2) Is followed by the Authentication Token
	// else: response starts with "INVALID_LOGIN_OR_PASSWORD".

	String receive = httpTransfer.recv();

	debug("receive: " + receive);

	if (receive.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
	    throw new InvalidLoginException("Invalid username or password.");
	} else if (receive.startsWith(ReturnCode.INVALID_2FA_CODE)) {
	    throw new Invalid2faCodeException("Invalid 2FA code.");
	} else if (receive.startsWith(ReturnCode.OK)) {
	    // OK! We are logged in & and correctly authenticated
	    // Keep in static memory the Authentication Token for next api
	    // commands (First 20 chars)
	    String theToken = receive.substring(ReturnCode.OK.length() + 1);
	    authenticationToken = StringUtils.left(theToken, Parameter.TOKEN_LEFT_SIZE);
	} else {
	    this.username = null;
	    // Should never happen
	    throw new InvalidLoginException(Tag.AWAKE_PRODUCT_FAIL + " Please contact support.");
	}

    }

    /**
     * Transform an url with a "http" scheme to secure "https" scheme including
     * guessed ports
     * 
     * @param url the url to rewrite
     * @return the rewritten url
     */
    private String rewriteUrlToHttps(String url) {

	if (url == null) {
	    throw new IllegalArgumentException("url can not be null!");
	}

	// Replace Scheme
	url = "https://" + StringUtils.substringAfter(url, "://");

	// replace Port
	if (url.contains(":8080/")) {
	    url = url.replace(":8080/", ":8443/");
	}

	if (url.contains(":80/")) {
	    url = url.replace(":80/", ":443/");
	}
	return url;
    }

    /**
     * 
     * Tests if remote host requires our URL to be SSL
     * 
     * @return true if the host requires SSL
     * 
     * @throws UnknownHostException
     * @throws ConnectException
     * @throws RemoteException
     * @throws SecurityException
     * @throws IOException
     */
    private boolean isForceHttps()
	    throws UnknownHostException, ConnectException, RemoteException, SecurityException, IOException {
	// Launch the Servlet
	httpTransfer = new HttpTransferOne(url, httpProxy, httpProtocolParameters, null);

	// Prepare the request parameters
//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, Action.BEFORE_LOGIN_ACTION));

	Map<String,String> requestParams = new HashMap<>();
	requestParams.put(Parameter.ACTION, Action.BEFORE_LOGIN_ACTION);

	httpTransfer.send(requestParams);

	// If everything is OK, we have in our protocol a response that
	// 1) starts with "OK". 2) Is followed by the Authentication Token
	// else: response starts with "INVALID_LOGIN_OR_PASSWORD".

	String receive = httpTransfer.recv();

	Boolean isForceHttps = new Boolean(receive);
	return isForceHttps.booleanValue();

    }

    /**
     * Creates an AwakeFile session with a proxy and protocol parameters.
     * <p>
     * 
     * @param url                    the URL of the path to the AwakeFileManager
     *                               Servlet
     * @param username               the username for authentication on the Awake
     *                               Server (may be null for <code>call()</code>
     * @param password               the user password for authentication on the
     *                               Awake Server (may be null)
     * @param httpProxy              the http proxy to use (null if none)
     * @param httpProtocolParameters the http parameters to use (may be null)
     * @throws MalformedURLException   if the url is malformed
     * @throws UnknownHostException    if Host url (http://www.acme.org) does not
     *                                 exists or no Internet Connection..
     * @throws ConnectException        if the Host is correct but the
     *                                 AwakeFileManager Servlet is not reachable
     *                                 (http://www.acme.org/AwakeFileManager) and
     *                                 access failed with a status != OK (200). (If
     *                                 the host is incorrect, or is impossible to
     *                                 connect to - Tomcat down - the
     *                                 ConnectException will be the sub exception
     *                                 HttpHostConnectException.)
     * @throws InvalidLoginException   the username or password is invalid
     * @throws Invalid2faCodeException the 2FA code is invalid
     * @throws SecurityException       Scheme is required to be https (SSL/TLS)
     * @throws RemoteException         an exception has been thrown on the server
     *                                 side. This traps an Awake product failure and
     *                                 should not happen.
     * @throws IOException             For all other IO / Network / System Error
     */
    public AwakeFileSession(String url, String username, char[] password, HttpProxy httpProxy,
	    HttpProtocolParameters httpProtocolParameters) throws MalformedURLException, UnknownHostException,
	    ConnectException, InvalidLoginException, RemoteException, SecurityException, IOException {
	this(url, username, password, httpProxy, httpProtocolParameters, null);
    }

    /**
     * Creates an AwakeFile session with a proxy.
     * <p>
     * 
     * @param url       the URL of the path to the AwakeFileManager Servlet
     * @param username  the username for authentication on the Awake Server (may be
     *                  null for <code>call()</code>
     * @param password  the user password for authentication on the Awake Server
     *                  (may be null)
     * @param httpProxy the http proxy to use (null if none)
     * 
     * @throws MalformedURLException if the url is malformed
     * @throws UnknownHostException  if Host url (http://www.acme.org) does not
     *                               exists or no Internet Connection..
     * @throws ConnectException      if the Host is correct but the AwakeFileManager
     *                               Servlet is not reachable
     *                               (http://www.acme.org/AwakeFileManager) and
     *                               access failed with a status != OK (200). (If
     *                               the host is incorrect, or is impossible to
     *                               connect to - Tomcat down - the ConnectException
     *                               will be the sub exception
     *                               HttpHostConnectException.)
     * @throws InvalidLoginException the username or password is invalid
     * @throws SecurityException     Scheme is required to be https (SSL/TLS)
     * @throws RemoteException       an exception has been thrown on the server side
     * @throws IOException           For all other IO / Network / System Error
     */
    public AwakeFileSession(String url, String username, char[] password, HttpProxy httpProxy)
	    throws MalformedURLException, UnknownHostException, ConnectException, InvalidLoginException,
	    RemoteException, SecurityException, IOException {
	this(url, username, password, httpProxy, null, null);
    }

    /**
     * Creates an AwakeFile session.
     * <p>
     * 
     * @param url      the URL of the path to the AwakeFileManager Servlet
     * @param username the username for authentication on the Awake Server (may be
     *                 null for <code>call()</code>
     * @param password the user password for authentication on the Awake Server (may
     *                 be null)
     * 
     * @throws MalformedURLException if the url is malformed
     * @throws UnknownHostException  if Host url (http://www.acme.org) does not
     *                               exists or no Internet Connection..
     * @throws ConnectException      if the Host is correct but the AwakeFileManager
     *                               Servlet is not reachable
     *                               (http://www.acme.org/AwakeFileManager) and
     *                               access failed with a status != OK (200). (If
     *                               the host is incorrect, or is impossible to
     *                               connect to - Tomcat down - the ConnectException
     *                               will be the sub exception
     *                               HttpHostConnectException.)
     * @throws InvalidLoginException the username or password is invalid
     * @throws SecurityException     Scheme is required to be https (SSL/TLS)
     * @throws RemoteException       an exception has been thrown on the server side
     * @throws IOException           For all other IO / Network / System Error
     */

    public AwakeFileSession(String url, String username, char[] password)
	    throws MalformedURLException, UnknownHostException, ConnectException, InvalidLoginException,
	    RemoteException, IOException, SecurityException {
	this(url, username, password, null, null, null);
    }

    /**
     * Allows to set an Awake Progress Manager instance.
     * 
     * @param awakeProgressManager the Awake Progress Manager instance
     */
    public void setAwakeProgressManager(AwakeProgressManager awakeProgressManager) {
	this.awakeProgressManager = awakeProgressManager;
    }

    /**
     * Returns the username of this Awake File session
     * 
     * @return the username of this Awake File session
     */
    public String getUsername() {
	return this.username;
    }

    /**
     * Returns the <code>AwakeProgresManager</code> in use.
     * 
     * @return the <code>AwakeProgresManager</code> in use
     */
    public AwakeProgressManager getAwakeProgressManager() {
	return this.awakeProgressManager;
    }

    /**
     * Returns the HttpProtocolParameters instance in use for the Awake File
     * session.
     * 
     * @return the HttpProtocolParameters instance in use for the Awake File session
     */
    public HttpProtocolParameters getHttpProtocolParameters() {
	return this.httpProtocolParameters;
    }

    /**
     * Returns the URL of the path to the <code>AwakeFileManager</code> Servlet (or
     * <code>AwakeSqlManager</code> Servlet if session has been initiated by an
     * <code>AwakeConnection</code>).
     * 
     * @return the URL of the path to the <code>AwakeFileManager</code> Servlet
     */
    public String getUrl() {
	return url;
    }

    /**
     * Returns the HttpProxy instance in use for this Awake session.
     * 
     * @return the HttpProxy instance in use for this Awake session
     */
    public HttpProxy getHttpProxy() {
	return this.httpProxy;
    }

    /**
     * Returns the http status code of the last executed verb
     * 
     * @return the http status code of the last executed verb
     */
    public int getHttpStatusCode() {
	if (httpTransfer != null) {
	    return httpTransfer.getHttpStatusCode();
	} else {
	    return 0;
	}
    }

    /**
     * Returns the Authentication Token. This method is used by other Awake products
     * (Awake SQL, ...)
     * 
     * @return the Authentication Token
     */
    public String getAuthenticationToken() {
	return this.authenticationToken;
    }

    /**
     * Downloads a file from the remote server.
     * <p>
     * The path of the remote file name is relative depending on the Awake File
     * configuration on the server. The path may be expressed
     * <p>
     * 
     * @param remoteFile the file name on the host
     * @param file       the file to create on the Client side
     * 
     * @throws IllegalArgumentException if remoteFile or file is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * @throws FileNotFoundException    if the remote file is not found on server
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     */
    public void download(String remoteFile, File file) throws IllegalArgumentException, InvalidLoginException,
	    FileNotFoundException, UnknownHostException, ConnectException, RemoteException, IOException

    {
	if (remoteFile == null) {
	    throw new IllegalArgumentException("remoteFile can not be null!");
	}

	if (file == null) {
	    throw new IllegalArgumentException("file can not be null!");
	}

	if (username == null || authenticationToken == null) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	// debug("downloadFile Begin");
	try {

	    httpTransfer = new HttpTransferOne(url, this.httpProxy, httpProtocolParameters, awakeProgressManager);

	    // Prepare the request parameters
//	    List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	    requestParams.add(new BasicNameValuePair(Parameter.ACTION, Action.DOWNLOAD_FILE_ACTION));
//	    requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	    requestParams.add(new BasicNameValuePair(Parameter.TOKEN, authenticationToken));
//	    requestParams.add(new BasicNameValuePair(Parameter.FILENAME, remoteFile));

	    Map<String, String> requestParams = new HashMap<>();
	    requestParams.put(Parameter.ACTION, Action.DOWNLOAD_FILE_ACTION);
	    requestParams.put(Parameter.LOGIN, username);
	    requestParams.put(Parameter.TOKEN, authenticationToken);
	    requestParams.put(Parameter.FILENAME, remoteFile);
		
	    httpTransfer.download(requestParams, file);
	} catch (HttpTransferInterruptedException e) {
	    throw new IOException(new InterruptedException(e.getLocalizedMessage()));
	}

	// If everything is OK, we have in our protocol a response that
	// 1) starts with "OK". 2) Is followed by the authentication token
	// else: response starts with "INVALID_LOGIN_OR_PASSWORD".

	// Analyze the answer, case of invalid login or FileNotFound Tag
	String receive = httpTransfer.recv();

	if (receive.length() > 1) {
	    if (receive.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
		throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	    }

	    if (receive.startsWith(Tag.FileNotFoundException)) {
		throw new FileNotFoundException("Remote file does not exists: " + remoteFile);
	    }

	    // Should never happen
	    throw new IOException(Tag.AWAKE_PRODUCT_FAIL + "Invalid received buffer: " + receive);
	}

    }

    /**
     * Uploads a file on the server.
     * <p>
     * The path of the remote file name is relative depending on the Awake File
     * configuration on the server.
     * <p>
     * 
     * @param file       the file to upload
     * @param remoteFile the file name on the host
     * 
     * @throws IllegalArgumentException if file or remoteFile is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * @throws FileNotFoundException    if the file to upload is not found
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     * 
     */
    public void upload(File file, String remoteFile) throws IllegalArgumentException, InvalidLoginException,
	    FileNotFoundException, UnknownHostException, ConnectException, RemoteException, IOException

    {
	if (remoteFile == null) {
	    throw new IllegalArgumentException("remoteFile can not be null!");
	}

	if (file == null) {
	    throw new IllegalArgumentException("file can not be null!");
	}

	if (!file.exists()) {
	    throw new FileNotFoundException("File does not exists: " + file);
	}

	if (username == null || authenticationToken == null) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	httpTransfer = new HttpTransferOne(url, this.httpProxy, httpProtocolParameters, awakeProgressManager);

	// Prepare the request parameters
//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, Action.UPLOAD_FILE_ACTION));
//	requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	requestParams.add(new BasicNameValuePair(Parameter.TOKEN, authenticationToken));
//	requestParams.add(new BasicNameValuePair(Parameter.FILENAME, remoteFile));

	Map<String, String> requestParams = new HashMap<>();
	requestParams.put(Parameter.ACTION, Action.UPLOAD_FILE_ACTION);
	requestParams.put(Parameter.LOGIN, username);
	requestParams.put(Parameter.TOKEN, authenticationToken);
	requestParams.put(Parameter.FILENAME, remoteFile);
	    
	httpTransfer.send(requestParams, file);

	if (awakeProgressManager != null && awakeProgressManager.isCancelled()) {
	    throw new IOException(new InterruptedException(Tag.AWAKE + "File upload interrupted by user."));
	}

	// If everything is OK, we have in our protocol a response that
	// 1) starts with "OK". 2) Is followed by the authenticaiton token
	// else: response starts with "INVALID_LOGIN_OR_PASSWORD".

	// Return the answer
	String receive = httpTransfer.recv();

	debug("receive: " + receive);

	if (receive.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

    }

    /**
     * Returns the length of a a list of files located on the remote host.
     * 
     * @param remoteFiles the list of the files located on the remote host.
     * 
     * @return the total length of the files located on the remote host.
     * 
     * @throws IllegalArgumentException remoteFilesPath is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if the host url (http://www.acme.org) does
     *                                  not exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     */
    public long length(List<String> remoteFiles) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {
	if (remoteFiles == null) {
	    throw new IllegalArgumentException("remotesFilePath can not be null!");
	}

	if (username == null || authenticationToken == null) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	remoteFiles = HtmlConverter.toHtml(remoteFiles);

	httpTransfer = new HttpTransferOne(url, httpProxy, httpProtocolParameters, awakeProgressManager);

	ListHolder listHolderRemoteFilesPath = new ListHolder();
	listHolderRemoteFilesPath.setList(remoteFiles);

	String jsonString = ListOfStringTransport.toJson(listHolderRemoteFilesPath);

	// Prepare the request parameters
//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, Action.GET_FILE_LENGTH_ACTION));
//	requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	requestParams.add(new BasicNameValuePair(Parameter.TOKEN, authenticationToken));
//	requestParams.add(new BasicNameValuePair(Parameter.FILENAME, jsonString));

	Map<String, String> requestParams = new HashMap<>();
	requestParams.put(Parameter.ACTION, Action.GET_FILE_LENGTH_ACTION);
	requestParams.put(Parameter.LOGIN, username);
	requestParams.put(Parameter.TOKEN, authenticationToken);
	requestParams.put(Parameter.FILENAME, jsonString);
	    
	httpTransfer.send(requestParams);

	// If everything is OK, we have in our protocol a response that
	// 1) starts with "OK". 2) Is followed by the Authentication Token
	// else: response starts with "INVALID_LOGIN_OR_PASSWORD".

	String response = httpTransfer.recv();

	if (response.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	} else {
	    try {
		long fileLength = Long.parseLong(response);
		return fileLength;
	    } catch (NumberFormatException nfe) {
		// Build an Awake Exception with the content of the recv stream
		throw new IOException(Tag.AWAKE_PRODUCT_FAIL + nfe.getMessage(), nfe);
	    }
	}
    }

    /**
     * Returns the length of a file located on the remote host.
     * 
     * @param remoteFile the file name on the host
     * 
     * @return the length of the file located on the remote host.
     * 
     * @throws IllegalArgumentException if remoteFilesPath is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if the Host url (http://www.acme.org) does
     *                                  not exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     */
    public long length(String remoteFile) throws IllegalArgumentException, InvalidLoginException, UnknownHostException,
	    ConnectException, RemoteException, IOException {
	if (remoteFile == null) {
	    throw new IllegalArgumentException("remotesFilePath can not be null!");
	}

	if (username == null || authenticationToken == null) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	List<String> list = new Vector<String>();
	list.add(remoteFile);
	return length(list);
    }

    /**
     * Deletes a remote file or remote directory on the host. (Directory must be
     * empty to be deleted).
     * 
     * @param remoteFile the file name on the host
     * 
     * @return true if the file has been deleted
     * 
     * @throws IllegalArgumentException if remoteFile is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws SecurityException        the url is not secured with https (SSL)
     * @throws IOException              For all other IO / Network / System Error
     */
    public boolean delete(String remoteFile) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {
	return actionOnUniqueFile(remoteFile, Action.DELETE_FILE_ACTION);
    }

    /**
     * Says if a remote file or directory exists.
     * 
     * @param remoteFile the file name on the host
     * 
     * @return true if the file or directory exists
     * 
     * @throws IllegalArgumentException if remoteFile is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws SecurityException        the url is not secured with https (SSL)
     * @throws IOException              For all other IO / Network / System Error
     */
    public boolean exists(String remoteFile) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {
	return actionOnUniqueFile(remoteFile, Action.EXISTS_ACTION);
    }

    /**
     * Executes a Java <code>File.mkdir()</code> on the Host.
     * 
     * @param remoteFile the file name on the host
     * 
     * @return true if the mkdir() is successful
     * 
     * @throws IllegalArgumentException if remoteFile is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws IOException              For all other IO / Network / System Error
     */
    public boolean mkdir(String remoteFile) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {
	return actionOnUniqueFile(remoteFile, Action.MKDIR_ACTION);
    }

    /**
     * Executes a Java <code>File.mkdirs()</code> on the Host.
     * 
     * @param remoteFile the file name on the host
     * 
     * @return true if the mkdirs() is successful
     * 
     * @throws IllegalArgumentException if remoteFile is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws IOException              For all other IO / Network / System Error
     */
    public boolean mkdirs(String remoteFile) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {
	return actionOnUniqueFile(remoteFile, Action.MKDIRS_ACTION);
    }

    /**
     * 
     * Do a boolean action on a unique file or directory
     * 
     * @param remoteFile the file name on the host
     * 
     * @return true if the file has been deleted
     * 
     * @throws IllegalArgumentException if remoteFile or action is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     */
    private boolean actionOnUniqueFile(String remoteFile, String action) throws IllegalArgumentException,
	    InvalidLoginException, UnknownHostException, ConnectException, RemoteException, IOException {
	if (remoteFile == null) {
	    throw new IllegalArgumentException("remoteFile can not be null!");
	}

	if (action == null) {
	    throw new IllegalArgumentException("action can not be null!");
	}

	if (username == null || authenticationToken == null) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	// Launch the Servlet
	httpTransfer = new HttpTransferOne(url, httpProxy, httpProtocolParameters, awakeProgressManager);

	// Prepare the request parameters

//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, action));
//	requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	requestParams.add(new BasicNameValuePair(Parameter.TOKEN, authenticationToken));
//	requestParams.add(new BasicNameValuePair(Parameter.FILENAME, remoteFile));
	
	Map<String,String> requestParams = new HashMap<>();
	requestParams.put(Parameter.ACTION, action);
	requestParams.put(Parameter.LOGIN, username);
	requestParams.put(Parameter.TOKEN, authenticationToken);
	requestParams.put(Parameter.FILENAME, remoteFile);
	
	httpTransfer.send(requestParams);

	// If everything is OK, we have in our protocol a response that
	// 1) starts with "OK". 2) Is followed by the authenticaiton token
	// else: response starts with "INVALID_LOGIN_OR_PASSWORD".
	String response = httpTransfer.recv();

	if (response.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	try {
	    boolean actionDone = Boolean.parseBoolean(response);
	    return actionDone;
	} catch (NumberFormatException nfe) {
	    // Build an Awake Exception with the content of the recv stream
	    throw new IOException(Tag.AWAKE_PRODUCT_FAIL + nfe.getMessage(), nfe);
	}
    }

    /**
     * Lists the files contained in a remote directory.
     * 
     * @param remoteFile the file name of the directory on the host
     * 
     * @return the list of files in the remote directory. Will be <code>null</code>
     *         if the remote directory does not exists. Will be empty if the remote
     *         directory exists but has no files.
     * 
     * @throws IllegalArgumentException if remoteFile is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     */
    public List<String> listFiles(String remoteFile) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {
	return listFilesOrDirectory(remoteFile, Action.LIST_FILES_IN_DIR_ACTION);
    }

    /**
     * Lists the sub-directories contained in a remote directory
     * 
     * @param remoteFile the file name of the directory on the host
     * 
     * @return the list of directories in the remote directory. Will be
     *         <code>null</code> if the remote directory does not exists. Will be
     *         empty if the remote directory exists but has no sub-directories.
     * 
     * @throws IllegalArgumentException if remoteFile is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     */
    public List<String> listDirectories(String remoteFile) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {
	return listFilesOrDirectory(remoteFile, Action.LIST_DIRS_IN_DIR_ACTION);
    }

    /**
     * 
     * Returns the list of files or directory in the remote directory.
     * 
     * @param remoteFile the file name of the directory on the host
     * 
     * @return the list of files or directories in the remote directory. Will be
     *         <code>null</code> if the remote directory does not exists. Will be
     *         empty if the remote directory exists but is empty.
     * 
     * @throws IllegalArgumentException if remoteFile is null
     * @throws InvalidLoginException    if the username is refused by the remote
     *                                  host
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws SecurityException        the url is not secured with https (SSL)
     * @throws IOException              For all other IO / Network / System Error
     */
    private List<String> listFilesOrDirectory(String remoteFile, String action) throws IllegalArgumentException,
	    InvalidLoginException, UnknownHostException, ConnectException, RemoteException, IOException

    {
	if (remoteFile == null) {
	    throw new IllegalArgumentException("remoteFile can not be null!");
	}

	if (action == null) {
	    throw new IllegalArgumentException("action can not be null!");
	}

	if (username == null || authenticationToken == null) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	// Launch the Servlet
	httpTransfer = new HttpTransferOne(url, httpProxy, httpProtocolParameters, awakeProgressManager);

	// Prepare the request parameters
//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, action));
//	requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	requestParams.add(new BasicNameValuePair(Parameter.TOKEN, authenticationToken));
//	requestParams.add(new BasicNameValuePair(Parameter.FILENAME, remoteFile));

	Map<String,String> requestParams = new HashMap<>();
	requestParams.put(Parameter.ACTION, action);
	requestParams.put(Parameter.LOGIN, username);
	requestParams.put(Parameter.TOKEN, authenticationToken);
	requestParams.put(Parameter.FILENAME, remoteFile);
	
	httpTransfer.setReceiveInFile(true); // To say we get the result into a
					     // file
	httpTransfer.send(requestParams);

	// If everything is OK, we have in our protocol a response that
	// 1) starts with "OK". 2) Is followed by the authenticaiton token
	// else: response starts with "INVALID_LOGIN_OR_PASSWORD".

	File receiveFile = httpTransfer.getReceiveFile();
	String receive = AwakeFileUtil.getFirstLineOfFile(receiveFile);

	// Content is OK
	if (receive.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
	    if (!DEBUG && !KeepTempFilePolicyParms.KEEP_TEMP_FILE) {
		receiveFile.delete();
	    }
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	try {
	    if (receive.equals("null")) {
		return null;
	    } else if (receive.equals("[]")) {
		return new Vector<String>();
	    } else {
		List<String> list = getFilesListFromFile(receiveFile);
		return list;
	    }
	} catch (Exception e) {
	    throw new IOException(e.getMessage(), e);
	} finally {
	    if (!DEBUG && !KeepTempFilePolicyParms.KEEP_TEMP_FILE) {
		receiveFile.delete();
	    }
	}

    }

    /**
     * Transforms the content of the file in Base64 lines into a list.
     * 
     * @param file the file containing the file names
     * 
     * @return the content of the file lines into a list
     * @throws IOException if any IO / Network / System Error occurs
     */
    private List<String> getFilesListFromFile(File file) throws IOException {

	List<String> listBase = FileUtils.readLines(file);

	List<String> files = new Vector<String>();

	for (String theFileStr : listBase) {

	    theFileStr = HtmlConverter.fromHtml(theFileStr);

	    files.add(theFileStr);
	}

	return files;
    }

    /**
     * Logs off from the remote host.&nbsp; This will purge the authentication
     * values necessary for method calls.
     * <p>
     * <b>Method should be called at the closure of the Client application</b>.
     */
    public void logoff() {
	username = null;
	authenticationToken = null;

	httpProxy = null;
	httpProtocolParameters = null;
	awakeProgressManager = null;
    }

    /**
     * Calls a remote Java {@code class.method} and (eventually) pass some
     * parameters to it. This method transforms the values in Base64. It's a legacy
     * method not to be used anymore: use {@code call} instead.
     * 
     * @param methodName the full method name to call in the format
     *                   <code>org.acme.config.package.MyClass.myMethod</code>
     * @param params     the array of parameters passed to the method
     * @return the result of the Java call as string
     * 
     * @throws IllegalArgumentException if methodName is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     * 
     */

    private String callBase64Encoded(String methodName, Object... params) throws IllegalArgumentException,
	    InvalidLoginException, UnknownHostException, ConnectException, RemoteException, IOException {

	// Class and method name can not be null
	if (methodName == null) {
	    throw new IllegalArgumentException("methodName can not be null!");
	}

	// username & Authentication Token may be null
	// because some methods can be called freely

	if (username == null) {
	    username = "null";
	}

	if (authenticationToken == null) {
	    authenticationToken = "null";
	}

	// Build the params types
	List<String> paramsTypes = new Vector<String>();

	// Build the params values
	List<String> paramsValues = new Vector<String>();

	debug("");

	for (int i = 0; i < params.length; i++) {
	    if (params[i] == null) {
		throw new IllegalArgumentException(
			Tag.AWAKE + "null values are not supported. Please provide a value for all parameters.");
	    } else {
		String classType = params[i].getClass().getName();

		// NO! can alter class name if value is obsfucated
		// classType = StringUtils.substringAfterLast(classType, ".");
		paramsTypes.add(classType);

		String value = params[i].toString();

		debug("");
		debug("classType: " + classType);
		debug("value    : " + value);

		paramsValues.add(value);
	    }

	}

	ListHolder listHolderTypes = new ListHolder();
	listHolderTypes.setList(paramsTypes);
	String jsonParamTypes = ListOfStringTransport.toJson(listHolderTypes);

	ListHolder listHolderValues = new ListHolder();
	listHolderValues.setList(paramsValues);
	String jsonParamValues = ListOfStringTransport.toJson(listHolderValues);

	debug("methodName     : " + methodName);
	debug("jsonParamTypes : " + jsonParamTypes);
	debug("jsonParamValues: " + jsonParamValues);

	httpTransfer = new HttpTransferOne(url, httpProxy, httpProtocolParameters, awakeProgressManager);
	// Prepare the request parameters
//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, Action.CALL_ACTION));
//	requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	requestParams.add(new BasicNameValuePair(Parameter.TOKEN, authenticationToken));
//	requestParams.add(new BasicNameValuePair(Parameter.METHOD_NAME, methodName));
//	requestParams.add(new BasicNameValuePair(Parameter.PARAMS_TYPES, StringUtil.toBase64(jsonParamTypes)));
//	requestParams.add(new BasicNameValuePair(Parameter.PARAMS_VALUES, StringUtil.toBase64(jsonParamValues)));
	
	Map<String,String> requestParams = new HashMap<>();
	requestParams.put(Parameter.ACTION, Action.CALL_ACTION);
	requestParams.put(Parameter.LOGIN, username);
	requestParams.put(Parameter.TOKEN, authenticationToken);
	requestParams.put(Parameter.METHOD_NAME, methodName);
	requestParams.put(Parameter.PARAMS_TYPES, StringUtil.toBase64(jsonParamTypes));
	requestParams.put(Parameter.PARAMS_VALUES, StringUtil.toBase64(jsonParamValues));

	httpTransfer.send(requestParams);

	// Return the answer
	String response = httpTransfer.recv();

	debug("response: " + response);

	// Content is OK
	if (response.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	// The response is in Base 64
	try {
	    if (!response.isEmpty()) {
		response = StringUtil.fromBase64(response);
	    }
	} catch (Exception e) {
	    debug(response);
	    // May happen till new Awake File is not deployed on Server
	    throw new IOException(Tag.AWAKE_PRODUCT_FAIL + "Response must be and is not base64!", e);
	}

	return response;

    }

    /**
     * Calls a remote Java class.method and (eventually) pass some parameters to it.
     * 
     * @param methodName the full method name to call in the format
     *                   <code>org.acme.config.package.MyClass.myMethod</code>
     * @param params     the array of parameters passed to the method
     * @return the result of the Java call as string
     * 
     * @throws IllegalArgumentException if methodName is null
     * @throws InvalidLoginException    the session has been closed by a logoff()
     * 
     * @throws UnknownHostException     if Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         if the Host is correct but the
     *                                  AwakeFileManager Servlet is not reachable
     *                                  (http://www.acme.org/AwakeFileManager) and
     *                                  access failed with a status != OK (200). (If
     *                                  the host is incorrect, or is impossible to
     *                                  connect to - Tomcat down - the
     *                                  ConnectException will be the sub exception
     *                                  HttpHostConnectException.)
     * @throws RemoteException          an exception has been thrown on the server
     *                                  side
     * @throws IOException              For all other IO / Network / System Error
     * 
     */

    public String call(String methodName, Object... params) throws IllegalArgumentException, InvalidLoginException,
	    UnknownHostException, ConnectException, RemoteException, IOException {

	// For legacy methods
	if (!USE_HTML_ENCODING) {
	    return callBase64Encoded(methodName, params);
	}

	// Class and method name can not be null
	if (methodName == null) {
	    throw new IllegalArgumentException("methodName can not be null!");
	}

	// username & Authentication Token may be null
	// because some methods can be called freely

	if (username == null) {
	    username = "null";
	}

	if (authenticationToken == null) {
	    authenticationToken = "null";
	}

	// Build the params types
	List<String> paramsTypes = new Vector<String>();

	// Build the params values
	List<String> paramsValues = new Vector<String>();

	debug("");

	for (int i = 0; i < params.length; i++) {
	    if (params[i] == null) {
		throw new IllegalArgumentException(
			Tag.AWAKE + "null values are not supported. Please provide a value for all parameters.");
	    } else {
		String classType = params[i].getClass().getName();

		// NO! can alter class name if value is obsfucated
		// classType = StringUtils.substringAfterLast(classType, ".");
		paramsTypes.add(classType);

		String value = params[i].toString();

		debug("");
		debug("classType: " + classType);
		debug("value    : " + value);

		paramsValues.add(value);
	    }
	}

	ListHolder listHolderTypes = new ListHolder();
	listHolderTypes.setList(paramsTypes);
	String jsonParamTypes = ListOfStringTransport.toJson(listHolderTypes);

	ListHolder listHolderValues = new ListHolder();
	listHolderValues.setList(paramsValues);
	String jsonParamValues = ListOfStringTransport.toJson(listHolderValues);

	debug("methodName     : " + methodName);
	debug("jsonParamTypes : " + jsonParamTypes);
	debug("jsonParamValues: " + jsonParamValues);

	httpTransfer = new HttpTransferOne(url, httpProxy, httpProtocolParameters, awakeProgressManager);
	// Prepare the request parameters
//	List<BasicNameValuePair> requestParams = new Vector<BasicNameValuePair>();
//	requestParams.add(new BasicNameValuePair(Parameter.ACTION, Action.CALL_ACTION_HTML_ENCODED));
//	requestParams.add(new BasicNameValuePair(Parameter.LOGIN, username));
//	requestParams.add(new BasicNameValuePair(Parameter.TOKEN, authenticationToken));
//	requestParams.add(new BasicNameValuePair(Parameter.METHOD_NAME, methodName));
//	requestParams.add(new BasicNameValuePair(Parameter.PARAMS_TYPES, jsonParamTypes));
//	requestParams.add(new BasicNameValuePair(Parameter.PARAMS_VALUES, jsonParamValues));

	Map<String,String> requestParams = new HashMap<>();
	requestParams.put(Parameter.ACTION, Action.CALL_ACTION_HTML_ENCODED);
	requestParams.put(Parameter.LOGIN, username);
	requestParams.put(Parameter.TOKEN, authenticationToken);
	requestParams.put(Parameter.METHOD_NAME, methodName);
	requestParams.put(Parameter.PARAMS_TYPES, jsonParamTypes);
	requestParams.put(Parameter.PARAMS_VALUES, jsonParamValues);
	
	httpTransfer.send(requestParams);

	// Return the answer
	String response = httpTransfer.recv();

	debug("response: " + response);

	// Content is OK
	if (response.startsWith(ReturnCode.INVALID_LOGIN_OR_PASSWORD)) {
	    throw new InvalidLoginException(AWAKE_SESSION_IS_CLOSED);
	}

	// The response is in Html encode:
	if (!response.isEmpty()) {
	    response = HtmlConverter.fromHtml(response);
	}

	return response;

    }

    /**
     * Allows to get a copy of the current <code>AwakeFileSession</code>: use it to
     * do some simultaneous operations in a different thread (in order to avoid
     * conflicts).
     */
    @Override
    public AwakeFileSession clone() {
	AwakeFileSession awakeFileSession = new AwakeFileSession(this.url, this.username, this.authenticationToken,
		this.httpProxy, this.httpProtocolParameters);
	return awakeFileSession;
    }

    /**
     * Returns the Awake File Version.
     * 
     * @return the Awake File Version
     */
    public String getVersion() {
	return AwakeFileVersion.getVersion();
    }

    /**
     * debug tool
     */
    private void debug(String s) {
	if (DEBUG) {
	    AwakeClientLogger.log(s);
	}
    }

}

// End
