/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.util.convert;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.awakefw.commons.api.client.HttpProtocolParameters;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.api.util.HtmlConverter;
import org.awakefw.file.util.parms.Parameter;
import org.awakefw.file.version.AwakeFileVersionValues;

public class BasicNameValuePairConvertor {
    /** Debug flag */
    private static boolean DEBUG = AwakeDebug
	    .isSet(BasicNameValuePairConvertor.class);

    /** The request params */
    private Map<String,String>  requestParams = null;

    /** The http protocol parameters */
    private HttpProtocolParameters httpProtocolParameters = null;

    /**
     * Constructor
     * 
     * @param requestParams
     *            the request parameters list of BasicNameValuePair
     */
    public BasicNameValuePairConvertor(Map<String,String> requestParams, 
	    	HttpProtocolParameters httpProtocolParameters) {
	this.requestParams = requestParams;
	this.httpProtocolParameters = httpProtocolParameters;
    }

    /**
     * @return the convert & may be encrypted parameters
     */
    public Map<String,String>  convert() throws IOException {
	Map<String,String> requestParamsConverted = new HashMap<String, String>();

	for ( Map.Entry<String, String> entry : requestParams.entrySet() ) {

	    String paramName = entry.getKey();	    
	    String paramValue = entry.getValue();

	    // Don't do it for STATEMENT_HOLDER ==> already has it's own Html
	    // conversion and encryption
	    if (! paramName.equals(Parameter.STATEMENT_HOLDER))
	    {
		paramValue = HtmlConverter.toHtml(paramValue);
		paramValue = encryptValue(paramName, paramValue);
	    }
		    	  
	    debug("converted param name : " + paramName);
	    debug("converted param value: " + paramValue);

	    requestParamsConverted.put(paramName, paramValue);
	}
	
	// Add the Version
//	BasicNameValuePair basicNameValuePairEnc = new BasicNameValuePair(
//		Parameter.VERSION, AwakeFileVersionValues.VERSION);
//	requestParamsConverted.add(basicNameValuePairEnc);
	    
	requestParamsConverted.put(Parameter.VERSION, AwakeFileVersionValues.VERSION);
	    
	return requestParamsConverted;
    }

    /**
     * Encrypt the parameter value
     * 
     * @param paramName
     *            the parameter name
     * @param paramValue
     *            the parameter value
     * 
     * @return the encrypted parameter value
     * 
     * @throws IOException
     *             if any exception occurs
     */
    private String encryptValue(String paramName, String paramValue)
	    throws IOException {
	
	if (httpProtocolParameters == null) {
	    return paramValue;
	}
	
	char [] password = httpProtocolParameters.getEncryptionPassword();

	if (password == null || password.length <= 1) {
	    return paramValue;
	}
	    	
	try {
	    paramValue = Pbe.AWAKE_ENCRYPTED
		    + new Pbe().encryptToHexa(paramValue, password);
	} catch (Exception e) {
	    String message = "Impossible to encrypt the value of the parameter "
		    + paramName;

	    throw new IOException(message, e);
	}
	return paramValue;
    }

    /**
     * Displays the given message if DEBUG is set.
     * 
     * @param s
     *            the debug message
     */

    private static void debug(String s) {
	if (DEBUG) {
	    System.out.println(s);
	}
    }

}
