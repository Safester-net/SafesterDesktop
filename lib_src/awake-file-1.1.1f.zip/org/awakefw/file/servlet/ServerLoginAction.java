/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.awakefw.commons.api.server.AwakeCommonsConfigurator;
import org.awakefw.commons.server.util.AwakeServerLogger;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.http.HttpTransfer;
import org.awakefw.file.util.IpSubnet;
import org.awakefw.file.util.Tag;
import org.awakefw.file.util.parms.Action;
import org.awakefw.file.util.parms.Parameter;
import org.awakefw.file.util.parms.ReturnCode;

/**
 * @author Nicolas de Pomereu
 * 
 *         The method executeRequest() is to to be called from the
 *         ServerClientLogin Servlet and Class. <br>
 *         It will execute a client side request with a
 *         ServerCaller.httpsLogin()
 * 
 */

public class ServerLoginAction extends HttpServlet {
    private static boolean DEBUG = AwakeDebug.isSet(ServerLoginAction.class);

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    // A space
    public static final String SPACE = " ";

    /**
     * Constructor
     */
    public ServerLoginAction() {

    }

    /**
     * 
     * Execute the login request asked by the main Awake File Servlet
     * 
     * @param request
     *            the http request
     * @param response
     *            the http response
     * @param awakeCommonsConfigurator
     *            the Awake Commons Client login specific class
     * @param action
     *            the login action: BEFORE_LOGIN_ACTION or LOGIN_ACTION
     * @throws IOException
     *             if any Servlet Exception occurs
     */
    public void executeAction(HttpServletRequest request,
	    HttpServletResponse response,
	    AwakeCommonsConfigurator awakeCommonsConfigurator, String action)
	    throws IOException {
	PrintWriter out = response.getWriter();

	try {
	    response.setContentType("text/html");

	    // if the action is BEFORE_LOGIN_ACTION: just test if we must be in
	    // https mode
	    if (action.equals(Action.BEFORE_LOGIN_ACTION)) {
		// Check if we must be in httpS
		boolean forceHttps = awakeCommonsConfigurator.forceSecureHttp();

		out.println(HttpTransfer.SEND_OK);
		out.println(forceHttps);
		return;
	    }

	    debug("before request.getParameter(Parameter.LOGIN);");

	    String username = request.getParameter(Parameter.LOGIN);
	    username = username.trim();

	    String password = request.getParameter(Parameter.PASSWORD);
	    password = password.trim();

	    // User must provide a user
	    if (username.length() < 1) {
		debug("username.length() < 1!");
		// No login transmitted
		// Redirect to ClientLogin with error message.
		out.println(HttpTransfer.SEND_OK);
		out.println(ReturnCode.INVALID_LOGIN_OR_PASSWORD);
		return;
	    }

	    debug("before awakeCommonsConfigurator.getBannedUsernames();");

	    // Check the username. Refuse access if username is banned
	    Set<String> usernameSet = awakeCommonsConfigurator.getBannedUsernames();	    	    
	    if (usernameSet.contains(username)) {
		debug("banned username!");
		throw new SecurityException("Username is banned: "
			+ usernameSet);
	    }
	    
	    debug("before awakeCommonsConfigurator.getBannedIPs();");

	    // Check the IP. Refuse access if IP is banned
	    String ip = request.getRemoteAddr();
	    List<String> bannedIpList = awakeCommonsConfigurator.getBannedIPs();
	    
	    if (isIpBanned(ip, bannedIpList)) {
		debug("banned IP!");
		throw new SecurityException("Client IP is banned: " + ip);
	    }

	    debug("calling checkLoginAndPassword");

	    boolean isOk =  awakeCommonsConfigurator.login(username,
		    password.toCharArray());
	    
	    debug("login isOk: " + isOk + " (login: " + username + ")");

	    if (!isOk) {
		debug("login: invalid login or password");

		// Reduce the login speed
		LoginSpeedReducer loginSpeedReducer = new LoginSpeedReducer(
			username);
		loginSpeedReducer.checkAttempts();

		out.println(HttpTransfer.SEND_OK);
		out.println(ReturnCode.INVALID_LOGIN_OR_PASSWORD);
		return;
	    }

	    // Test if need 2FA auth
	    debug("Checking DOUBLE2FA_CODE: 2faCode value!");
	    String double2faCode = request.getParameter(Parameter.DOUBLE2FA_CODE);
	    if (! awakeCommonsConfigurator.check2faCode(username, double2faCode)) {
		
		// Reduce the login speed
		LoginSpeedReducer loginSpeedReducer = new LoginSpeedReducer(
			username);
		loginSpeedReducer.checkAttempts();
		
		out.println(HttpTransfer.SEND_OK);
		out.println(ReturnCode.INVALID_2FA_CODE);
		return;
	    }
	    
	    debug("Login done!");

	    // OK! Now build a token with SHA-1(username + hostname +
	    // secretValue)
	    String token = awakeCommonsConfigurator.computeAuthToken(username);

	    // out.println(HttpTransfer.SEND_OK + SPACE + ReturnCode.OK + SPACE
	    // + token);
	    out.println(HttpTransfer.SEND_OK);
	    out.println(ReturnCode.OK + SPACE + token);

	} catch (Exception e) {
	    	    	    
	    out.println(HttpTransfer.SEND_FAILED);
	    out.println(e.getClass().getName());
	    out.println(ServerUserException.getMessage(e));	    
	    out.println(ExceptionUtils.getStackTrace(e)); // stack trace
	    
	    try {
		AwakeServerLogger.log(Level.WARNING, Tag.AWAKE_EXCEPTION_RAISED
			    + ServerUserException.getMessage(e));		
		AwakeServerLogger.log(Level.WARNING, Tag.AWAKE_EXCEPTION_RAISED
		    + ExceptionUtils.getStackTrace(e));
	    } catch (Exception e1) {
		e1.printStackTrace();
		e1.printStackTrace(System.out);
	    }

	}
    }

    /**
     * Test if an ip is banned against a list of banned ip
     * 
     * @param ip
     *            the IP address to test
     * @param bannedIp
     *            the list of banned ip
     * 
     * @return true if the ip is banned, else false
     */
    private boolean isIpBanned(String ip, List<String> bannedIp) {
	if (ip == null) {
	    return false;
	}

	if (bannedIp == null) {
	    return false;
	}

	for (String theBannedIp : bannedIp) {
	    if (theBannedIp.contains("/")) {
		IpSubnet ipSubnet = new IpSubnet(theBannedIp);
		if (ipSubnet.contains(ip)) {

		    return true;
		} else {
		    // Nothing
		}
	    } else {
		if (ip.equals(theBannedIp)) {
		    return true;
		}
	    }
	}

	return false;
    }

    private void debug(String s) {
	if (DEBUG) {
	    //AwakeServerLogger.log(s);
	    System.out.println(new Date() + " " + ServerLoginAction.class.getSimpleName() + " " + s);
	}
    }
}
