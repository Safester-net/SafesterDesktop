/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.servlet;

//ServerFileUploadAction.java  
//Copyright (c) Kawan Softwares S.A.S, 2011
//
//Last Updates: 

// 21/05/07 18:35 NDP - Creation
// 06/06/07 19:05 NDP - New Name ZoomingRecv
// 12/06/07 17:20 NDP - add generateNewAuthToken()
// 12/06/07 17:35 NDP - Modify storage directory: is now download/auth_token 
// 10/10/07 20:45 NDP - ServerFileUploadAction: new method name createFile(InputStream inputStream, File file)
// 12/10/10 17:50 NDP : ServerFileUploadAction: all actions on files are dispatched to AwakeFileActionManager
// 15/01/11 20:40 NDP : ServerFileUploadAction: add debug info for file names
// 16/01/11 20:30 NDP : ServerFileUploadAction: filename = HtmlConverter.fromHtml(filename);
// 17/01/11 17:10 NDP : ServerFileUploadAction: back to false in debug
// 12/04/12 17:15 NDP : ServerFileUploadAction: print class name, message & stack trace on servlet output stream
// 03/06/11 20:00 NDP : ServerFileUploadAction: Use Parameter.LOGIN / TOKEN / FILENAME 
// 08/12/11 20:00 NDP : ServerFileUploadAction: no more Base64 decode (only Html)
// 16/02/12 15:50 NDP : ServerFileUploadAction: use AwakeCommonsConfigurator.computeAuthToken()
// 02/04/12 16:20 NDP : ServerFileUploadAction: add Tag.AWAKE_USER_CONFIG_FAIL to exception.getMessage()
//			thrown back to client if exception is thrown by a Configurator

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.awakefw.commons.api.server.AwakeCommonsConfigurator;
import org.awakefw.commons.server.util.AwakeServerLogger;
import org.awakefw.file.api.server.AwakeFileConfigurator;
import org.awakefw.file.api.server.fileaction.AwakeFileActionManager;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.api.util.HtmlConverter;
import org.awakefw.file.http.HttpTransfer;
import org.awakefw.file.http.HttpTransferOne;
import org.awakefw.file.servlet.convert.StreamsEncrypted;
import org.awakefw.file.util.Tag;
import org.awakefw.file.util.parms.Parameter;
import org.awakefw.file.util.parms.ReturnCode;

/**
 * 
 * @author Nicolas de Pomereu
 * 
 *         Upload file name See Word Documentation for help
 */

public class ServerFileUploadAction {
    private static boolean DEBUG = AwakeDebug
	    .isSet(ServerFileUploadAction.class);

    // Max file size
    @SuppressWarnings("unused")
    private static final int MAX_FILE_SIZE = 1024 * 1024 * 20;

    // A space
    public static final String SPACE = " ";

    /**
     * 
     * Execute the dispatched request
     * 
     * @param request
     *            the http request
     * @param response
     *            the http response
     * @param awakeCommonsConfigurator
     *            the client login specific class
     * @param awakeFileActionManager
     *            TODO
     * @throws IOException
     */

    public void executeAction(HttpServletRequest request,
	    HttpServletResponse response,
	    AwakeCommonsConfigurator awakeCommonsConfigurator,
	    AwakeFileConfigurator awakeFileConfigurator,
	    AwakeFileActionManager awakeFileActionManager) throws IOException {
	PrintWriter out = response.getWriter();

	try {
	    String username = null;
	    String token = null;
	    String filename = null;

	    response.setContentType("text/html");
	    // Prepare the response

	    // Check that we have a file upload request
	    boolean isMultipart = ServletFileUpload.isMultipartContent(request);
	    debug("isMultipart: " + isMultipart);

	    if (!isMultipart) {
		return;
	    }

	    // Create a new file upload handler
	    ServletFileUpload upload = new ServletFileUpload();

	    // Parse the request
	    FileItemIterator iter = upload.getItemIterator(request);

	    // Parse the request
	    // List /* FileItem */ items = upload.parseRequest(request);
	    while (iter.hasNext()) {
		FileItemStream item = iter.next();
		String name = item.getFieldName();
		debug("name: " + name);

		// The input Stream for the File
		InputStream stream = item.openStream();

		if (item.isFormField()) {
		    if (name.equals(Parameter.LOGIN)) {
			// username = Streams.asString(stream);
			username = StreamsEncrypted.asString(stream,
				awakeCommonsConfigurator);

			// Not sure it's necessary:
			username = HtmlConverter.fromHtml(username);

			debug("username: " + username);
		    } else if (name.equals(Parameter.TOKEN)) {
			// token = Streams.asString(stream);
			token = StreamsEncrypted.asString(stream,
				awakeCommonsConfigurator);
			debug("token: " + token);
		    } else if (name.equals(Parameter.FILENAME)) {
			// filename = Streams.asString(stream);
			filename = StreamsEncrypted.asString(stream,
				awakeCommonsConfigurator);
			debug("filename: " + filename);
		    }
		} else {
		    
		    
		    if (!isTokenValid(out, username, token,
			    awakeCommonsConfigurator)) // Security check
		    {
			return;
		    }

		    // Not use it's necessary:
		    filename = HtmlConverter.fromHtml(filename);

		    debug("");
		    debug("File field " + name + " with file name "
			    + item.getName() + " detected.");
		    debug("filename: " + filename);

		    awakeFileActionManager.upload(awakeFileConfigurator,
			    stream, username, filename);

		    out.println(HttpTransferOne.SEND_OK);
		    out.println("OK");

		    return;
		}
	    }
	} catch (Exception e) {

	    out.println(HttpTransfer.SEND_FAILED);
	    out.println(e.getClass().getName());
	    out.println(ServerUserException.getMessage(e));	    
	    out.println(ExceptionUtils.getStackTrace(e)); // stack trace
	    
	    try {
		AwakeServerLogger.log(Level.WARNING, Tag.AWAKE_EXCEPTION_RAISED
			    + ServerUserException.getMessage(e));		
		AwakeServerLogger.log(Level.WARNING, Tag.AWAKE_EXCEPTION_RAISED
		    + ExceptionUtils.getStackTrace(e));
	    } catch (Exception e1) {
		e1.printStackTrace();
		e1.printStackTrace(System.out);
	    }

	}

    }

    /**
     * Check the validity of the (username, token) pair
     * 
     * @param out
     *            the out stream
     * @param username
     *            the username to check
     * @param token
     *            the associated token with the login
     * @param awakeCommonsConfigurator
     *            the client commons configurator
     * 
     * @return true if the pair (login, token) is verified and ok.
     * @throws Exception
     */
    private boolean isTokenValid(PrintWriter out, String username,
	    String token, AwakeCommonsConfigurator awakeCommonsConfigurator)
	    throws Exception {

	// OK! Now build a token with SHA-1(username + hostname +
	// secretValue)
	String tokenRecomputed = awakeCommonsConfigurator
		.computeAuthToken(username);

	if (token == null || !token.equals(tokenRecomputed)) {
	    debug("username       : " + username + ":");
	    debug("token          : " + token + ":");
	    debug("tokenRecomputed: " + tokenRecomputed + ":");

	    out.println(HttpTransfer.SEND_OK + SPACE
		    + ReturnCode.INVALID_LOGIN_OR_PASSWORD);
	    return false;
	}

	return true;
    }

    /**
     * return the filename without the trailing / or \\
     * 
     * @param filename
     *            the filename to remove the trailing file separator
     * @return
     */
    public static String removeTrailingFileSep(String filename) {
	if (filename == null) {
	    return null;
	}

	if (filename.startsWith("" + File.separatorChar)) {
	    filename = filename.substring(1);
	}

	return filename;
    }

    private void debug(String s) {
	if (DEBUG) {
	    //AwakeServerLogger.log(s);
	    System.out.println(new Date() + " " + ServerFileUploadAction.class.getSimpleName() + " " + s);
	}
    }

}
