/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */

package org.awakefw.file.http;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.net.Authenticator;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.BatchUpdateException;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.awakefw.commons.api.client.AwakeProgressManager;
import org.awakefw.commons.api.client.HttpProtocolParameters;
import org.awakefw.commons.api.client.HttpProxy;
import org.awakefw.commons.api.client.RemoteException;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.http.exception.HttpTransferInterruptedException;
import org.awakefw.file.util.AwakeFileUtil;
import org.awakefw.file.util.Tag;
import org.awakefw.file.util.convert.BasicNameValuePairConvertor;

import com.kawansoft.httpclient.KawanHttpClient;
import com.kawansoft.httpclient.MultipartUtility;

/**
 * HttpTransferOne - Please note that in implementation, result is read in the
 * send method to be sure to release ASAP the server. <br>
 * 
 * @see com.Kawan Softwares S.A.S.pgp.apispecs.HttpTransfer for usage.
 */

public class HttpTransferOne implements HttpTransfer {
    /** The debug flag */
    private static boolean DEBUG = AwakeDebug.isSet(HttpTransferOne.class);

    /** Universal and clean line separator */
    public static String CR_LF = System.getProperty("line.separator");

    public final static String HTTP_WWW_GOOGLE_COM = "http://www.google.com";

    /** Response from http server container */
    private String m_responseBody = null;

    //
    // Server Parameter
    //
    /** The url to the main controler servlet session */
    private String url = null;

    /** The Http Proxy instance */
    private HttpProxy httpProxy = null;

    /** The Http Parameters instance */
    private HttpProtocolParameters httpProtocolParameters = null;

    /** The awake class tht follows the file transfer */
    private AwakeProgressManager awakeProgressManager = null;

    /** If true, all results will be received in a temp file */
    private boolean doReceiveInFile = false;

    /** The file that contains the result of a http request send() */
    private File receiveFile = null;

    /** The Http Status code of the last send() */
    private int statusCode = 0;

    /**
     * Default constructor.&nbsp;
     * <p>
     * 
     * @param url                    the URL path to the Sql Manager Servlet
     * @param httpProxy              the proxy (may be null for default settings)
     * @param httpProtocolParameters the http protocol supplementary parameters (may
     *                               be null for default settings)
     * @param awakeProgressManager   the Awake Progress Manager may be null for
     *                               default settings
     */
    public HttpTransferOne(String url, HttpProxy httpProxy, HttpProtocolParameters httpProtocolParameters,
	    AwakeProgressManager awakeProgressManager) {

	if (url == null) {
	    throw new IllegalArgumentException("url can not be null!");
	}

	this.url = url;
	this.httpProxy = httpProxy;
	this.httpProtocolParameters = httpProtocolParameters;
	this.awakeProgressManager = awakeProgressManager;

    }

    /**
     * Constructor to use only for for URL download.
     * <p>
     * 
     * @param httpProxy              the proxy (may be null for default settings)
     * @param httpProtocolParameters the http protocol supplementary parameters
     * @param awakeProgressManager   the Awake Progress Manager (may be null for
     *                               default settings)
     */
    public HttpTransferOne(HttpProxy httpProxy, HttpProtocolParameters httpProtocolParameters,
	    AwakeProgressManager awakeProgressManager) {
	this.httpProxy = httpProxy;
	this.httpProtocolParameters = httpProtocolParameters;
	this.awakeProgressManager = awakeProgressManager;
    }

    /**
     * @return the http status code
     */
    public int getHttpStatusCode() {
	return this.statusCode;
    }

    public static KawanHttpClient buildKawanHttpClient(HttpProxy httpProxy) {
	KawanHttpClient kawanHttpClient;
	if (httpProxy == null) {
	    kawanHttpClient = new KawanHttpClient();
	} else {
	    String proxyHostname = httpProxy.getAddress();
	    int proxyPort = httpProxy.getPort();
	    String proxyUserName = httpProxy.getUsername();
	    String proxyPassword = httpProxy.getPassword();

	    Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHostname, proxyPort));

	    if (proxyUserName == null) {
		kawanHttpClient = new KawanHttpClient(proxy, null);
	    } else {
		kawanHttpClient = new KawanHttpClient(proxy,
			new PasswordAuthentication(proxyUserName, proxyPassword.toCharArray()));
	    }
	}
	return kawanHttpClient;
    }

    /**
     * Send a String to the HTTP server.
     * 
     * @param requestParams the request parameters list with (parameter, value)
     * 
     * @throws UnknownHostException Host url (http://www.acme.org) does not exists
     *                              or no Internet Connection.
     * @throws ConnectException     The Host is correct but the Servlet
     *                              (http://www.acme.org/Servlet) failed with a
     *                              status <> OK (200). (if the host is incorrect,
     *                              or is impossible to connect to- Tomcat down -
     *                              will throw a sub exception
     *                              HttpHostConnectException)
     * @throws RemoteException      an exception has been thrown on the server side
     * @throws SecurityException    the url is not secured with https (SSL)
     * @throws IOException          For all other IO / Network / System Error
     */
    public void send(Map<String, String> requestParams)
	    throws UnknownHostException, ConnectException, RemoteException, IOException

    {
	BufferedReader bufferedReader = null;
	File entityContentFile = null;

	// debug("send(requestParams): Using KawanHttpClient!");
	KawanHttpClient kawanHttpClient = buildKawanHttpClient(httpProxy);

	// We need to Html convert & maybe encrypt the parameters
	BasicNameValuePairConvertor basicNameValuePairConvertor = new BasicNameValuePairConvertor(requestParams,
		httpProtocolParameters);
	requestParams = basicNameValuePairConvertor.convert();

	// debug("requestParams : " + requestParams);
	// debug("requestParams.length: " + requestParams.toString().length());

	String result = kawanHttpClient.callWithPost(new URL(url), requestParams);
	statusCode = kawanHttpClient.getHttpStatusCode();

	if (statusCode != HttpURLConnection.HTTP_OK) {
	    // The server is up, but the servlet is not accessible
	    throw new ConnectException(url + ": Servlet failed with status code: " + statusCode);
	}

	// Get immediately the content as input stream
	// do *NOT* use a buffered stream ==> Will fail with SSL handshakes!
	try {
	    entityContentFile = createAwakeTempFile();
	    FileUtils.write(entityContentFile, result);

	    // Read content of first line.
	    bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(entityContentFile)));

	    // line 1: Contains the request status - line 2: Contains the datas
	    String awakeStatus = bufferedReader.readLine();
	    // debug("awakeStatus : " + awakeStatus);

	    if (doReceiveInFile) {
		// Content is saved back into a file, minus the first line
		// status
		receiveFile = createAwakeTempFile();
		copyResponseIntoFile(bufferedReader, receiveFile);
	    } else {
		int maxLengthForString = HttpProtocolParameters.DEFAULT_MAX_LENGTH_FOR_STRING;
		if (httpProtocolParameters != null) {
		    maxLengthForString = httpProtocolParameters.getMaxLengthForString();
		}

		if (entityContentFile.length() > maxLengthForString) {
		    throw new IOException("Response too big for String: > " + maxLengthForString + " bytes.");
		}

		copyResponseIntoString(bufferedReader);
	    }

	    // Analyze applicative response header
	    // "SEND_OK"
	    // "SEND_FAILED"

	    if (awakeStatus.startsWith(SEND_OK)) {
		return; // OK!
	    } else if (awakeStatus.startsWith(SEND_FAILED)) {
		BufferedReader bufferedReaderException = null;

		try {
		    // We must throw the remote exception
		    if (doReceiveInFile) {
			bufferedReaderException = new BufferedReader(new FileReader(receiveFile));
			throwTheRemoteException(bufferedReaderException);
		    } else {
			bufferedReaderException = new BufferedReader(new StringReader(m_responseBody));
			throwTheRemoteException(bufferedReaderException);
		    }
		} finally {
		    IOUtils.closeQuietly(bufferedReaderException);

		    if (doReceiveInFile && !DEBUG) {
			receiveFile.delete();
		    }
		}
	    } else {
		// debug("m_responseBody: " + m_responseBody + ":");
		throw new IOException(
			Tag.AWAKE_PRODUCT_FAIL + "Response message does not start with SEND_OK or SEND_FAILED!");
	    }
	} finally {
	    IOUtils.closeQuietly(bufferedReader);

	    if (entityContentFile != null) {
		entityContentFile.delete();
	    }
	}
    }

    /**
     * Send a String to the HTTP server using receive httpServerProgram Servlet and
     * download a file
     * 
     * @param requestParams the request parameters list with (parameter, value)
     * @param fileLength    the file length (for the progress indicator). If 0, will
     *                      not be used
     * @param file          the file to create on the client side (PC)
     * 
     * @throws IllegalArgumentException if the file to download is null
     * @throws UnknownHostException     Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws ConnectException         The Host is correct but the Servlet
     *                                  (http://www.acme.org/Servlet) failed with a
     *                                  status <> OK (200).
     * @throws IOException              For all other IO / Network / System Error
     */
    @Override
    public void download(Map<String, String> requestParams, File file)
	    throws IllegalArgumentException, UnknownHostException, ConnectException, RemoteException, IOException {

	InputStream in = null;
	OutputStream out = null;

	debug("downloadNew(requestParams, file): Using KawanHttpClient!");
	KawanHttpClient kawanHttpClient = buildKawanHttpClient(httpProxy);

	if (file == null) {
	    throw new IllegalArgumentException("file to create can not be null!");
	}

	// We need to Html convert & maybe encrypt the parameters
	BasicNameValuePairConvertor basicNameValuePairConvertor = new BasicNameValuePairConvertor(requestParams,
		httpProtocolParameters);
	requestParams = basicNameValuePairConvertor.convert();

	debug("requestParams       : " + requestParams);
	debug("requestParams.length: " + requestParams.toString().length());

	try {
	    in = kawanHttpClient.callWithPostReturnInputStream(new URL(url), requestParams);

	    statusCode = kawanHttpClient.getHttpStatusCode();

	    if (statusCode != HttpURLConnection.HTTP_OK) {
		// The server is up, but the servlet is not accessible
		throw new ConnectException(url + ": Servlet failed with status code: " + statusCode);
	    }

	    out = new BufferedOutputStream(new FileOutputStream(file));

	    int downloadBufferSize = HttpProtocolParameters.DEFAULT_DOWNLOAD_BUFFER_SIZE;

	    if (httpProtocolParameters != null) {
		downloadBufferSize = httpProtocolParameters.getDownloadBufferSize();
	    }

	    byte[] buf = new byte[downloadBufferSize];
	    int len;

	    int tempLen = 0;
	    // setOwnerNote(message);

	    long filesLength = 0;
	    if (awakeProgressManager != null) {
		filesLength = awakeProgressManager.getLengthToTransfer();
	    }

	    debug("before while ((len = in.read(buf)) > 0) { - filesLength: " + filesLength);
	    debug("");
	    long totallen = 0;

	    while ((len = in.read(buf)) > 0) {
		tempLen += len;

		if (filesLength > 0 && tempLen > filesLength / MAXIMUM_PROGRESS_100) {
		    tempLen = 0;
		    try {
			Thread.sleep(10);
		    } catch (InterruptedException e) {
			e.printStackTrace();
		    }
		    addOneToAwakeProgressManager(); // For ProgressMonitor
						    // progress bar
		}

		// if (isAwakeProgressManagerInterrupted()) {
		// throw new InterruptedException();
		// }

		if (isAwakeProgressManagerInterrupted()) {
		    throw new HttpTransferInterruptedException(Tag.AWAKE + "File download interrupted by user.");
		}

		totallen += len;

		debug("out.write(buf, 0, len); - totallen: " + totallen);

		out.write(buf, 0, len);
	    }

	    debug("before IOUtils.closeQuietly(out);");

	    // Close now, we will reuse file in setStatusAfterDownload
	    IOUtils.closeQuietly(out);

	    // Sets the status after the file download
	    analyseStatusAfterDownload(file);

	} finally {
	    IOUtils.closeQuietly(in);
	    IOUtils.closeQuietly(out);
	}
    }

    /**
     * Create a File from a remote URL.
     * 
     * @param url  the url of the site. Example http://www.yahoo.com
     * @param file the file to create from the download.
     * 
     * @throws IllegalArgumentException if the url or the file is null
     * @throws UnknownHostException     Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * @throws FileNotFoundException    Impossible to connect to the Host. May
     *                                  appear if, for example, the Web server is
     *                                  down. (Tomcat down ,etc.)
     * @throws IOException              For all other IO / Network / System Error
     * @throws InterruptedException     if download is interrupted by user through
     *                                  an AwakeProgressManager
     */

    public void downloadUrl(URL url, File file)
	    throws IllegalArgumentException, UnknownHostException, FileNotFoundException, IOException

    {
	if (file == null) {
	    throw new IllegalArgumentException("file can not be null!");
	}

	if (url == null) {
	    throw new IllegalArgumentException("url can not be null!");
	}

	debug("downloadUrl(url, file): Using KawanHttpClient!");
	KawanHttpClient kawanHttpClient = buildKawanHttpClient(httpProxy);

	statusCode = 0; // Reset it!

	InputStream in = null;
	OutputStream out = null;

	LineNumberReader lineNumberReader = null;

	try {
	    in = kawanHttpClient.callWithGetReturnStream(url.toString());

	    statusCode = kawanHttpClient.getHttpStatusCode();

	    if (statusCode != HttpURLConnection.HTTP_OK) {
		// The server is up, but the servlet is not accessible
		throw new ConnectException(url + ": Servlet failed with status code: " + statusCode);
	    }

	    out = new BufferedOutputStream(new FileOutputStream(file));

	    byte[] buf = new byte[4096];
	    int len;

	    int tempLen = 0;

	    long filesLength = 0;
	    if (awakeProgressManager != null) {
		filesLength = awakeProgressManager.getLengthToTransfer();
	    }

	    while ((len = in.read(buf)) > 0) {
		tempLen += len;

		if (filesLength > 0 && tempLen > filesLength / MAXIMUM_PROGRESS_100) {
		    tempLen = 0;
		    try {
			Thread.sleep(10);
		    } catch (InterruptedException e) {
			e.printStackTrace();
		    }
		    addOneToAwakeProgressManager(); // For ProgressMonitor
						    // progress bar
		}

		// if (isAwakeProgressManagerInterrupted()) {
		// throw new InterruptedException();
		// }

		if (isAwakeProgressManagerInterrupted()) {
		    throw new HttpTransferInterruptedException(Tag.AWAKE + "File download interrupted by user.");
		}

		out.write(buf, 0, len);
	    }

	    // We suppose the download is ok:
	    // m_isSendOk = true;

	} finally {
	    IOUtils.closeQuietly(out);
	    IOUtils.closeQuietly(in);
	    IOUtils.closeQuietly(lineNumberReader);
	}

    }

    /**
     * Create a File from a remote URL.
     * 
     * @param url  the url of the site. Example http://www.yahoo.com
     * @param file the file to create from the download.
     * 
     * @throws IllegalArgumentException if the url or the file is null
     * @throws UnknownHostException     Host url (http://www.acme.org) does not
     *                                  exists or no Internet Connection.
     * 
     * @throws IOException              For all other IO / Network / System Error
     */
    @Override
    public String getUrlContent(URL url) throws IllegalArgumentException, UnknownHostException, IOException

    {
	if (url == null) {
	    throw new IllegalArgumentException("url can not be null!");
	}

	debug("getUrlContent(url, file): Using KawanHttpClient!");
	KawanHttpClient kawanHttpClient = buildKawanHttpClient(httpProxy);

	statusCode = 0; // Reset it

	// Execute the request and analyze the error

	String content = kawanHttpClient.callWithGet(url.toString());
	statusCode = kawanHttpClient.getHttpStatusCode();

	if (statusCode != HttpURLConnection.HTTP_OK) {
	    // The server is up, but the servlet is not accessible
	    throw new ConnectException(url + ": Servlet failed with status code: " + statusCode);
	}

	return content;

    }

    /*
     * public HttpClient buildHttpClientForProxy(HttpProxy httpProxy) {
     * 
     * // 1) No Proxy if (httpProxy == null) { return new DefaultHttpClient(); }
     * 
     * throw new IllegalAccessError("Not implemented yet!"); /* // 2) Proxy with no
     * Auth if (httpProxy.getUsername() == null) { HttpHost proxy = new
     * HttpHost(httpProxy.getAddress(), httpProxy.getPort());
     * DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
     * HttpClient httpclient =
     * HttpClients.custom().setRoutePlanner(routePlanner).build(); return
     * httpclient; }
     * 
     * // 3) Proxy with Auth & Client credentials HttpHost proxy = new
     * HttpHost(httpProxy.getAddress(), httpProxy.getPort());
     * DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
     * CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
     * credentialsProvider.setCredentials(new AuthScope(proxy), new
     * UsernamePasswordCredentials(httpProxy.getUsername(),
     * httpProxy.getPassword()));
     * 
     * // Create AuthCache instance AuthCache authCache = new BasicAuthCache();
     * 
     * BasicScheme basicAuth = new BasicScheme(); authCache.put(proxy, basicAuth);
     * HttpClientContext context = HttpClientContext.create();
     * context.setCredentialsProvider(credentialsProvider);
     * context.setAuthCache(authCache);
     * 
     * HttpClient httpclient = HttpClients.custom().setRoutePlanner(routePlanner)
     * .setDefaultCredentialsProvider(credentialsProvider).build(); return
     * httpclient; }
     */

//    /**
//     * Immediately Save the entity content into file and release it
//     * 
//     * @param entityContentFile
//     *            the file where to save the entigy content
//     * @param entity
//     *            the http entity
//     * @throws IOException
//     * @throws IllegalStateException
//     * @throws FileNotFoundException
//     */
//    private void saveEntityContentToFile(File entityContentFile,
//	    HttpEntity entity) throws IOException, IllegalStateException,
//	    FileNotFoundException {
//	InputStream in;
//	in = entity.getContent();
//	BufferedOutputStream out = new BufferedOutputStream(
//		new FileOutputStream(entityContentFile));
//
//	try {
//	    IOUtils.copy(in, out);
//	} finally {
//	    IOUtils.closeQuietly(in);
//	    IOUtils.closeQuietly(out);
//	}
//    }

    /**
     * Send a String to the HTTP server and upload a file
     * 
     * @param requestParams the request parameters list with (parameter, value)
     * @param file          the file to upload
     * 
     * @throws UnknownHostException Host url (http://www.acme.org) does not exists
     *                              or no Internet Connection.
     * @throws ConnectException     The Host is correct but the Servlet
     *                              (http://www.acme.org/Servlet) failed with a
     *                              status <> OK (200). (if the host is incorrect,
     *                              or is impossible to connect to- Tomcat down -
     *                              will throw a sub exception
     *                              HttpHostConnectException)
     * @throws RemoteException      an exception has been thrown on the server side
     * @throws SecurityException    the url is not secured with https (SSL)
     * @throws IOException          For all other IO / Network / System Error
     */

    public void send(Map<String, String> requestParams, File file)
	    throws UnknownHostException, ConnectException, RemoteException, IOException {

	BufferedReader bufferedReader = null;
	File entityContentFile = null;

	if (file == null) {
	    throw new NullPointerException("file is null");
	}

	if (!file.exists()) {
	    throw new FileNotFoundException("file does not exist: " + file);
	}

	// We need to Html convert & maybe encrypt the parameters
	BasicNameValuePairConvertor basicNameValuePairConvertor = new BasicNameValuePairConvertor(requestParams,
		httpProtocolParameters);
	requestParams = basicNameValuePairConvertor.convert();

	InputStream in = null;

	try {

	    in = new FileInputStream(file);

	    URL theURL = new URL(url);

	    // trace("request : " + theURL);
	    HttpURLConnection conn = null;

	    Proxy proxy = null;

	    if (httpProxy != null) {
		proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(httpProxy.getAddress(), httpProxy.getPort()));
	    }

	    setCredentials(httpProxy);

	    if (proxy == null) {
		conn = (HttpURLConnection) theURL.openConnection();
	    } else {
		conn = (HttpURLConnection) theURL.openConnection(proxy);
	    }

	    conn.setRequestProperty("Accept-Charset", "UTF-8");
	    // conn.setRequestProperty("Connection", "Keep-Alive");
	    // conn.setRequestProperty("User-Agent", "Android Multipart HTTP Client 1.0");
	    conn.setRequestMethod("POST");
	    conn.setReadTimeout(KawanHttpClient.getReadTimeout());
	    conn.setDoOutput(true);
	    conn.setChunkedStreamingMode(4096 * 10);

	    final MultipartUtility http = new MultipartUtility(theURL, conn, KawanHttpClient.getConnectTimeout(),
		    awakeProgressManager);

//	    for (BasicNameValuePair basicNameValuePair : requestParams) {
//		String key = basicNameValuePair.getName();
//		String value = basicNameValuePair.getValue();
//	    }

	    for (Map.Entry<String, String> entry : requestParams.entrySet()) {
		String key = entry.getKey();
		String value = entry.getValue();
		http.addFormField(key, value);
	    }

	    // Server needs a unique file name to store the blob
	    String fileName = file.getName();

	    try {
		http.addFilePart("file", in, fileName);
	    } catch (InterruptedException e) {
		throw new IOException(e);
	    }

	    debug("Uploading file with http.finish()....");
	    http.finish();

	    conn = http.getConnection();

	    // Analyze the error after request execution
	    statusCode = conn.getResponseCode();
	    String httpStatusMessage = conn.getResponseMessage();

	    debug("Done Uploading statusCode: " + statusCode);
	    debug("httpStatusMessage        : " + httpStatusMessage);

	    InputStream inConn = null;

	    String result;

	    if (statusCode == HttpURLConnection.HTTP_OK) {
		inConn = conn.getInputStream();
	    } else {
		inConn = conn.getErrorStream();
	    }

	    result = null;

	    if (inConn != null) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		IOUtils.copy(inConn, out);
		result = out.toString("UTF-8");
	    }

	    entityContentFile = createAwakeTempFile();
	    FileUtils.write(entityContentFile, result);

	    // Read content of first line.
	    bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(entityContentFile)));

	    // line 1: Contains the request status - line 2: Contains the datas
	    String awakeStatus = bufferedReader.readLine();
	    debug("awakeStatus        : " + awakeStatus);

	    if (doReceiveInFile) {
		// Content is saved back into a file, minus the first line
		// status
		receiveFile = createAwakeTempFile();
		copyResponseIntoFile(bufferedReader, receiveFile);
	    } else {
		int maxLengthForString = HttpProtocolParameters.DEFAULT_MAX_LENGTH_FOR_STRING;
		if (httpProtocolParameters != null) {
		    maxLengthForString = httpProtocolParameters.getMaxLengthForString();
		}

		if (entityContentFile.length() > maxLengthForString) {
		    throw new IOException("Response too big for String: > " + maxLengthForString + " bytes.");
		}

		copyResponseIntoString(bufferedReader);
	    }

	    // Analyze applicative response header
	    // "SEND_OK"
	    // "SEND_FAILED"

	    if (awakeStatus.startsWith(SEND_OK)) {
		return; // OK!
	    } else if (awakeStatus.startsWith(SEND_FAILED)) {
		BufferedReader bufferedReaderException = null;

		try {
		    // We must throw the remote exception
		    if (doReceiveInFile) {
			bufferedReaderException = new BufferedReader(new FileReader(receiveFile));
			throwTheRemoteException(bufferedReaderException);
		    } else {
			bufferedReaderException = new BufferedReader(new StringReader(m_responseBody));
			throwTheRemoteException(bufferedReaderException);
		    }
		} finally {
		    IOUtils.closeQuietly(bufferedReaderException);

		    if (doReceiveInFile && !DEBUG) {
			receiveFile.delete();
		    }
		}
	    } else {
		debug("m_responseBody: " + m_responseBody + ":");
		throw new IOException(
			Tag.AWAKE_PRODUCT_FAIL + "Response message does not start with SEND_OK or SEND_FAILED!");
	    }

	} finally {
	    IOUtils.closeQuietly(in);
	    IOUtils.closeQuietly(bufferedReader);

	    if (entityContentFile != null) {
		entityContentFile.delete();
	    }
	}
    }

    private void setCredentials(HttpProxy httpProxy2) {

	if (httpProxy2 == null) {
	    return;
	}

	// Sets the credential for authentication
	if (httpProxy2.getUsername() != null) {
	    final String proxyAuthUsername = httpProxy2.getUsername();
	    final char[] proxyPassword = httpProxy2.getPassword().toCharArray();

	    Authenticator authenticator = new Authenticator() {

		@Override
		public PasswordAuthentication getPasswordAuthentication() {
		    return new PasswordAuthentication(proxyAuthUsername, proxyPassword);
		}
	    };

	    if (DEBUG) {
		System.out.println("passwordAuthentication: " + proxyAuthUsername + " " + new String(proxyPassword));
	    }

	    Authenticator.setDefault(authenticator);
	} else {
	    Authenticator.setDefault(null);
	}

    }

    /**
     * 
     * Throws an Exception
     * 
     * @param bufferedReader the reader that contains the remote thrown exception
     * 
     * @throws IOException
     * @throws RemoteException
     * @throws SecurityException
     */
    public static void throwTheRemoteException(BufferedReader bufferedReader) throws RemoteException, IOException {

	String exceptionName = bufferedReader.readLine();

	if (exceptionName.equals("null")) {
	    exceptionName = null;
	}

	if (exceptionName == null) {
	    throw new IOException(
		    Tag.AWAKE_PRODUCT_FAIL + "Remote Exception type/name not found in servlet output stream");
	}

	String message = bufferedReader.readLine();

	if (message.equals("null")) {
	    message = null;
	}

	StringBuffer sb = new StringBuffer();

	String line = null;
	while ((line = bufferedReader.readLine()) != null) {
	    // All subsequent lines contain the result
	    sb.append(line);
	    sb.append(CR_LF);
	}

	String remoteStackTrace = null;

	if (sb.length() > 0) {
	    remoteStackTrace = sb.toString();
	}

	// Ok, build the authorized Exception
	if (exceptionName.contains(Tag.ClassNotFoundException)) {
	    throw new RemoteException(message, new ClassNotFoundException(message), remoteStackTrace);
	} else if (exceptionName.contains(Tag.InstantiationException)) {
	    throw new RemoteException(message, new InstantiationException(message), remoteStackTrace);
	} else if (exceptionName.contains(Tag.NoSuchMethodException)) {
	    throw new RemoteException(message, new NoSuchMethodException(message), remoteStackTrace);
	} else if (exceptionName.contains(Tag.InvocationTargetException)) {
	    throw new RemoteException(message, new InvocationTargetException(new Exception(message)), remoteStackTrace);
	}
	//
	// SQL Exceptions
	//
	else if (exceptionName.contains(Tag.SQLException)) {
	    throw new RemoteException(message, new SQLException(message), remoteStackTrace);
	} else if (exceptionName.contains(Tag.BatchUpdateException)) {
	    throw new RemoteException(message, new BatchUpdateException(), remoteStackTrace);
	}

	//
	// Awake Security Failure
	//
	else if (exceptionName.contains(Tag.SecurityException)) {
	    // throw new RemoteException(message, new
	    // SecurityException(message), remoteStackTrace);
	    throw new SecurityException(message);
	}

	//
	// IOExceptions
	//
	else if (exceptionName.contains(Tag.FileNotFoundException)) {
	    throw new RemoteException(message, new FileNotFoundException(message), remoteStackTrace);
	} else if (exceptionName.contains(Tag.IOException)) {
	    throw new RemoteException(message, new IOException(message), remoteStackTrace);
	}

	//
	// Awake Failure: these errors should never be thrown by Awake File and
	// Awake SQL server :
	// - NullPointerException
	// - IllegalArgumentException
	//
	else if (exceptionName.contains(Tag.NullPointerException)) {
	    throw new RemoteException(message, new NullPointerException(message), remoteStackTrace);
	} else if (exceptionName.contains(Tag.IllegalArgumentException)) {
	    throw new RemoteException(message, new IllegalArgumentException(message), remoteStackTrace);
	} else {
	    // All other cases ==> IOException with no cause
	    throw new RemoteException("Remote " + exceptionName + ": " + message, new IOException(message),
		    remoteStackTrace);
	}

    }

    /**
     * Copy the response into a string
     * 
     * @param bufferedReader the buffered content of the centiy, minus the first
     *                       line
     * @throws IOException
     */
    private void copyResponseIntoString(BufferedReader bufferedReader) throws IOException {

	StringBuffer sb = new StringBuffer();

	String line = null;
	while ((line = bufferedReader.readLine()) != null) {
	    // All subsequent lines contain the result
	    sb.append(line);
	    sb.append(CR_LF);
	}
	m_responseBody = sb.toString();
	debug("m_responseBody: " + m_responseBody + ":");
    }

    /**
     * Transform the response stream into a file
     * 
     * @param bufferedReader the input response stream as line reader
     * @param file           the output file to create
     * 
     * @throws IOException if any IOException occurs during the process
     */
    private void copyResponseIntoFile(BufferedReader bufferedReader, File file) throws IOException {
	BufferedOutputStream out = null;

	try {
	    out = new BufferedOutputStream(new FileOutputStream(file));
	    String line = null;
	    while ((line = bufferedReader.readLine()) != null) {
		// All subsequent lines contain the result
		out.write((line + CR_LF).getBytes());
	    }
	    out.flush();
	} finally {
	    IOUtils.closeQuietly(out);
	}

    }

    /**
     * Sets the status after the file download
     * 
     * @param file the downloaded file
     */
    private void analyseStatusAfterDownload(File file) throws RemoteException, IOException {
	LineNumberReader lineNumberReader = null;
	InputStream in = null;

	try {
	    in = new BufferedInputStream(new FileInputStream(file));

	    byte[] statusAsBytes = new byte[SEND_OK.length()];
	    int readBytes = in.read(statusAsBytes);

	    String readStr = new String(statusAsBytes);

	    debug("readStr  : " + readStr);
	    debug("readBytes: " + readBytes);

	    // Nothing to read (should not happen, except for empty files...)
	    if (readBytes < SEND_OK.length()) {
		return;
	    }

	    // SEND_OK may happen if: 1) Invalid Login 2) FileNotFound

	    if ((readStr != null) && readStr.startsWith(SEND_OK)) {
		IOUtils.closeQuietly(in);

		BufferedReader bufferedReader = new BufferedReader(new FileReader(file));

		try {
		    bufferedReader.readLine(); // Read The status line
		    m_responseBody = bufferedReader.readLine();
		    debug("m_responseBody: " + m_responseBody);
		} finally {
		    IOUtils.closeQuietly(bufferedReader);

		    if (!DEBUG) {
			file.delete();
		    }
		}

	    }
	    // SEND_FAILED contains thrown Exceptions:
	    else if ((readStr != null) && readStr.startsWith(SEND_FAILED)) {
		IOUtils.closeQuietly(in);

		BufferedReader bufferedReaderException = new BufferedReader(new FileReader(file));

		try {
		    throwTheRemoteException(bufferedReaderException);
		} finally {
		    IOUtils.closeQuietly(bufferedReaderException);

		    if (!DEBUG) {
			file.delete();
		    }
		}

	    }

	} finally {
	    IOUtils.closeQuietly(in);
	    IOUtils.closeQuietly(lineNumberReader);

	}
    }

    /**
     * Create our own Awake temp file
     * 
     * @return the tempfile to create with ".awake" prefix in the java.io.tmpdir
     *         directory
     */
    private synchronized File createAwakeTempFile() {
	String unique = AwakeFileUtil.getUniqueId();
	String tempDir = AwakeFileUtil.getAwakeTempDir();
	String tempFile = tempDir + File.separator + "http-transfer-one-" + unique + ".awake.txt";

	return new File(tempFile);
    }

    /**
     * @return true is there is an owner AND it's interrupted
     */
    private boolean isAwakeProgressManagerInterrupted() {
	if (awakeProgressManager == null) {
	    return false;
	}

	return awakeProgressManager.isCancelled();
    }

    /**
     * Set the owner current value for progression bar
     * 
     * @param current
     */
    private void addOneToAwakeProgressManager() {
	if (awakeProgressManager != null) {
	    int current = awakeProgressManager.getProgress();
	    current++;

	    // awakeProgressManager.setProgress(current);
	    if (current < HttpTransfer.MAXIMUM_PROGRESS_100) {
		awakeProgressManager.setProgress(current);
	    }
	}
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.Kawan Softwares S.A.S.pgp.apispecs.HttpTransfer#recv()
     */
    public String recv() {
	if (m_responseBody == null) {
	    m_responseBody = "";
	}

	m_responseBody = m_responseBody.trim();
	return m_responseBody;
    }

    /**
     * Defines if the result is to be received into a text file <br>
     * Call getReceiveFile() to get the file name <br>
     * Defaults to false.
     * 
     * @param receiveInFile if true, the result will be defined in a file
     */
    public void setReceiveInFile(boolean doReceiveInFile) {
	this.doReceiveInFile = doReceiveInFile;
    }

    /**
     * @return the receiveFile
     */
    public File getReceiveFile() {
	return receiveFile;
    }

    /**
     * debug tool
     */
    private static void debug(String s) {
	if (DEBUG) {
	    System.out.println(new Date() + " " + HttpTransferOne.class.getSimpleName() + " " + s);
	}
    }

}
