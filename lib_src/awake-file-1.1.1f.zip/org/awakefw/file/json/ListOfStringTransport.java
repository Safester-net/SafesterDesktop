/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.json;

import java.lang.reflect.Type;
import java.util.List;

import org.awakefw.file.api.util.AwakeDebug;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * @author Nicolas de Pomereu
 * 
 *         Class to transport a list of strings with JSON from the PC side.
 *         Because obsfucation creates toubles, this class must never obsfucated
 */

public class ListOfStringTransport {

    /** For debug info */
    private static boolean DEBUG = AwakeDebug.isSet(ListOfStringTransport.class);

    /**
     * Format for JSON String a list of strings
     * 
     * @param list
     *            a list of strings
     * 
     * @return the formated JSON string ready for transport
     */

    public static String toJson(ListHolder listHolder) {
	List<String> list = listHolder.getList();

	if (list == null) {
	    throw new IllegalArgumentException("list is null!");
	}

	// See http://sites.google.com/site/gson/gson-user-guide
	Gson gson = new Gson();
	Type listOfStringsType = new TypeToken<List<String>>() {
	}.getType();
	String jsonString = gson.toJson(list, listOfStringsType);

	debug("List jsonString: " + jsonString);
	return jsonString;
    }


    /**
     * Format from JSON string a list of strings - TO BE USED ONLY ON THE SERVER
     * SIDE;
     * 
     * @param jsonString
     *            formated JSON string containing a list of strings
     * 
     * @return a list of strings
     */
    public static List<String> fromJson(String jsonString) {
        if (jsonString == null) {
            throw new IllegalArgumentException("jsonString is null!");
        }
    
        debug("List jsonString: " + jsonString);
    
        // See http://sites.google.com/site/gson/gson-user-guide
        Gson gson = new Gson();
        Type listOfStringsType = new TypeToken<List<String>>() {
        }.getType();
        List<String> list = gson.fromJson(jsonString, listOfStringsType);
        return list;
    }

    private static void debug(String s) {
	if (DEBUG) {
	    // AwakeFileLogger.log(s);
	    System.out.println(s);
	}
    }

    
}
