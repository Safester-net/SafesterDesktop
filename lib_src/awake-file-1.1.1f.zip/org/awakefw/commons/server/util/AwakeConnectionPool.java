/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.server.util;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.Date;
import java.util.Properties;

import org.awakefw.commons.api.server.AwakeCommonsConfigurator;
import org.awakefw.commons.api.server.DefaultAwakeCommonsConfigurator;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.util.Tag;


/**
 * 
 * Class that will build a Connection Pool of JDBC Connections and allow to
 * retrieve Connections at demand when using Awake services.
 * <p>
 * This class defines a default implementation of a Connection Pool for Awake
 * services. This implementation will be used by
 * {@link DefaultAwakeCommonsConfigurator}.
 * <p>
 * The default Connection Pool used is dbConnectionBroker from <a
 * href="http://www.javaexchange.com">www.javaexchange.com</a>.
 * <p>
 * Note: you may of course define and use any Connection Pooling mechanism in
 * Awake with your own implementation of {@link AwakeCommonsConfigurator}.
 * <p>
 * 
 * @see AwakeCommonsConfigurator <p>
 * @since 1.0
 */

public final class AwakeConnectionPool {
    private static boolean DEBUG = AwakeDebug.isSet(AwakeConnectionPool.class);
    
    /** The private instance of DbConnectionBroker */
    private DbConnectionBroker dbConnectionbroker = null;
    
    // Mandatory parameters
    private String username = null;
    private String password = null;
    private String driverClassName = null;
    private String url = null;
    private int minConns = 15;
    private int maxConns = 30;
    
    // Non mandatory parameters
    private double maxConnTime = 0;
    private File logFile = null;
    private int maxCheckoutSeconds = 0;
    private boolean logAppend = false;
    
    /**
     * 
     * Constructor
     * 
     * @param driverClassName
     *            the JDBC driver class name
     * @param url
     *            the URL to pass to the JDBC Driver
     * @param username
     *            the database username
     * @param password
     *            the database password
     * @param minConns
     *            the minimum number of Connections to open at startup
     * @param maxConns
     *            the maximum number of Connections to be created by the pool
     *            manager
     * @param maxConnTime
     *            the connection cycle life in days
     * @param maxCheckoutSeconds
     *            maximum time in seconds a <code>Connection</code> can be
     *            checked out before being recycled. This value is thus the
     *            maximum duration of a SQL request. Default value is 180
     *            seconds. Zero value turns option off.
     * @param logAppend
     *            says if log is in append mode
     * @param logFile
     *            the log file to use
     */
    public AwakeConnectionPool(String driverClassName, String url,
	    String username, String password, int minConns, int maxConns,
	    double maxConnTime, int maxCheckoutSeconds, boolean logAppend, File logFile) throws SQLException {
	this.username = username;
	this.password = password;
	this.driverClassName = driverClassName;
	this.url = url;
	this.minConns = minConns;
	this.maxConns = maxConns;
	
	this.maxCheckoutSeconds = maxCheckoutSeconds;
	this.logAppend = logAppend;
	
	if (this.url == null) {
	    throw new IllegalArgumentException(Tag.AWAKE_USER_CONFIG_FAIL + "url can not ne null!");
	}

	if (this.username == null) {
	    throw new IllegalArgumentException(Tag.AWAKE_USER_CONFIG_FAIL
		    + "username can not ne null!");
	}

	if (this.password == null) {
	    throw new IllegalArgumentException(Tag.AWAKE_USER_CONFIG_FAIL + "password can not ne null!");
	}	
	
	if (this.minConns == 0) {
	    throw new IllegalArgumentException(Tag.AWAKE_USER_CONFIG_FAIL + "minConns must be >= 1");
	}	
	
	if (this.maxConns < minConns) {
	    throw new IllegalArgumentException(Tag.AWAKE_USER_CONFIG_FAIL + "maxConns must be >= minConns");
	}		
	
	if (maxConnTime <= 0)
	{
	    this.maxConnTime = 1;
	}
	else
	{
	    this.maxConnTime = maxConnTime;
	}
	
	if (logFile == null) {	    
	    throw new IllegalArgumentException(Tag.AWAKE_PRODUCT_FAIL + "logFile can not be null!");
	}	
	
	this.logFile = logFile;
		
	try {
	    startDbConnectionBroker();
	} catch (IOException e) {
	    throw new SQLException(e);
	}

	
    }
   
    /**
     * Destroys the DbConnectionBroker Server server and reset it completely
     * for new usage
     */
    public void stop() {
	dbConnectionbroker.destroy();
	dbConnectionbroker = null;
	
    }

    /**
     * Starts the DbConnectionBroker server and create a static instance of it
     * 
     * @throws SQLException
     *             if any SQL Exception occurs when loading the Driver
     *             IOException if any IO exception occurs when logging
     */
    private void startDbConnectionBroker() throws SQLException, IOException {

	Connection connection = null;
	
	try {

	    debug("In startDbConnectionBroker():");
	    debug("driverClassName :" + driverClassName + ":");
	    debug("url             :" + url + ":");
	    debug("username        :" + username + ":");
	    debug("password        :" + password + ":");
	    	    
	    Class<?> c = Class.forName(driverClassName);
	    Driver driver = (Driver) c.newInstance();

	    Properties properties = new Properties();
	    properties.put("user", username);
	    properties.put("password", password);    
	    
	    connection = driver.connect(url, properties);
 	   
	    if (connection == null) {
		throw new NullPointerException("driver.connect(url, properties) returns null for url: " 
			+ url + " and user: " + username);
	    }	    
	    
	} catch (NullPointerException e) {
	    throw new SQLException(Tag.AWAKE_USER_CONFIG_FAIL + "Error configuring JDBC Driver: " + e.getMessage());	    
	} catch (SQLException e) {
	    throw new SQLException(Tag.AWAKE_USER_CONFIG_FAIL + "Error configuring JDBC Driver: " + e.getMessage(), e);
	} catch (ClassNotFoundException e) {
	    throw new SQLException(Tag.AWAKE_USER_CONFIG_FAIL + "Error configuring JDBC Driver. Driver class not found for driverClassName: "
		    + driverClassName);
	} catch (InstantiationException e) {
	    throw new SQLException(Tag.AWAKE_USER_CONFIG_FAIL
		    + "Driver class can not be instanced: " + driverClassName);
	} catch (IllegalAccessException e) {
	    throw new SQLException(Tag.AWAKE_USER_CONFIG_FAIL
		    + "Driver class can not be accessed: " + driverClassName);
	}
	finally {
	    if (connection != null) {
		connection.close();
	    }
	}

	debug("STARTING A NEW DbConnectionBroker...");
	
	dbConnectionbroker = new DbConnectionBroker(driverClassName, url,
		username, password, minConns, maxConns,
		logFile.toString(), maxConnTime, logAppend, maxCheckoutSeconds, DbConnectionBroker.DEFAULTDEBUGLEVEL);
	
	debug("DbConnectionBroker STARTED! (" + driverClassName + ", " + url + ")");
    }

    /**
     * Returns a new Connection extracted from the Pool.
     * 
     * @return a new Connection extracted from the Pool
     * 
     * @throws SQLException
     *             if any SQL Exception occurs
     */
    public Connection getConnection() throws SQLException {
	// Wrap the Connection into a PooledConnection
	Connection connection = new PooledConnection(dbConnectionbroker.getConnection(), dbConnectionbroker);	
	return connection;
    }

    /**
     * Returns the local JDBC ID for a Connection.
     */
    public int idOfConnection(Connection connnection) {
	return dbConnectionbroker.idOfConnection(connnection);
    }

    /**
     * Returns the age of a Connection -- the time since it was handed out to an
     * application.
     */
    public long getAge(Connection conn) {
	return dbConnectionbroker.getAge(conn);
    }

    /**
     * Returns the number of Connections in use.
     */
    public int getUseCount() {
	return dbConnectionbroker.getUseCount();
    }

    /**
     * Returns the number of Connections in the dynamic pool.
     */
    public int getSize() {
	return dbConnectionbroker.getSize();
    }

    /**
     * Displays the given message if DEBUG is set.
     * 
     * @param s
     *            the debug message
     */

    private static void debug(String s) {
	if (DEBUG) {
	    //AwakeServerLogger.log(s);
	    System.out.println(new Date() + " " + AwakeConnectionPool.class.getSimpleName() + " " + s);
	}
    }

}
