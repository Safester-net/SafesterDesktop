/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.server.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import org.awakefw.commons.jdbc.abstracts.AbstractConnection;
import org.awakefw.file.api.util.AwakeDebug;


//21/11/11 13:25 NDP : PooledConnection: Creation
//19/12/11 21:20 NDP : PooledConnection: rewrite with 2 parameters for constructor: Connection & DbConnectionBroker
//13/08/12 11:50 NDP : PooledConnection: add better debug

/**
 * 
 * A wrapper for a Connection extracted from  DbConnectionBroker  
 * The only delegate method is close() which releases the Connection into the Awake Connection pool.
 */

public class PooledConnection extends AbstractConnection implements Connection {
    
    private static boolean DEBUG = AwakeDebug
	    .isSet(PooledConnection.class);
    
    /** The DbConnectionBroker instance */
    private DbConnectionBroker dbConnectionbroker = null;
    
    /** The wrapped Connection */
    private Connection connection = null;
    
    /**
     * Constructor
     * @param connection 		the Connection to wrap, extracted from the passed DbConnectionBroker instance
     * @param dbConnectionbroker	the DB Conneciton broker to use
     */
    public PooledConnection(Connection connection, DbConnectionBroker dbConnectionbroker) {
	super(connection);
	
	this.dbConnectionbroker = dbConnectionbroker;
	this.connection = connection;
	
	debug("");	
	debug("constru: Connection extracted from pool : " + dbConnectionbroker.idOfConnection(connection));
	debug("constru: Nb of connection in use in pool: " + dbConnectionbroker.getUseCount());	
    }

    /**
     * Release the connection into the pool
     * @throws SQLException
     * @see java.sql.Connection#close()
     */
    public void close() throws SQLException {
	dbConnectionbroker.freeConnection(connection);
	// Do not call connection.close() ==> We just want to release the connection in the pool
	
	debug("");
	debug("close(): Connection released into pool : " + dbConnectionbroker.idOfConnection(connection));
	debug("close(): Nb of connection in use in pool: " + dbConnectionbroker.getUseCount());
    }
    
    /**
     * Debug & log
     * @param s	the string to print in log
     */
    public static void debug(String s) {
	if (DEBUG) {
	    //AwakeServerLogger.log(s);
	    System.out.println(new Date() + " " + PooledConnection.class.getSimpleName() + " " + s);
	}
    }    
    
}

