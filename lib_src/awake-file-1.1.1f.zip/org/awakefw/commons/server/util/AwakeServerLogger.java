/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.server.util;

import java.io.IOException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.awakefw.commons.api.server.DefaultAwakeCommonsConfigurator;

/**
 * 
 * Logger class.
 * 
 * @author NicolasO de Pomereu
 * 
 */
public class AwakeServerLogger {


    /** The Java Logger */
    private static Logger SERVER_LOGGER = null;

    /**
     * Invisible constructor
     */
    protected AwakeServerLogger() {

    }

    /**
     * Create the Logger.
     * 
     * @param the
     *            directory where to put the log files
     * 
     * @throws IOException
     */
    public static void createLogger(Logger logger) throws IOException {

	SERVER_LOGGER = logger;
	
	System.out.println(new Date());
	System.out.println(new Date()
		+ "[AWAKE] OK. Awake Logging will be done in Logger: " + SERVER_LOGGER.getName());
	
    }

    /**
     * Log the string
     * 
     * @param s
     *            the string to log
     */
    public static void log(String s) {

	log(Level.WARNING, s);
    }

    /**
     * Log the string at the specified log level
     * 
     * @param s
     *            the string to log
     */
    public static void log(Level level, String s) {

	if (SERVER_LOGGER == null)
	{
	    try {
		SERVER_LOGGER = new DefaultAwakeCommonsConfigurator().getLogger();
	    } catch (IOException e) {
		throw new IllegalArgumentException("Impossible to create the SERVER_LOGGER logger", e);
	    }
	}
	
	SERVER_LOGGER.log(level, s);
    }
}
