/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.api.client;

import org.awakefw.file.api.util.AwakeDebug;

/**
 * 
 * A default implementation for an Awake Progress Manager.&nbsp;
 * <p>
 * This implementation is ready to use without any customization.
 * <p>
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */
public class DefaultAwakeProgressManager implements AwakeProgressManager {

    private static boolean DEBUG = AwakeDebug
	    .isSet(DefaultAwakeProgressManager.class);

    private long lengthToTransfer = 0;
    private boolean cancelValue = false;
    private int progress = 0;

    /**
     * Constructor.
     */
    public DefaultAwakeProgressManager() {

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.progress.AwakeProgressManager#cancel()
     */
    @Override
    public void cancel() {
	cancelValue = true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.awakefw.file.api.progress.AwakeProgressManager#getLengthToTransfer()
     */
    @Override
    public long getLengthToTransfer() {
	return lengthToTransfer;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.progress.AwakeProgressManager#getProgress()
     */
    @Override
    public int getProgress() {
	return progress;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.progress.AwakeProgressManager#isCancelled()
     */
    @Override
    public boolean isCancelled() {
	return cancelValue;
    }

//    /*
//     * (non-Javadoc)
//     * 
//     * @see org.awakefw.file.api.progress.AwakeProgressManager#setLengthToTransfer(long)
//     */
    /**
     * Will reinitialize all other values for a new usage:
     * <ul>
     * <li><code>cancelValue = false</code></li>
     * <li><code>progress = 0</code></li>
     * </ul>
     */    
    @Override
    public void setLengthToTransfer(long lengthToTransfer) {
	this.lengthToTransfer = lengthToTransfer;
	this.cancelValue = false;
	this.progress = 0;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.progress.AwakeProgressManager#setProgress(int)
     */
    @Override
    public void setProgress(int progress) {
	this.progress = progress;
	debug("progress: " + this.progress);
    }

    /**
     * Displays the given message if DEBUG is set.
     * 
     * @param s
     *            the debug message
     */

    private static void debug(String s) {
	if (DEBUG) {
	    System.out.println(s);
	}
    }

}
