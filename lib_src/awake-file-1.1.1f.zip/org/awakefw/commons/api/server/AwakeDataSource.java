/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.api.server;

import java.io.File;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.awakefw.commons.server.util.AwakeConnectionPool;
import org.awakefw.commons.server.util.DbConnectionBroker;

/**
 * Implementation of <code>{@link javax.sql.DataSource}</code> that allows the
 * wrapping of Awake default connection pooling system. <br>
 * <br>
 * Notes: <br>
 * <br>
 * 1) This class will be automatically loaded by
 * <code>{@link AwakeDataSourceFactory}</code> in a Java EE environment. <br>
 * <br>
 * 2) This class may also be called directly using the constructor and setting
 * the values in order to extract a Connection from the pool. <br>
 * Note that the class is <i>not</i> immutable because it must be a Java Bean
 * for some Java EE servers as Caucho Resin. <br>
 * <br>
 * Example: <br>
 * <pre>
 * // Declare the DataSource as member to load only once the pool:
 * private AwakeDataSource awakeDataSource = null;
 * ...
 * ...
 * // Driver parameters to use:
 * String driverClassName = &quot;org.postgresql.Driver&quot;;
 * String url = &quot;jdbc:postgresql://localhost:5432/awake-example&quot;;
 * String username = &quot;user1&quot;;
 * String password = &quot;password1&quot;;
 * int minConns = 2;
 * int maxConns = 15;
 * int maxConnTime = 1;
 * int maxCheckoutSeconds = 180;
 * boolean logAppend = false;
 * File logfile = new File(&quot;/home/admin/log/mylog.log&quot;);
 * &nbsp;
 * // Creating the DataSource bean and populating the values:
 * if (awakeDataSource == null) {
 *     awakeDataSource = new AwakeDataSource();
 *     awakeDataSource.setDriverClassName(driverClassName);
 *     awakeDataSource.setUrl(url);
 *     awakeDataSource.setUsername(username);
 *     awakeDataSource.setPassword(password);
 *     awakeDataSource.setMinConns(minConns);
 *     awakeDataSource.setMaxConns(maxConns);
 *     awakeDataSource.setMaxConnTime(maxConnTime);
 *     awakeDataSource.setMaxCheckoutSeconds(maxCheckoutSeconds);
 *     awakeDataSource.setLogAppend(logAppend);     
 *     awakeDataSource.setLogFile(logFile);
 * }
 * &nbsp;
 * // Extracting the Connection from the connection pool:
 * Connection connection = awakeDataSource.getConnection();
 * </pre>
 * 
 * Note that after the first call to <code>awakeDataSource.getConnection()</code>, it is then possible
 * to query the state of the connection pool with:<br>
 * <ul>
 * <li>{@link #idOfConnection(Connection)} </li>
 * <li>{@link #getAge(Connection)}</li>
 * <li>{@link #getSize()} </li>
 * <li>{@link #getUseCount()} </li>
 * </ul>
 * 
 * @see AwakeDataSourceFactory
 * @see DefaultAwakeCommonsConfigurator
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */

public class AwakeDataSource implements DataSource {

    // Mandatory parameters
    private String driverClassName = null;
    private String url = null;
    private String username = null;
    private String password = null;
    private int minConns = 0;
    private int maxConns = 0;

    // Default values for non mandatory parameters
    private double maxConnTime = 1;
    private File logFile = getDefaultLogFile();
    private int maxCheckoutSeconds = DbConnectionBroker.DEFAULTMAXCHECKOUTSECONDS;
    private boolean logAppend = false;
    
    // Not used
    private int loginTimeOut;
    private PrintWriter logWriter;
    
    /** The AwakeConnectionPool instance to use to extract connection from */
    private AwakeConnectionPool awakeConnectionPool = null;

    /**
     * This constructor is mandatory for EJB behavior. Values are set with
     * setters.
     */
    public AwakeDataSource() {

    }

    /**
     * Sets the default log file to use:
     */
    private File getDefaultLogFile() {
	
	String userHome = System.getProperty("user.home");
	if (!userHome.endsWith(File.separator)) {
	    userHome += File.separator;
	}
	
	File logDir = new File (userHome + ".awake" + File.separator + "log");
	logDir.mkdirs();
	
	String logFileStr = logDir.toString() +  File.separator
		+ "DbConnectionBroker.log";

	return new File(logFileStr);
    }

    /**
     * Sets the JDBC driver class name.
     * 
     * @param driverClassName
     *            JDBC driver class name.
     */
    public void setDriverClassName(String driverClassName) {
	this.driverClassName = driverClassName;
    }

    /**
     * Sets the Connection URL to be passed to your JDBC driver
     * 
     * @param url
     *            the Connection URL to be passed to your JDBC driver
     */
    public void setUrl(String url) {
	this.url = url;
    }

    /**
     * Sets the database username to be passed to your JDBC driver.
     * 
     * @param username
     *            the Database username to be passed to your JDBC driver.
     */
    public void setUsername(String username) {
	this.username = username;
    }

    /**
     * Sets the database password to be passed to your JDBC driver.
     * 
     * @param password
     *            the Database password to be passed to your JDBC driver.
     */
    public void setPassword(String password) {
	this.password = password;
    }

    /**
     * Sets the minimum number of connections to start with. Must be > 0.
     * 
     * @param minConns
     *            minimum number of connections to start with. Must be > 0.
     */
    public void setMinConns(int minConns) {
	this.minConns = minConns;
    }

    /**
     * Sets the maximum number of connections in dynamic pool. Must be >=
     * minConns.
     * 
     * @param maxConns
     *            the maximum number of connections in dynamic pool. Must be >=
     *            minConns.
     */
    public void setMaxConns(int maxConns) {
	this.maxConns = maxConns;
    }

    /**
     * Sets the time in days between connection resets. Defaults to 1. (Reset
     * does a basic cleanup).
     * 
     * @param maxConnTime
     *            time in days between connection resets.
     */
    public void setMaxConnTime(double maxConnTime) {
	this.maxConnTime = maxConnTime;
    }
       
    /**
     * Sets the maximum time in seconds a <code>Connection</code> can be checked out before being
     * recycled. This value is thus the maximum duration of a SQL request.
     * Default value is 180 seconds. Zero value turns option off.
     * 
     * @param maxCheckoutSeconds  the maximum time in seconds a <code>Connection</code> can be checked out before being
     * recycled. 
     */
    public void setMaxCheckoutSeconds(int maxCheckoutSeconds) {
        this.maxCheckoutSeconds = maxCheckoutSeconds;
    }

    
    
    /**
     * Sets if the log is in append. Default is false.
     * @param logAppend true to log in append, else false
     */
    public void setLogAppend(boolean logAppend) {
        this.logAppend = logAppend;
    }

    /**
     * Sets the absolute path name for log file. e.g. '/tmp/mylog.log'. Defaults
     * to user.home/.awake/awake.sql.log.
     * 
     * @param logFile
     *            absolute path name for log file.
     */
    public void setLogFile(File logFile) {
	this.logFile = logFile;
    }
    
    
    /**
     * Returns the fully qualified Java class name of your JDBC driver.
     * 
     * @return the fully qualified Java class name of your JDBC driver
     */
    public String getDriverClassName() {
	return this.driverClassName;
    }

    /**
     * Returns the Connection URL.
     * 
     * @return the Connection URL
     */
    public String getUrl() {
	return this.url;
    }

    /**
     * Returns the database username.
     * 
     * @return the database username
     */
    public String getUsername() {
	return this.username;
    }

    /**
     * Returns the database password.
     * 
     * @return the database password
     */
    public String getPassword() {
	return this.password;
    }

    /**
     * Returns the minimum number of connections to start with.
     * 
     * @return the minimum number of connections to start with
     */
    public int getMinConns() {
	return this.minConns;
    }

    /**
     * Returns the maximum number of connections in dynamic pool.
     * 
     * @return the maximum number of connections in dynamic pool.
     */
    public int getMaxConns() {
	return this.maxConns;
    }

    /**
     * Returns the time in days between connection resets.
     * 
     * @return the time in days between connection reset
     */
    public double getMaxConnTime() {
	return this.maxConnTime;
    }

    
    /**
     * Returns the maximum time in seconds a <code>Connection</code>  can be checked out before being
     * recycled. This value is thus the maximum duration of a SQL request.
     * 
     * @return  the maximum time in seconds a <code>Connection</code>  can be checked out before being
     * recycled. 
     */
    public int getMaxCheckoutSeconds() {
        return maxCheckoutSeconds;
    }

    /**
     * Returns if log is in append.
     * @return true if log is append, else false.
     */
    public boolean isLogAppend() {
        return logAppend;
    }
    
    /**
     * Returns the absolute path name for log file.
     * 
     * @return the absolute path name for log file
     */
    public File getLogFile() {
	return this.logFile;
    }

    
    /**
     * Returns the local JDBC ID for a Connection.
     * @param connnection the JDBC Connection
     */
    public int idOfConnection(Connection connnection) {
	if (awakeConnectionPool == null) {
	    throw new IllegalStateException("Method must be called after the first  getConnection()");
	}
	
	return awakeConnectionPool.idOfConnection(connnection);
    }

    /**
     * Returns the age of a Connection -- the time since it was handed out to an
     * application.
     * @param connnection the JDBC Connection
     */
    public long getAge(Connection connnection) {
	return awakeConnectionPool.getAge(connnection);
    }

    /**
     * Returns the number of Connections in use.
     */
    public int getUseCount() {
	return awakeConnectionPool.getUseCount();
    }

    /**
     * Returns the number of Connections in the dynamic pool.
     */
    public int getSize() {
	return awakeConnectionPool.getSize();
    }
    
    
    /**
     * Returns a Connection to the database.
     * 
     * @exception SQLException
     *                if a database access error occurs
     */
    @Override
    public Connection getConnection() throws SQLException {

	
	// Pool will be created at first invocation 
	if (awakeConnectionPool == null) {
	    awakeConnectionPool = new AwakeConnectionPool(driverClassName, url,
		    username, password, minConns, maxConns, maxConnTime,
		    maxCheckoutSeconds, logAppend, logFile);
	}
	

	return awakeConnectionPool.getConnection();
    }

   
    /**
     * Returns a Connection to the database.
     * 
     * @param username
     *            Database user on whose behalf the Connection is being made
     * @param password
     *            The database user's password
     * 
     * @exception SQLException
     *                if a database access error occurs
     */
    @Override
    public Connection getConnection(String username, String password)
	    throws SQLException {
	this.username = username;
	this.password = password;

	return this.getConnection();
    }

    /**
     * Returns the login timeout (in seconds) for connecting to the database.
     * 
     * @exception SQLException
     *                if a database access error occurs
     */
    @Override
    public int getLoginTimeout() throws SQLException {
	return this.loginTimeOut;
    }

    /**
     * Returns the log writer being used by this data source.
     * 
     * @exception SQLException
     *                if a database access error occurs
     */
    @Override
    public PrintWriter getLogWriter() throws SQLException {
	return this.logWriter;
    }

    /**
     * Sets the login timeout (in seconds) for connecting to the database.
     * 
     * @param loginTimeout
     *            The new login timeout, or zero for no timeout
     * 
     * @exception SQLException
     *                if a database access error occurs
     */
    @Override
    public void setLoginTimeout(int loginTimeout) throws SQLException {
	this.loginTimeOut = loginTimeout;
    }

    /**
     * Sets the log writer being used by this data source.
     * 
     * @param logWriter
     *            The new log writer
     * 
     * @exception SQLException
     *                if a database access error occurs
     */
    @Override
    public void setLogWriter(PrintWriter logWriter) throws SQLException {
	this.logWriter = logWriter;
    }

    /**
     * Returns an object that implements the given interface to allow access to
     * non-standard methods, or standard methods not exposed by the proxy.
     * 
     * If the receiver implements the interface then the result is the receiver
     * or a proxy for the receiver. If the receiver is a wrapper and the wrapped
     * object implements the interface then the result is the wrapped object or
     * a proxy for the wrapped object. Otherwise return the the result of
     * calling <code>unwrap</code> recursively on the wrapped object or a proxy
     * for that result. If the receiver is not a wrapper and does not implement
     * the interface, then an <code>SQLException</code> is thrown.
     * 
     * @param iface
     *            A Class defining an interface that the result must implement.
     * @return an object that implements the interface. May be a proxy for the
     *         actual implementing object.
     * @throws java.sql.SQLException
     *             If no object found that implements the interface
     * @since 1.6
     */
    @Override
    public <T> T unwrap(java.lang.Class<T> iface) throws java.sql.SQLException {
	throw new SQLException("Not implemented yet.");
    }

    /**
     * Returns true if this either implements the interface argument or is
     * directly or indirectly a wrapper for an object that does. Returns false
     * otherwise. If this implements the interface then return true, else if
     * this is a wrapper then return the result of recursively calling
     * <code>isWrapperFor</code> on the wrapped object. If this does not
     * implement the interface and is not a wrapper, return false. This method
     * should be implemented as a low-cost operation compared to
     * <code>unwrap</code> so that callers can use this method to avoid
     * expensive <code>unwrap</code> calls that may fail. If this method returns
     * true then calling <code>unwrap</code> with the same argument should
     * succeed.
     * 
     * @param iface
     *            a Class defining an interface.
     * @return true if this implements the interface or directly or indirectly
     *         wraps an object that does.
     * @throws java.sql.SQLException
     *             if an error occurs while determining whether this is a
     *             wrapper for an object with the given interface.
     * @since 1.6
     */
    @Override
    public boolean isWrapperFor(java.lang.Class<?> iface)
	    throws java.sql.SQLException {
	throw new SQLException("Not implemented yet.");
    }

    ///////////////////////////////////////////////////////////
    //             JAVA 7 METHOD EMULATION                   //
    ///////////////////////////////////////////////////////////
    
    /**
     * Method not implemented in Awake SQL v1.0.<br><br>
     * 
     * Return the parent Logger of all the Loggers used by this data source. This
     * should be the Logger farthest from the root Logger that is
     * still an ancestor of all of the Loggers used by this data source. Configuring
     * this Logger will affect all of the log messages generated by the data source.
     * In the worst case, this may be the root Logger.
     *
     * @return the parent Logger for this data source
     * @throws SQLFeatureNotSupportedException if the data source does not use <code>java.util.logging</code>.
     * @since 1.7
     */
    
    //@Override do not not override for Java 6 compatibility
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
	throw new SQLFeatureNotSupportedException("Not implemented yet.");
    }

}
