/*
 * This file is part of Awake File. 
 * Awake file: Easy file upload & download over HTTP with Java.                                    
 * Copyright (C) 2013,  KawanSoft SAS
 * (http://www.kawansoft.com). All rights reserved.                                
 *                                                                               
 * Awake File is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
package org.awakefw.file.api.client.quickstart;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.awakefw.file.api.client.AwakeFileSession;

/**
 * 
 * This example:
 * <ul>
 * <li>Creates a remote directory.</li>
 * <li>Uploads two files to the remote directory.</li>
 * <li>Lists the content of the remote directory.</li>
 * <li>Downloads the files of the remote directory.</li>
 * </ul>
 * 
 * @author Nicolas de Pomereu
 */
public class MyAwakeFileSession {

    /** The session to the remote Awaker File server */
    private AwakeFileSession awakeFileSession = null;

    /**
     * AwakeFileSession Quick Start client example. Creates an Awake File
     * Session.
     * 
     * @return the Awake File Session to the remote Awake File server
     * @throws IOException
     *             if communication or configuration error is raised
     */
    public static AwakeFileSession awakeFileSessionBuilder() throws IOException {

	// Modify the URL of the path to your AwakeFileManager Servlet:
	String url = "https://www.safester.net/safester_vault/AwakeFileServer";

	// (usename, password) for authentication on server side.
	// No authentication will be done for our Quick Start:
	String username = "demo";
	char[] password = { 'd', 'e', 'm', 'o' };

	// Create the Awake File Session to the remote server:
	AwakeFileSession awakeFileSession = new AwakeFileSession(url, username,
		password);
	return awakeFileSession;
    }

    /**
     * Do some Awake File operations. This example:
     * <ul>
     * <li>Creates a remote directory.</li>
     * <li>Uploads two files to the remote directory.</li>
     * <li>Lists the content of the remote directory.</li>
     * <li>Downloads the files of the remote directory.</li>
     * </ul>
     * 
     * @throws IOException
     *             if communication or configuration error is raised
     */
    public void doIt() throws IOException {

	// Define userHome var
	String userHome = System.getProperty("user.home") + File.separator;

	// Create a remote directory on the server:
	awakeFileSession.mkdirs("/mydir");

	// Upload two files image-1.jpg and image-2.jpg file located in our
	// user.home directory to the remote directory /mydir
	File image1 = new File(userHome + "image-1.jpg");
	File image2 = new File(userHome + "image-2.jpg");

	awakeFileSession.upload(image1, "/mydir/image-1.jpg");
	awakeFileSession.upload(image2, "/mydir/image-2.jpg");

	// List the subdirectories of our virtual server
	List<String> remoteDirs = awakeFileSession.listDirectories("/");
	System.out.println("directories located in /: " + remoteDirs);

	// List the files located in remote directory /mydir
	List<String> remoteFiles = awakeFileSession.listFiles("/mydir");
	System.out.println("files located in /mydir: " + remoteFiles);

	// Download the files - with a new name - in our user.home directory
	File downloadedImage1 = new File(userHome + "downloaded-image-1.jpg");
	File downloadedImage2 = new File(userHome + "downloaded-image-2.jpg");

	awakeFileSession.download("/mydir/image-1.jpg", downloadedImage1);
	awakeFileSession.download("/mydir/image-2.jpg", downloadedImage2);

	System.out.println("done!");
    }

    /**
     * Constructor
     * 
     * @param awakeFileSession
     *            the Awake File Session to use for this session
     */
    private MyAwakeFileSession(AwakeFileSession awakeFileSession) {
	this.awakeFileSession = awakeFileSession;
    }

    /**
     * Main
     * 
     * @param args
     *            not used
     */
    public static void main(String[] args) throws IOException {

	AwakeFileSession awakeFileSession = MyAwakeFileSession
		.awakeFileSessionBuilder();
	MyAwakeFileSession myAwakeFileSession = new MyAwakeFileSession(
		awakeFileSession);
	myAwakeFileSession.doIt();

    }

}
