/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api.server.fileaction;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.apache.commons.io.IOUtils;
import org.awakefw.file.api.server.AwakeFileConfigurator;
import org.awakefw.file.api.util.AwakeDebug;

/**
 * The Default Action Manager for files: all operations will simply be done on
 * the local file system.
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */

public class DefaultAwakeFileActionManager implements AwakeFileActionManager {
    private static boolean DEBUG = AwakeDebug
	    .isSet(DefaultAwakeFileActionManager.class);

    /**
     * Constructor.
     */
    public DefaultAwakeFileActionManager() {

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.server.fileaction.AwakeFileActionManager#
     * actionUploadFile(org.awakefw.file.api.server.AwakeFileConfigurator,
     * java.io.InputStream, java.lang.String, java.lang.String)
     */
    @Override
    public void upload(AwakeFileConfigurator awakeFileConfigurator,
	    InputStream inputStream, String username, String filename)
	    throws IOException {
	OutputStream fos = null;

	try {
	    filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		    username, filename);

	    File file = new File(filename);

	    // We must create, if necessary, the path
	    File parentDir = file.getParentFile();
	    if (parentDir != null) {
		parentDir.mkdirs();
	    }

	    fos = new BufferedOutputStream(new FileOutputStream(file));
	    IOUtils.copy(inputStream, fos);

	    debug("file created : " + file);
	    debug("file.length(): " + file.length());
	} finally {
	    IOUtils.closeQuietly(fos);
	}
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.server.fileaction.AwakeFileActionManager#
     * actionDeleteFile(org.awakefw.file.api.server.AwakeFileConfigurator,
     * java.lang.String, java.lang.String)
     */
    @Override
    public boolean delete(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException {
	debug("DELETE_FILE_ACTION");
	boolean result = false;

	filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		username, filename);

	File file = new File(filename);
	result = file.delete();

	return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.awakefw.file.api.server.fileaction.AwakeFileActionManager#exists(
     * org.awakefw.file.api.server.AwakeFileConfigurator, java.lang.String,
     * java.lang.String)
     */
    @Override
    public boolean exists(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException {
	debug("DELETE_FILE_ACTION");
	boolean result = false;

	filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		username, filename);

	File file = new File(filename);
	result = file.exists();

	return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.awakefw.file.api.server.fileaction.AwakeFileActionManager#mkdir(org
     * .awakefw.file.api.server.AwakeFileConfigurator, java.lang.String,
     * java.lang.String)
     */
    @Override
    public boolean mkdir(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException {
	debug("MKDIR_ACTION");
	boolean result = false;

	filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		username, filename);

	File file = new File(filename);
	result = file.mkdir();

	return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.awakefw.file.api.server.fileaction.AwakeFileActionManager#actionMkdirs
     * (org.awakefw.file.api.server.AwakeFileConfigurator, java.lang.String,
     * java.lang.String)
     */
    @Override
    public boolean mkdirs(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException {
	debug("MKDIRS_ACTION");
	boolean result = false;

	filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		username, filename);

	File file = new File(filename);
	result = file.mkdirs();

	return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.server.fileaction.AwakeFileActionManager#
     * actionGetFileLength(org.awakefw.file.api.server.AwakeFileConfigurator,
     * java.lang.String, java.lang.String)
     */
    @Override
    public long length(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException {
	filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		username, filename);

	File file = new File(filename);
	return file.length();

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.awakefw.file.api.server.fileaction.AwakeFileActionManager#
     * actionDownloadFile(java.io.OutputStream,
     * org.awakefw.file.api.server.AwakeFileConfigurator, java.lang.String,
     * java.lang.String)
     */
    @Override
    public boolean download(OutputStream out,
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws FileNotFoundException, IOException {
	InputStream in = null;
	debug("DOWNLOAD_FILE_ACTION");

	try {
	    filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		    username, filename);

	    File file = new File(filename);

	    if (!file.exists()) {
		debug("File does not exists: " + file);
		return false;
	    }

	    in = new BufferedInputStream(new FileInputStream(file));
	    IOUtils.copy(in, out);

	    return true;
	} finally {
	    IOUtils.closeQuietly(in);
	}

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.awakefw.file.api.server.fileaction.AwakeFileActionManager#listFiles
     * (org.awakefw.file.api.server.AwakeFileConfigurator, java.lang.String,
     * java.lang.String)
     */
    @Override
    public List<File> listFiles(AwakeFileConfigurator awakeFileConfigurator,
	    String username, String filename) throws IOException {
	debug("filename before addRootPath: " + filename);
	filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		username, filename);

	FilenameFilter filterFiles = new FilenameFilter() {
	    public boolean accept(File dir, String name) {

		File file = new File(dir + File.separator + name);
		return file.isFile();
	    }
	};

	File[] files = new File(filename).listFiles(filterFiles);

	List<File> fileList = null;

	if (files == null) {
	    fileList = null;
	} else {
	    fileList = Arrays.asList(files);
	}

	return fileList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.awakefw.file.api.server.fileaction.AwakeFileActionManager#listDirectories
     * (org.awakefw.file.api.server.AwakeFileConfigurator, java.lang.String,
     * java.lang.String)
     */
    @Override
    public List<File> listDirectories(
	    AwakeFileConfigurator awakeFileConfigurator, String username,
	    String filename) throws IOException {
	debug("filename before addRootPath: " + filename);
	filename = HttpConfigurationUtil.addRootPath(awakeFileConfigurator,
		username, filename);

	FilenameFilter filterFiles = new FilenameFilter() {
	    public boolean accept(File dir, String name) {

		File file = new File(dir + File.separator + name);
		return file.isDirectory();
	    }
	};

	File[] files = new File(filename).listFiles(filterFiles);

	List<File> fileList = null;

	if (files == null) {
	    fileList = new Vector<File>();
	} else {
	    fileList = Arrays.asList(files);
	}

	return fileList;
    }

    private void debug(String s) {
	if (DEBUG) {
	    //AwakeServerLogger.log(s);
	    System.out.println(new Date() + " " + DefaultAwakeFileActionManager.class.getSimpleName() + " " + s);
	}
    }

}
