/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.http.engine;

import java.io.File;
import java.util.List;

import org.awakefw.commons.api.client.AwakeProgressManager;
import org.awakefw.file.api.client.AwakeFileSession;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.http.HttpTransfer;
import org.awakefw.file.util.AwakeClientLogger;

/**
 * A Downloader Engine allows to download files from the server.
 */

public class FileDownloaderEngine extends Thread {

    public static final int RC_ERROR = -1;
    public static final int RC_OK = 1;

    /** The debug flag */
    private static boolean DEBUG = AwakeDebug.isSet(FileDownloaderEngine.class);

    /** The return code */
    private int returnCode = RC_ERROR;

    /** The Exception thrown if something *realy* bad happened */
    private Exception exception = null;

    /** The ServerCallerNew instance (already logged user) */
    private AwakeFileSession awakeFileSession;

    /** The progress manager instance, to follow the transfer */
    private AwakeProgressManager awakeProgressManager;

    /** The name of the file on the host */
    private List<String> remoteFilesPath = null;

    /** The file to download */
    private List<File> files = null;

    /** The current downloaded file name */
    private String currentFilename = null;

    /**
     * Constructor
     * 
     * @param awakeFileSession
     *            The ServerCallerNew instance (already logged user)
     * @param remoteFilesPath
     *            The files path addresses on the remote host
     * @param files
     *            The files to create on the Client side
     */
    public FileDownloaderEngine(AwakeFileSession awakeFileSession,
	    AwakeProgressManager awakeProgressManager,
	    List<String> remoteFilesPath, List<File> files) {

	if (awakeFileSession == null) {
	    throw new IllegalArgumentException(
		    "awakeFileSession can not be null!");
	}

	if (awakeProgressManager == null) {
	    throw new IllegalArgumentException(
		    "awakeProgressManager can not be null!");
	}

	if (remoteFilesPath == null) {
	    throw new IllegalArgumentException(
		    "remoteFilesPath can not be null!");
	}

	if (files == null) {
	    throw new IllegalArgumentException("files can not be null!");
	}

	this.awakeFileSession = awakeFileSession;
	this.awakeProgressManager = awakeProgressManager;
	this.remoteFilesPath = remoteFilesPath;
	this.files = files;

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.Kawan Softwares S.A.S.utilx.http.FileTransferEngine#run()
     */
    public void run() {
	try {
	    debug("FileDownloaderEngine Begin");

	    // Get the total files length
	    long filesLength = awakeFileSession
		    .length(remoteFilesPath);
	    awakeProgressManager.setLengthToTransfer(filesLength);

	    awakeFileSession.setAwakeProgressManager(awakeProgressManager);

	    for (int i = 0; i < remoteFilesPath.size(); i++) {
		this.currentFilename = files.get(i).getName();
		awakeFileSession.download(remoteFilesPath.get(i),
			files.get(i));
	    }

	    returnCode = RC_OK;
	    awakeProgressManager.setProgress(HttpTransfer.MAXIMUM_PROGRESS_100);
	    debug("FileDownloaderEngine End");
	} catch (Exception e) {
	    e.printStackTrace();
	    debug("FileDownloaderEngine Exception thrown: " + e);
	    exception = e;
	    awakeProgressManager.setProgress(HttpTransfer.MAXIMUM_PROGRESS_100);
	}

    }

    /**
     * @return the error code
     */
    public int getReturnCode() {
	return returnCode;
    }

    /**
     * 
     * @return the Java Exception (if any)
     */
    public Exception getException() {
	return exception;
    }

    /**
     * Get the file list
     * 
     * @return
     */
    public List<File> getFiles() {
	return files;
    }

    /**
     * Get the current downloading file name
     * 
     * @return the file name currently downloading
     */
    public String getCurrentFilename() {
	return currentFilename;
    }

    /**
     * debug tool
     */
    private void debug(String s) {
	if (DEBUG) {
	    System.out.println(s);
	    AwakeClientLogger.log(s);
	}
    }

}
