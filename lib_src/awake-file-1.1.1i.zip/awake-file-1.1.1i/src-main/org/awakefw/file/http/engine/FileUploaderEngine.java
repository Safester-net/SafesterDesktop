/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.http.engine;

import java.io.File;
import java.util.List;

import org.awakefw.commons.api.client.AwakeProgressManager;
import org.awakefw.file.api.client.AwakeFileSession;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.http.HttpTransfer;
import org.awakefw.file.util.AwakeClientLogger;

/**
 * An Uploader Engine allows to upload files to to the server.
 */

public class FileUploaderEngine extends Thread {
    public static final int RC_ERROR = -1;
    public static final int RC_OK = 1;

    /** The debug flag */
    public boolean DEBUG = AwakeDebug.isSet(FileUploaderEngine.class);;

    /** The return code */
    private int returnCode = RC_ERROR;

    /**
     * The error message to store if something bad happened without an Exception
     */
    private String errorMessage = null;

    /** The Exception thrown if something *realy* bad happened */
    private Exception exception = null;

    /** The ServerCallerNew instance (already logged user) */
    private AwakeFileSession awakeFileSession;

    /** The progress manager instance, to follow the transfer */
    private AwakeProgressManager awakeProgressManager;

    /** The file to download */
    private List<File> files = null;

    /** The name of the file on the host */
    private List<String> remoteFilesPath;

    /** The name of uploading file */
    private String currentFilename;

    /**
     * Constructor
     * 
     * @param awakeFileSession
     *            The ServerCallerNew instance (already logged user)
     * @param files
     *            The files to upload on the remote server
     * @param remoteFilesPath
     *            The files path addresses on the remote host
     */
    public FileUploaderEngine(AwakeFileSession awakeFileSession,
	    AwakeProgressManager awakeProgressManager, List<File> files,
	    List<String> remoteFilesPath) {

	if (awakeFileSession == null) {
	    throw new IllegalArgumentException(
		    "awakeFileSession can not be null!");
	}

	if (awakeProgressManager == null) {
	    throw new IllegalArgumentException(
		    "awakeProgressManager can not be null!");
	}

	if (remoteFilesPath == null) {
	    throw new IllegalArgumentException(
		    "remoteFilesPath can not be null!");
	}

	if (files == null) {
	    throw new IllegalArgumentException("files can not be null!");
	}

	this.awakeFileSession = awakeFileSession;
	this.awakeProgressManager = awakeProgressManager;
	this.files = files;
	this.remoteFilesPath = remoteFilesPath;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.Kawan Softwares S.A.S.utilx.http.FileTransferEngine#run()
     */
    public void run() {
	try {
	    debug("FileUploaderEngine Begin");

	    // Get the total files length
	    long filesLength = getFilesLength();
	    awakeProgressManager.setLengthToTransfer(filesLength);
	    awakeFileSession.setAwakeProgressManager(awakeProgressManager);

	    for (int i = 0; i < remoteFilesPath.size(); i++) {
		currentFilename = files.get(i).getName();
		awakeFileSession.upload(files.get(i),
			remoteFilesPath.get(i));
	    }

	    returnCode = RC_OK;
	    awakeProgressManager.setProgress(HttpTransfer.MAXIMUM_PROGRESS_100);
	    debug("FileUploaderEngine End");
	} catch (Exception e) {
	    e.printStackTrace();
	    debug("FileUploaderEngine Exception thrown: " + e);
	    exception = e;

	    awakeProgressManager.setProgress(HttpTransfer.MAXIMUM_PROGRESS_100);
	}

    }

    /**
     * @return the total files length
     */
    private long getFilesLength() {
	long filesLength = 0;
	for (File file : files) {
	    filesLength += file.length();
	}
	return filesLength;
    }

    public int getReturnCode() {
	return returnCode;
    }

    public String getErrorMessage() {
	return errorMessage;
    }

    /**
     * Get currently uplaoded file name
     * 
     * @return the file name
     */
    public String getCurrentFilename() {
	return currentFilename;
    }

    public Exception getException() {
	return exception;
    }

    /**
     * debug tool
     */
    private void debug(String s) {
	if (DEBUG) {
	    AwakeClientLogger.log(s);
	}
    }

}
