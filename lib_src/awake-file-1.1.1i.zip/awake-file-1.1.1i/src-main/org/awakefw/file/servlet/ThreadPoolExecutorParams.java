package org.awakefw.file.servlet;

public class ThreadPoolExecutorParams {

    public static final int DEFAULT_CORE_POOL_SIZE = 50;
    public static final int DEFAULT_MAXIMUM_POOL_SIZE = 100;
    
    public static final long DEFAULT_KEEP_ALIVE_TIME = 50000L;
    public static final int DEFAULT_QUEUE_CAPACITY = 2000;
    
    private int corePoolSize = DEFAULT_CORE_POOL_SIZE;
    private int maximumPoolSize = DEFAULT_MAXIMUM_POOL_SIZE;
    private long keepAliveTime = DEFAULT_KEEP_ALIVE_TIME;
    private int queueCapacity = DEFAULT_QUEUE_CAPACITY;
    
   
    public ThreadPoolExecutorParams() {
	super();
    }

    public ThreadPoolExecutorParams(int corePoolSize, int maximumPoolSize, long keepAliveTime, int queueCapacity) {
	super();
	this.corePoolSize = corePoolSize;
	this.maximumPoolSize = maximumPoolSize;
	this.keepAliveTime = keepAliveTime;
	this.queueCapacity = queueCapacity;
    }

    public int getCorePoolSize() {
        return corePoolSize;
    }

    public int getMaximumPoolSize() {
        return maximumPoolSize;
    }

    public long getKeepAliveTime() {
        return keepAliveTime;
    }

    public int getQueueCapacity() {
        return queueCapacity;
    }

    @Override
    public String toString() {
	return "ThreadPoolExecutorParams [corePoolSize=" + corePoolSize + ", maximumPoolSize=" + maximumPoolSize
		+ ", keepAliveTime=" + keepAliveTime + ", queueCapacity=" + queueCapacity + "]";
    }
       
}
