/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.servlet.AsyncContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.awakefw.commons.api.server.AwakeCommonsConfigurator;
import org.awakefw.commons.api.server.DefaultAwakeCommonsConfigurator;
import org.awakefw.commons.server.util.AwakeServerLogger;
import org.awakefw.file.api.server.AwakeFileConfigurator;
import org.awakefw.file.api.server.DefaultAwakeFileConfigurator;
import org.awakefw.file.api.server.fileaction.AwakeFileActionManager;
import org.awakefw.file.api.server.fileaction.DefaultAwakeFileActionManager;
import org.awakefw.file.http.HttpTransfer;
import org.awakefw.file.servlet.convert.HttpServletRequestConvertor;
import org.awakefw.file.util.Tag;
import org.awakefw.file.version.AwakeFileVersion;


/**
 * The main Awake File Manager Servlet <br>
 * 
 * @author Nicolas de Pomereu
 */

@SuppressWarnings("serial")
public class AwakeFileManager extends HttpServlet {

    public static String CR_LF = System.getProperty("line.separator");

    public static final String AWAKE_FILE_ACTION_MANAGER_CLASS_NAME = "awakeFileActionManagerClassName";
    public static final String AWAKE_FILE_CONFIGURATOR_CLASS_NAME = "awakeFileConfiguratorClassName";
    public static final String AWAKE_COMMONS_CONFIGURATOR_CLASS_NAME = "awakeCommonsConfiguratorClassName";

    private AwakeCommonsConfigurator awakeCommonsConfigurator = null;
    private AwakeFileConfigurator awakeFileConfigurator = null;
    private AwakeFileActionManager awakeFileActionManager = null;

    /** The init error message trapped */
    private String initErrrorMesage = null;
    
    /** The Exception thrown at init */
    private Exception exception = null;

    private ThreadPoolExecutor threadPoolExecutor = null;
    
    /**
     * Init.
     */

    public void init(ServletConfig config) throws ServletException {
	super.init(config);

	// Variable use to store the current name when loading, used to
	// detail
	// the exception in the catch clauses
	String classNameToLoad = null;

	String awakeCommonsConfiguratorClassName = config
		.getInitParameter(AWAKE_COMMONS_CONFIGURATOR_CLASS_NAME);
	String awakeFileConfiguratorClassName = config
		.getInitParameter(AWAKE_FILE_CONFIGURATOR_CLASS_NAME);
	String awakeFileActionManagerClassName = config
		.getInitParameter(AWAKE_FILE_ACTION_MANAGER_CLASS_NAME);

	try {

	    // Check spelling with first letter capitalized
	    if (awakeCommonsConfiguratorClassName == null
		    || awakeCommonsConfiguratorClassName.isEmpty()) {
		String capitalized = StringUtils
			.capitalize(AWAKE_COMMONS_CONFIGURATOR_CLASS_NAME);
		awakeCommonsConfiguratorClassName = config
			.getInitParameter(capitalized);
	    }

	    if (awakeFileConfiguratorClassName == null
		    || awakeFileConfiguratorClassName.isEmpty()) {
		String capitalized = StringUtils
			.capitalize(AWAKE_FILE_CONFIGURATOR_CLASS_NAME);
		awakeFileConfiguratorClassName = config
			.getInitParameter(capitalized);
	    }

	    if (awakeFileActionManagerClassName == null
		    || awakeFileActionManagerClassName.isEmpty()) {
		String capitalized = StringUtils
			.capitalize(AWAKE_FILE_ACTION_MANAGER_CLASS_NAME);
		awakeFileActionManagerClassName = config
			.getInitParameter(capitalized);
	    }

	    // System.out.println(Tag.AWAKE_START +
	    // "AwakeFileManager start...");

	    // Call the specific Awake File Configurator class to use

	    classNameToLoad = awakeCommonsConfiguratorClassName;
	    if (awakeCommonsConfiguratorClassName != null
		    && !awakeCommonsConfiguratorClassName.isEmpty()) {
		Class<?> c = Class.forName(awakeCommonsConfiguratorClassName);
		awakeCommonsConfigurator = (AwakeCommonsConfigurator) c
			.newInstance();
	    } else {
		awakeCommonsConfigurator = new DefaultAwakeCommonsConfigurator();
	    }

	    // Immediately create the AwakeLogger
	    Logger logger = null;
	    try {
		logger = awakeCommonsConfigurator.getLogger();
		AwakeServerLogger.createLogger(logger);
	    } catch (Exception e) {
		initErrrorMesage = Tag.AWAKE_USER_CONFIG_FAIL
			+ "Impossible to create the Logger: " + logger;
		exception = e;
		
	    }

	    classNameToLoad = awakeFileConfiguratorClassName;
	    if (awakeFileConfiguratorClassName != null
		    && !awakeFileConfiguratorClassName.isEmpty()) {
		Class<?> c = Class.forName(awakeFileConfiguratorClassName);
		awakeFileConfigurator = (AwakeFileConfigurator) c.newInstance();
	    } else {
		awakeFileConfigurator = new DefaultAwakeFileConfigurator();
	    }

	    classNameToLoad = awakeFileActionManagerClassName;
	    if (awakeFileActionManagerClassName != null
		    && !awakeFileActionManagerClassName.isEmpty()) {
		Class<?> c = Class.forName(awakeFileActionManagerClassName);
		awakeFileActionManager = (AwakeFileActionManager) c
			.newInstance();
	    } else {
		awakeFileActionManager = new DefaultAwakeFileActionManager();
	    }

	} catch (ClassNotFoundException e) {
	    initErrrorMesage = Tag.AWAKE_USER_CONFIG_FAIL
		    + "Impossible to load (ClassNotFoundException) Awake Configurator class: "
		    + classNameToLoad;
		exception = e;
	} catch (InstantiationException e) {
	    initErrrorMesage = Tag.AWAKE_USER_CONFIG_FAIL
		    + "Impossible to load (InstantiationException) Awake Configurator class: "
		    + classNameToLoad;
		exception = e;
	} catch (IllegalAccessException e) {
	    initErrrorMesage = Tag.AWAKE_USER_CONFIG_FAIL
		    + "Impossible to load (IllegalAccessException) Awake File Configurator class: "
		    + classNameToLoad;
		exception = e;
	} catch (Exception e) {
	    initErrrorMesage = Tag.AWAKE_PRODUCT_FAIL + "Please contact support support@awakefamework.org";
	    exception = e;
	}
	
	
	if (awakeCommonsConfigurator == null) {
	    awakeCommonsConfiguratorClassName = AWAKE_COMMONS_CONFIGURATOR_CLASS_NAME;
	} else {
	    awakeCommonsConfiguratorClassName = awakeCommonsConfigurator
		    .getClass().getName();
	}

	if (awakeFileConfigurator == null) {
	    awakeFileConfiguratorClassName = AWAKE_FILE_CONFIGURATOR_CLASS_NAME;
	} else {
	    awakeFileConfiguratorClassName = awakeFileConfigurator.getClass()
		    .getName();
	}

	if (awakeFileActionManager == null) {
	    awakeFileActionManagerClassName = AWAKE_FILE_ACTION_MANAGER_CLASS_NAME;
	} else {
	    awakeFileActionManagerClassName = awakeFileActionManager.getClass()
		    .getName();
	}

	System.out.println();
	System.out.println(Tag.AWAKE_START
		+ org.awakefw.file.version.AwakeFileVersion.getVersion());
	System.out.println(Tag.AWAKE_START + this.getClass().getSimpleName()
		+ " Servlet:");
	System.out.println(Tag.AWAKE_START
		+ "- Init Parameter awakeCommonsConfiguratorClassName = "
		+ awakeCommonsConfiguratorClassName);
	System.out.println(Tag.AWAKE_START
		+ "- Init Parameter awakeFileConfiguratorClassName    = "
		+ awakeFileConfiguratorClassName);
	System.out.println(Tag.AWAKE_START
		+ "- Init Parameter awakeFileActionManagerClassName   = "
		+ awakeFileActionManagerClassName);

	if (exception == null) {
	    System.out.println(Tag.AWAKE_START + "Status: OK & Running.");
	}
	else {
	    System.out.println(Tag.AWAKE_START + "Status: KO.");
	    System.out.println(initErrrorMesage);
	    System.out.println( ExceptionUtils.getStackTrace(exception));	    
	}
	
	trace("Creating threadPoolExecutor...");
	ThreadPoolExecutorParams threadPoolExecutorParams = new ThreadPoolExecutorParams();
	this.threadPoolExecutor = new ThreadPoolExecutor(threadPoolExecutorParams.getCorePoolSize(),
		threadPoolExecutorParams.getMaximumPoolSize(), threadPoolExecutorParams.getMaximumPoolSize(),
		TimeUnit.MILLISECONDS,
		new ArrayBlockingQueue<Runnable>(threadPoolExecutorParams.getQueueCapacity()));
	trace("threadPoolExecutor creation done.");
	trace("threadPoolExecutor params: " + threadPoolExecutorParams.toString());
	
    }

    /**
     * Test the configurators main methods to see if they throw Exceptions
     */
    private void testConfiguratorMethods() {
	if (exception == null) {
	    // Test that the login method does not throw an Exception
	    @SuppressWarnings("unused")
	    boolean isOk = false;

	    try {
		isOk = awakeCommonsConfigurator.login("dummy",
			"dummy".toCharArray());
	    } catch (Exception e) {
		initErrrorMesage = ServerUserException.getErrorMessage(awakeCommonsConfigurator, "login");
		exception = e;
	    }
	}
		
	if (exception == null) {
	    try {
		@SuppressWarnings("unused")
		File serverRootFile = awakeFileConfigurator.getServerRoot();
	    } catch (Exception e) {
		initErrrorMesage = ServerUserException.getErrorMessage(
			awakeCommonsConfigurator, "getServerRoot");
		exception = e;
	    }	    
	}

	if (exception == null) {
	    try {
		@SuppressWarnings("unused")
		String tokenRecomputed = awakeCommonsConfigurator
			.computeAuthToken("dummy");
	    } catch (Exception e) {
		initErrrorMesage = ServerUserException.getErrorMessage(
			awakeCommonsConfigurator, "getServerRoot");
		exception = e;
	    }
	}
	
	if (exception == null) {
	    try {
		@SuppressWarnings("unused")
		boolean forceHttps = awakeCommonsConfigurator.forceSecureHttp();
	    } catch (Exception e) {
		initErrrorMesage = ServerUserException.getErrorMessage(
			awakeCommonsConfigurator, "forceSecureHttp");
		exception = e;
	    }
	}
	
	if (exception == null) {
	    try {
		@SuppressWarnings("unused")
		 Set<String> usernameSet = awakeCommonsConfigurator.getBannedUsernames();
	    } catch (Exception e) {
		initErrrorMesage = ServerUserException.getErrorMessage(
			awakeCommonsConfigurator, "getBannedUsernames");
		exception = e;
	    }
	}		   
	    
	if (exception == null) {
	    try {
		@SuppressWarnings("unused")
		 List<String> bannedIpList = awakeCommonsConfigurator.getBannedIPs();
	    } catch (Exception e) {
		initErrrorMesage = ServerUserException.getErrorMessage(
			awakeCommonsConfigurator, "getBannedIPs");
		exception = e;
	    }
	}	
	
	
	if (exception == null) {
	    try {
		@SuppressWarnings("unused")
		boolean doUseOneRootPerUsername = awakeFileConfigurator
			.useOneRootPerUsername();
	    } catch (Exception e) {
		initErrrorMesage = ServerUserException.getErrorMessage(
			awakeCommonsConfigurator, "useOneRootPerUsername");
		exception = e;
	    }
	}
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {	
	trace("service call...");
	
	/* Call in async mode */
	final AsyncContext asyncContext = request.startAsync();
	asyncContext.setTimeout(0);
	asyncContext.addListener(new AwakeFileManagerAsyncListener());

	threadPoolExecutor.execute(new Runnable() {
	    public void run() {

		trace("Before treat call 1...");
		
		HttpServletRequest request = (HttpServletRequest) asyncContext.getRequest();
		HttpServletResponse response = (HttpServletResponse) asyncContext.getResponse();

		try {
		    trace("Before treat call 2...");
		    treat(request, response, asyncContext);
		} catch (Throwable throwable) {
		   trace("SafesterApisServlet.service failure in async mode: " + throwable.toString());
		} finally {
		    asyncContext.complete();
		}
	    }
	});
	
    }
    
    private void treat(HttpServletRequest request, HttpServletResponse response, AsyncContext asyncContext)
	    throws IOException, IllegalArgumentException {
	if (request.getMethod().equalsIgnoreCase("POST")) {
	    doPostRequest(request, response);
	} else if (request.getMethod().equalsIgnoreCase("GET")) {
	    doGetRequest(request, response);
	} else {
	    throw new IllegalArgumentException("Unsupported method: " + request.getMethod());
	}
    }
    
    /**
     * Post request.
     */
    public void doPostRequest(HttpServletRequest request, HttpServletResponse response)
	    throws IOException {

	// If init fail, say it cleanly client, instead of bad 500 Servlet Error
	if (exception != null) {
	    OutputStream out = response.getOutputStream();

	    writeLine(out, HttpTransfer.SEND_FAILED);
	    writeLine(out, exception.getClass().getName()); // Exception class name
	    writeLine(out, initErrrorMesage + " Reason: " + exception.getMessage()); // Exception message
	    writeLine(out, ExceptionUtils.getStackTrace(exception)); // stack trace
	    return;

	}

	// Store the host info in RequestInfoStore
	RequestInfoStore.init(request);

	// Wrap the HttpServletRequest with HttpServletRequestEncrypted for
	// parameters decryption
	HttpServletRequestConvertor requestEncrypted = new HttpServletRequestConvertor(
		request, awakeCommonsConfigurator);

	// System.out.println(Tag.AWAKE_START + "AwakeFileManager started!");
	ServerAwakeFileDispatch dispatch = new ServerAwakeFileDispatch();
	dispatch.executeRequest(requestEncrypted, response,
		awakeCommonsConfigurator, awakeFileConfigurator,
		awakeFileActionManager);
    }

    /**
     * Get request.
     */
    public void doGetRequest(HttpServletRequest request, HttpServletResponse response)
	    throws IOException {
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();

	String status = "</font><font face=\"Arial\" color=\"green\">"
		+ "OK & Running.";

	// Test all methods
	testConfiguratorMethods();
	
	if (exception != null) {
	    
	    String stackTrace = ExceptionUtils.getStackTrace(exception);
	    
	    BufferedReader bufferedReader = new BufferedReader(
		    new StringReader(stackTrace));
	    StringBuffer sb = new StringBuffer();

	    String line = null;
	    while ((line = bufferedReader.readLine()) != null) {
		// All subsequent lines contain the result
		sb.append(line);
		sb.append("<br>");
	    }
	    	    	    
	    status = "</font><font face=\"Arial\" color=\"red\">"
		    + initErrrorMesage + "<br>"
		    + sb.toString();
	}

	String awakeCommonsConfiguratorClassName = null;
	if (awakeCommonsConfigurator == null) {
	    awakeCommonsConfiguratorClassName = AWAKE_COMMONS_CONFIGURATOR_CLASS_NAME;
	} else {
	    awakeCommonsConfiguratorClassName = awakeCommonsConfigurator
		    .getClass().getName();
	}

	String awakeFileConfiguratorClassName = null;
	if (awakeFileConfigurator == null) {
	    awakeFileConfiguratorClassName = AWAKE_FILE_CONFIGURATOR_CLASS_NAME;
	} else {
	    awakeFileConfiguratorClassName = awakeFileConfigurator.getClass()
		    .getName();
	}

	String awakeFileActionManagerClassName = null;
	if (awakeFileActionManager == null) {
	    awakeFileActionManagerClassName = AWAKE_FILE_ACTION_MANAGER_CLASS_NAME;
	} else {
	    awakeFileActionManagerClassName = awakeFileActionManager.getClass()
		    .getName();
	}
	
	out.println("<font face=\"Arial\">");
	out.println("<b>");
	out.println("<font color=\"#F87D23\">" + AwakeFileVersion.getVersion() + "</font>");
	out.println("<br>");
	out.println("<br>");	
	out.println(this.getClass().getSimpleName() + " Servlet Configuration");
	out.println("</b>");
	

	out.println("<br><br>");
	out.println("<table cellpadding=\"3\" border=\"1\">");

	out.println("<tr>");
	out.println("<td align=\"center\"> <b>Configurator Parameter</b> </td>");
	out.println("<td align=\"center\"> <b>Configurator Value</b> </td>");
	out.println("</tr>");

	out.println("<tr>");
	out.println("<td> " + AWAKE_COMMONS_CONFIGURATOR_CLASS_NAME + "</td>");
	out.println("<td> " + awakeCommonsConfiguratorClassName + "</td>");
	out.println("</tr>");

	out.println("<tr>");
	out.println("<td> " + AWAKE_FILE_CONFIGURATOR_CLASS_NAME + "</td>");
	out.println("<td> " + awakeFileConfiguratorClassName + "</td>");
	out.println("</tr>");

	out.println("<tr>");
	out.println("<td> " + AWAKE_FILE_ACTION_MANAGER_CLASS_NAME + "</td>");
	out.println("<td> " + awakeFileActionManagerClassName + "</td>");
	out.println("</tr>");

	out.println("</table>");

	out.println("<br><br>");
	out.println("<table cellpadding=\"3\" border=\"1\">");
	out.println("<tr>");
	out.println("<td align=\"center\"> <b>Awake File Configuration Status</b> </td>");
	out.println("</tr>");
	out.println("<tr>");
	out.println("<td> " + status + "</td>");
	out.println("</tr>");
	out.println("</table>");
	out.println("</font>");

    }

    /**
     * Write a line of string on the servlet output stream. Will add the
     * necessary CR_LF
     * 
     * @param out
     *            the servlet output stream
     * @param s
     *            the string to write
     * @throws IOException
     */
    private void writeLine(OutputStream out, String s) throws IOException {
	out.write((s + CR_LF).getBytes());
    }
    
    private void trace(String msg) {
	System.out.println(AwakeFileManagerAsyncListener.getNowFormatted() + " " + AwakeFileManager.class.getSimpleName() + " " + msg);
    }
    
    @Override
    public void destroy() {
	// Terminate the Thread pool
	trace("destroy call...");
	threadPoolExecutor.shutdownNow();
	super.destroy();
	trace("destroy done!");
    }
    
}
