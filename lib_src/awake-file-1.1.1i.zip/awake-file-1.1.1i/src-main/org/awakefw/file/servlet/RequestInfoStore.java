/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.servlet;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Nicolas de Pomereu
 * 
 *         Stores the host info at start of Awake File or Awake SQL - Can be
 *         used by server Configurators to query the host in use. Infos are
 *         extract from <code>HttpServletRequest</code>.
 */

public class RequestInfoStore {

    private static String scheme = null;
    private static String serverName = null;
    private static int port = 0;

    /**
     * Constructor to be used for query.
     */
    public RequestInfoStore() {

    }

    /**
     * Sets the HttpServletRequest in memory - This method is called by Awake
     * File or Awake SQL at server startup and should not be used.
     * 
     * @param theRequest
     *            the Http Servlet Request instance at server startup.
     */
     public static void init(HttpServletRequest request) {
	if (request == null) {
	    throw new IllegalArgumentException("request can not be null!");
	}

	scheme = request.getScheme();
	serverName = request.getServerName();
	port = request.getServerPort();
    }

    /**
     * Returns the host url in format https://www.acme.org (without the port).
     * 
     * @return host url in format https://www.acme.org (without the port)
     */
    public String getServerUrl() {
	if (scheme == null || serverName == null) {
	    return null;
	}

	String hostUrl = scheme + "://" + serverName;
	return hostUrl;
    }

    /**
     * Returns the name of the scheme used to make this request, for example,
     * http, https, or ftp. Different schemes have different rules for
     * constructing URLs, as noted in RFC 1738.
     * 
     * @returns a String containing the name of the scheme used to make this
     *          request
     */
    public String getScheme() {
	return scheme;
    }

    /**
     * Returns the host name of the server to which the request was sent. It is
     * the value of the part before ":" in the Host header value, if any, or the
     * resolved server name, or the server IP address.
     * 
     * @return a String containing the name of the server
     */
    public String getServerName() {
	return serverName;
    }

    /**
     * Returns the port number to which the request was sent. It is the value of
     * the part after ":" in the Host header value, if any, or the server port
     * where the client connection was accepted on.
     * 
     * @return an integer specifying the port number
     */
    public int getServerPort() {
	return port;
    }

}
