package org.awakefw.file.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.RejectedExecutionException;

import javax.servlet.AsyncEvent;
import javax.servlet.AsyncListener;
import javax.servlet.http.HttpServletResponse;

public class AwakeFileManagerAsyncListener implements AsyncListener {

    public AwakeFileManagerAsyncListener() {

    }

    @Override
    public void onStartAsync(AsyncEvent event) throws IOException {
	// Do nothing:
    }
    
    @Override
    public void onComplete(AsyncEvent event) throws IOException {
	// Do nothing
    }

    @Override
    public void onError(AsyncEvent event) throws IOException {
	
	HttpServletResponse response = (HttpServletResponse)event.getSuppliedResponse();
	
	OutputStream out = null;
	try {
	    out = response.getOutputStream();
	} catch (IllegalStateException e) {
	    // Do nothing. Case it was already opened in main servlet...
	} catch (IOException ioexception) {
	    System.out.println(
		    getNowFormatted() + " " + "1 Internal IOException: " + ioexception.toString());
	    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	    return;
	}
	
	if (out == null) {
	    System.out.println(getNowFormatted() + " " + "2 Internal: out is null!");
	    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	    return;
	}
	
	// Rejected response means server is timeout
	if ( event.getThrowable() instanceof RejectedExecutionException) {
	    //response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
	    String message =getNowFormatted() + " " + "Server is too busy and not available for now. Please try later.";
	    out.write(("<font face=\"arial\"><h3>" + message + "</h3>").getBytes());
	    System.out.println(message);
	}
	else {
	    String message = getNowFormatted() + " " + "Server is on error and not available. Please try later.";
	    out.write(("<font face=\"arial\"><h3>" + message + "</h3>").getBytes());
	    System.out.println(message);
	}
    }
    
    @Override
    public void onTimeout(AsyncEvent event) throws IOException {
	 System.out.println(getNowFormatted() + " " + "AYSNC TIMEOUT:" + event.getThrowable());

	HttpServletResponse response = (HttpServletResponse)event.getSuppliedResponse();
	response.setStatus(HttpServletResponse.SC_GATEWAY_TIMEOUT);
    }
    
    public static String getNowFormatted() {
	Timestamp tsNow = new Timestamp(System.currentTimeMillis());
	DateFormat df = new SimpleDateFormat("yy/MM/dd HH:mm:ss.SSS");
	String now = df.format(tsNow);
	return now;
    }

}
