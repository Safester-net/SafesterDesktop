/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.util;

import java.io.File;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * 
 * Logger class.
 * 
 * @author Nicolas de Pomereu
 * 
 */
public class AwakeClientLogger {


    /** The Java Logger */
    private static Logger CLIENT_LOGGER = null;

    /**
     * Invisible constructor
     */
    protected AwakeClientLogger() {

    }


    /**
     * Log the string
     * 
     * @param s
     *            the string to log
     */
    public static void log(String s) {

	log(Level.WARNING, s);
    }

    /**
     * Log the string at the specified log level
     * 
     * @param s
     *            the string to log
     */
    public static void log(Level level, String s) {

	if (CLIENT_LOGGER == null) {
	    try {
		
		String userHome = AwakeFileUtil.getUserHome();
		if (!userHome.endsWith(File.separator)) {
		userHome += File.separator;
		}

		File logDir = new File(userHome + ".awake" + File.separator + "log");
		logDir.mkdirs();

		String logFilePattern = logDir.toString() + File.separator
		    + "AwakeClient.log";

		CLIENT_LOGGER = Logger.getLogger("AwakeClientLogger");
		int limit = 50 * 1024 * 1024;
		Handler fh = new FileHandler(logFilePattern, limit, 4, true);
		fh.setFormatter(new SimpleFormatter());
		CLIENT_LOGGER.addHandler(fh);
	    } catch (Exception e) {
		throw new IllegalArgumentException("Impossible to create the CLIENT_LOGGER logger", e);
	    }
	}
	
	CLIENT_LOGGER.log(level, s);
    }
}
