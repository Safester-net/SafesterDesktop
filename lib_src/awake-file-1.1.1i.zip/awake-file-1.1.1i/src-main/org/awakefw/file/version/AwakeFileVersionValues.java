/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.version;

// Version	: Version Manager values
// Copyright (c) KawanSoft S.A.S, 2019
//
// v1.00BETA
// 23/02/10 15:40 NDP - Configurators are now independents. Tested.
// 26/02/10 11:20 NDP - AwakeProgressManager: Add get/setLengthToTransfer() and more methods
// 26/02/10 12:10 NDP - AwakeFileSession: No more pass of HttpNetworkParameters in constructor
// 26/02/10 13:30 NDP - HttpTransferOne: new Complete constructor and suppress setHost() and setServerProgram()
// 26/02/10 18:45 NDP - Split .api package into .api.client & api.server
// 26/02/10 20:35 NDP - Clean Javadoc
// 02/03/10 15:25 NDP - AwakeFileManager: New name 
// 02/03/10 16:20 NDP - AwakeFileSession: Do not throw illegalArgumentValue on constructors
// 22/03/10 16:50 NDP - Use new commons-codec-1.4.jar
// 22/03/10 17:55 NDP - Do not transmit login/password before checking if we must be in https
// 25/03/10 17:20 NDP - method invocation was bugged. Now fixed.
// 25/03/10 18:00 NDP - Remote call takes only one parameter for class+method name
// 01/04/10 12:05 NDP - getUniqueId() moved to FileUtil & new name AwakeJdbcDriverConfigurator
// 01/04/10 16:40 NDP - Add setAwakeJdbcDriverConfiguratorClassName: allows pool usage outside awake
// 06/04/10 15:50 NDP - ServerAwakeFileDispatch: Call getCallablePackages() 
//                      instead of getCallableMethodsWithoutAuthentication()    
// 14/06/10 11:40 NDP - getUniqueId(): use now an random because two thread can do access at same time
// 01/07/10 21:00 NDP - New signature for: downloadFileFromUrl(File file, URL url) 
// 02/07/10 14:15 NDP - Add special constructor for downloadUrl in AwakeFileSession
// 03/07/10 18:50 NDP - Add setHttpNetworkParameters() for downloadUrl
// 04/07/10 18:50 NDP - Remove setHttpNetworkParameters() method
//                      & now all constructors must pass a HttpNetworkParameters instances
// 05/07/10 11:40 NDP - Add getHttpNetworkParameters()
// 07/07/10 11:15 NDP - Add displaySwingMessageIfNoProxySet() to detect NO proxy is in use
//
// 15/07/10 19:25 NDP - Jar is now awake-file-1.0.jar
// 15/07/10 19:25 NDP - AwakeConnectionPool: Clean code: if (awakeJdbcDriverConfigurator.getUrl() == null)
// 15/07/10 19:25 NDP - AwakeFileSession: Remove dead code in uploadFile of test of remoteFilePath == null
// 15/07/10 19:25 NDP - ServerAwakeFileDispatch: Remove dead code
// 06/08/10 19:50 NDP - ServerAwakeFileDispatch: fix bug: the check on package was done on full method name
// 27/08/10 20:30 NDP - use now JsonList to transport list of strings
// 28/08/10 19:15 NDP - listFilesOrDirectory() gets content from a string instead of a file
// 28/08/10 19:15 NDP - AwakeFileSession: Add DELETE_RESULT_FILE to delete temp file
//
// 15/09/10 15:50 NDP - AwakeFileSession: new constructors with/without proxy & setHttpProtocolParameters
// 17/09/10 16:25 NDP - HttpTransferOne.downloadFile(): read error status from binary input stream 
// 22/09/10 22:40 NDP - HttpTransferOne: add ntlm authentication support
// 23/09/10 17:35 NDP - Comments
// 24/09/10 12:45 NDP - AwakeFileSession.call(): String returned by Awake File Server is now base64
// 24/09/10 12:50 NDP - ServerAwakeFileDispatch.actionInvokeRemoteMethod: String returned to client is now base64
// 25/09/10 09:10 NDP - AwakeFileConfigurator: add allowExecuteAfterAnalysis()
// 25/09/10 10:15 NDP - DefaultAwakeFileConfigurator: add allowExecuteAfterAnalysis()
// 30/09/10 13:05 NDP - Version that throws Exceptions
// 03/10/10 16:20 NDP - API classes are now final
// 03/10/10 16:50 NDP - Return  empty Set or ArrayList instead of null in configurators
// 07/10/10 11:05 NDP : ServerAwakeFileDispatch: actionCall throws now SQLException
//
// 07/10/10 11:55 NDP : AwakeFileConfigurator: allowExecuteAfterAnalysis throws now SQLException
// 07/10/10 11:55 NDP : AwakeFileConfigurator: allowExecuteAfterAnalysis renamed to allowCallAfterAnalysis
// 07/10/10 11:55 NDP : AwakeFileConfigurator: add actionIfCallDisallowed
// 07/10/10 15:25 NDP : ServerAwakeFileDispatch: call free connection in finally
// 11/10/07 13:05 NDP : ServerFileUploadAction: new method name createFile(InputStream inputStream, File file)
//
// 12/10/10 17:55 NDP : ServerAwakeFileDispatch: all actions on files are dispatched to AwakeFileActionManager
// 12/10/10 17:55 NDP : ServerFileUploadAction: all actions on files are dispatched to AwakeFileActionManager
// 12/10/10 17:55 NDP : ServerAwakeSqlDispatch: all actions on files are dispatched with an AwakeFileActionManager
// 02/11/10 19:10 NDP : AwakeConnectionPool: add new methods (pool size, number of active connections, ...)
// 08/11/10 16:15 NDP - HttpTransferOne.send(): in entity content is always immediately fetched into file
// 12/11/10 14:15 NDP - ReturnCode: add IO_EXCEPTION
// 12/11/10 18:50 NDP - Remove references to Registry, will not work because of package names
// 13/11/10 16:55 NDP - HttpTransferOne.downloadUrl(): out is now a BufferredOutputStream
// 13/11/10 16:55 NDP - HttpTransferOne.downloadUrl(): Do *NOT* use a buffered input stream 
//                      ==> Will fail with SSL handshakes!
// 14/11/10 19:35 NDP : AwakeFileLogger: Level.WARNING instead of CONFIG
// 14/11/10 20:05 NDP : org.awakefw.file.http.json package is moved to awake_file_json project (because of obsfucation)
// 15/10/10 16:25 NDP : ServerAwakeFileDispatch: all JSON actions are done using JsonServerBuilder
// 15/10/10 16:25 NDP : All JSON actions *creation* on client side must use external non-obsfucated
//                     org.awakefw.file.api.client.json of project awake_file_json
// 17/10/10 19:45 NDP : AwakeSessionConfig: Creation
// 17/10/10 19:45 NDP : HttpServletRequestEncrypted: Creation
// 18/11/10 11:30 NDP : AwakeFileManager: Wrap the HttpServletRequest with HttpServletRequestEncrypted 
//                      for parameters decryption encrypted on the PC
// 18/11/10 15:20 NDP : Add AwakeSessionConfig for static parameters settings & all passwords are char []
//
// 20/11/10 21:00 NDP : HttpProtocolParameters: add parameters of suppressed AwakeSessionConfig class
// 20/11/10 21:00 NDP : HttpTransferOne: use parameters of HttpProtocolParameters instead of 
//                      suppressed AwakeSessionConfig class
// 20/11/10 21:00 NDP : FileBodyForEngine: use HttpProtocolParameters instance for upload buffer size
// 21/11/10 18:40 NDP : BasicNameValuePairEncryptor: do not encrypt if password is null!
// 21/11/10 18:40 NDP : ServerLoginAction: test awakeCommonsConfigurator.forceSecureHttp() on LOGIN_ACTION
// 27/11/10 19:10 NDP - AwakeFileSession: add getUrl()
// 15/12/10 20:35 NDP : ServerAwakeFileDispatch.call(): Add System.out.println("Call Exception: " + getStackTrace(e));
// 29/12/10 17:30 NDP - AwakeFileSession.call(): remove a silly println
// 15/01/11 20:40 NDP : ServerFileUploadAction: add debug info for file names
// 16/01/11 20:10 NDP : HtmlConverter moved from Awake SQL
// 16/01/11 20:10 NDP : AwakeFileSession.call: apply HtmlConverter.toHtml() to remote file name before servlet call
// 16/01/11 20:25 NDP : AwakeFileSession.call: apply HtmlConverter.fromHtml() to local file after download
// 16/01/11 20:30 NDP : ServerFileUploadAction: filename = HtmlConverter.fromHtml(filename);
// 16/01/11 20:50 NDP : ServerAwakeFileDispatch: filename = HtmlConverter.fromHtml(filename);
// 17/01/11 17:10 NDP : ServerFileUploadAction: back to false in debug
// 17/01/11 17:20 NDP : AwakeFileSession.call: apply HtmlConverter.toHtml() to login & password
// 17/01/11 17:25 NDP : ServerLoginAction: apply HtmlConverter.fromHtml() to login & password
// 17/01/11 17:35 NDP : AwakeFileSession.call: NO MORE apply HtmlConverter.toHtml() to login & password
// 17/01/11 17:35 NDP : ServerLoginAction: NO MORE apply HtmlConverter.toHtml() to login & password
// 17/01/11 17:45 NDP : AwakeFileSession.call: this.login = login done before conversion
// 09/03/11 20:05 NDP - BasicNameValuePairEncryptor: do not encrypt for Parameter.STATEMENT_HOLDER
// 10/03/11 15:40 NDP - Parameter: add STATEMENT_HOLDER
// 10/03/11 15:40 NDP - DefaultAwakeCommonsConfigurator: add Comments to get/freeConnection()
// 11/03/11 16:05 NDP - Rename packages
//
// 13/03/10 15:10 NDP - DefaultAwakeProgressManagerClass: Debug var is now in ApiDebug
// 13/03/10 15:25 NDP : AwakeFileSession: no more setters (class is immutable)
// 13/03/10 15:45 NDP : AwakeFileSession: no more setter for HttpProtocolParameters (passed in constructor)
// 13/03/10 17:55 NDP : All API classes: correct Javadoc for publishing
//
// 15/03/11 17:20 NDP - DefaultAwakeCommonsConfigurator: add setAwakeJdbcInfoIni()
// 15/03/11 17:20 NDP - AwakeFileManager: no more awakeJdbcDriverConfiguratorClassName
// 15/03/11 17:20 NDP - AwakeConnectionPool: loads JDBC Driver info from an ini file
//
// 17/03/11 12:30 NDP - Add comments for Javadoc
// 17/03/11 19:05 NDP - DefaultAwakeCommonsConfigurator: getConnection(String awakeJdbcInfoIniStr) 
// 17/03/11 19:10 NDP - DefaultAwakeCommonsConfigurator: remove setAwakeJdbcInfoIni() method
// 18/03/11 18:25 NDP - DefaultAwakeCommonsConfigurator: Comments
//
// 12/04/12 17:05 NDP : ServerLoginAction: print class name, message & stack trace on servlet output stream
// 12/04/12 17:10 NDP : ServerLoginAction: use AwakeSecurityException for banned ip or no https scheme
// 12/04/12 17:05 NDP : ServerAwakeSqlDispatch: print class name, message & stack trace on servlet output stream
// 12/04/12 17:05 NDP : ServerAwakeFileDispatch: print class name, message & stack trace on servlet output stream
// 12/04/12 17:15 NDP : ServerFileUploadAction: print class name, message & stack trace on servlet output stream
// 12/04/12 18:15 NDP : HttpTransferOne: clean trap and re-throw of remote exceptions
// 12/04/12 18:15 NDP : Tag: add AwakeFailureException & AwakeSecurityException
// 12/04/12 18:45 NDP : AwakeFileSession: beagin clean trap and re-throw of remote exceptions
// 13/04/12 19:45 NDP : AwakeFileSession: clean trap and re-throw of remote exceptions
// 19/04/11 12:25 NDP - DefaultAwakeCommonsConfigurator: suppress awakeJdbcInfoIni/dbPassword fields
// 19/04/11 12:25 NDP - AwakeConnectionPool: add new constructor AwakeConnectionPool(File awakeJdbcInfoIni)
// 19/04/11 12:25 NDP - AwakeConnectionPool: test if log_file can be created
// 24/04/11 18:15 NDP - Update all commons + gson libraries to latest versions
// 26/04/11 19:40 NDP - AwakeConnectionPool: add debug info
// 27/04/11 19:10 NDP - AwakeFileManager: put as much init code in init() instead of doPost()
// 28/04/12 19:25 NDP : ServerAwakeFileDispatch: log call() exceptions on System.out 
// 27/05/11 16:55 NDP - AwakeConnectionPool: allow default value of 1 to maxConnectionTime
//
// 30/05/11 17:35 NDP : HttpTransferOne: addOneToAwakeProgressManager(): awakeProgressManager.setProgress(current)
//                      on lyt id current < current < HttpTransfer.MAXIMUM_PROGRESS_100
// 30/05/11 17:35 NDP : FileBodyForEngine: addOneToAwakeProgressManager(): awakeProgressManager.setProgress(current)
//                      on lyt id current < current < HttpTransfer.MAXIMUM_PROGRESS_100
//
// v1.00b_BETA
// 03/06/11 20:00 NDP : AwakeCommonsConfigurator: Refactor checkLoginAndPassword() to login(), 
//                      getSecretValue() to addSecretForAuthToken() and
//                      getEncryptionPasswordForHttpParameters() to getPasswordForHttpRequestEncryption()
// 03/06/11 20:00 NDP : ServerAwakeFileDispatch.isTokenValid: rename param 
// 03/06/11 20:00 NDP : AwakeFileSession: Refactor login(): returns a boolean
// 03/06/11 20:00 NDP : ServerFileUploadAction: Use Parameter.LOGIN / TOKEN / FILENAME 
// 03/06/11 20:00 NDP : ReturnCode: Rename INVALID_LOGIN_OR_PASSWORD ==> INVALID_LOGIN_OR_PASSWORD
// 04/06/11 11:50 NDP : ReturnCode: back to INVALID_LOGIN_OR_PASSWORD (for compatibility with prev versions)
// 04/06/11 11:50 NDP : AwakeFileActionManager: rename login to username
// 04/06/11 11:50 NDP : DefaultAwakeFileActionManager: rename login to username
// 04/06/11 12:50 NDP : ServerAwakeFileDispatch: rename login to username
// 
// 04/06/11 21:25 NDP : HttpProxy: Handle NTLM proxy with integrated code of HttpClient 4.1.1
// 04/06/11 21:25 NDP : HttpTransferOne: Handle NTLM proxy with integrated code of HttpClient 4.1.1
//
// v1.00c_BETA
// 06/06/11 18:10 NDP : AwakeFileConfigurator: add method name and parameters into actionIfCallDisallowed()
// 06/06/11 18:10 NDP : DefaultAwakeFileConfigurator: add method name and parameters into actionIfCallDisallowed()
// 07/06/11 14:30 NDP : AwakeFile.InvalidLoginException & AwakeFailureException are now in org.awakefw.commons.api.client
//
// v1.00d_BETA
// 08/06/11 10:45 NDP : ComputerInfo: clean trap of exceptions on getMacAddress();
// 08/06/11 10:45 NDP : ServerAwakeSqlDispatch: set debug to false;
//
// v1.00e_BETA
// 08/06/11 12:20 NDP : HttpProxy: Clean Javadoc
// 08/06/11 12:45 NDP : AwakeCommonsConfigurator: Clean Javadoc
// 08/06/11 18:45 NDP : All AwakeExceptions are now in org.awakefw.commons.api.client
// 08/06/11 19:30 NDP : AwakeFileSession: no more throw of AwakeRemoteException on apis, except for call()
// 09/06/11 16:15 NDP : AwakeCommonsConfigurator: add getBannedUsernames()
// 09/06/11 16:15 NDP : DefaultAwakeCommonsConfigurator: add getBannedUsernames()
// 09/06/11 16:30 NDP : AwakeCommonsConfigurator: check banned usernames
// 17/06/11 20:55 NDP : AwakeSecurityException: does not extends anymore IOException
// 18/06/11 15:15 NDP : Tested.
//
// BEGIN Work for api v2:
// 18/06/11 15:40 NDP : InputStreamBodyForEngine Creation
// 18/06/11 18:50 NDP : HttpTransferOne.throwTheRemoteException(): 
//                      IOExceptions are not anymore Failure Exceptions
// 19/06/11 16:00 NDP : AwakeFileSession: add getUsername() and getAwakeProgressManager()
// END Work for api v2. (Suspended)
// 
// 20/06/11 12:05 NDP : AwakeFileSession: login & username are now passed to constructor
// 20/06/11 12:45 NDP : AwakeFileManager: new name for AwakeFileServer
// 20/06/11 13:50 NDP : HttpTransfer: getStatusCode() renamed to getHttpStatusCode()
// 20/06/11 13:50 NDP : AwakeFileSession: getStatusCode() renamed to getHttpStatusCode()
// 22/06/11 16:00 NDP : AwakeProgressManager: comments
// 23/06/11 13:24 NDP : AwakeFileSession: username & password may be null: for call() and downloadUrl() usage
//
// v1.00f_BETA
// 23/06/11 16:00 NDP : AwakeFileSession: comments
//
// v1.00g_BETA
// 06/07/11 16:35 NDP : AwakeFailureException is suppressed!
// 09/07/11 16:45 NDP : ServerAwakeFileDispatch: support all classes that have a TheClass(String s) contructor:
// 10/07/11 21:35 NDP : ServerAwakeFileDispatch: support call with AwakeCallable(NotAuthenticated) interface
// 15/07/11 11:50 NDP : AwakeFileSession: add clone() method
// 15/07/11 11:50 NDP : UserNumberGetter: code is optimized 
// 15/07/11 13:05 NDP : ConnectionParms: UserNumberGetter optimized code is used to get the user number
// 16/07/11 13:15 NDP : ServerAwakeFileDispatch: remove old client call() security checks
// 17/07/11 14:10 NDP : CallAuthorizer: adapt code to AwakeCallable & AwakeCallableNotAuthenticated
// 17/07/11 14:15 NDP : CallUtil creation & comments 
// 17/07/11 15:25 NDP : AwakeFileConfigurator: new name for actionIfCallDisallowed ==>  runIfCallDisallowed
// 17/07/11 15:25 NDP : DefaultAwakeFileConfigurator: new name for actionIfCallDisallowed ==>  runIfCallDisallowed
//
// v1.00h_BETA
// 18/07/11 19:05 NDP : ServerLoginAction: computeToken moved to TokenUtil
// 18/07/11 19:05 NDP : TokenUtil: creation
// 18/07/11 19:05 NDP : ComputerInfo: moved into org.awakefw.file.api.util
//
// v1.00i_BETA
// 20/07/11 12:45 NDP : ServerLoginAction: set debug to false
// 20/07/11 12:45 NDP : FileDownloaderEngine: set debug to false
// 20/07/11 18:10 NDP : AwakeFileSession: add getUrlContent(URL url) 
// 20/07/11 18:10 NDP : HttpTransfer: add getUrlContent(URL url) 
// 20/07/11 18:10 NDP : HttpTransferOne: add getUrlContent(URL url) 
//
// v1.00j_BETA
//22/07/11 16:45 NDP : AwakeUrl: Creation
//22/07/11 18:45 NDP : AwakeFileSession: adapt code to new AwakeUrl
//22/07/11 18:45 NDP : AwakeUrl: URL is passed to the download methods 
//                               (necessary for progress indicators if multiple downloads)
//22/07/11 20:10 NDP : DefaultAwakeFileConfigurator: not secured at all for immediate start
//22/07/11 20:10 NDP : AwakeFileConfigurator: Javadoc comments
//
// v1.00j2_BETA
//02/08/11 20:25 NDP : AwakeConnectionPool is now in org.awakefw.commons.api.server
//02/08/11 20:35 NDP : ConnectionTester is now in org.awakefw.file.api.util
//
// v1.0
//21/09/11 12:50 NDP : Configurators methods throw IOException & SQLException
//21/09/11 16:20 NDP : Comments
//22/09/11 18:00 NDP : Examples have been completely rewritten
//23/09/11 17:30 NDP : AwakeFileManager: better fault tolerance on first class name capitalization
//28/09/11 18:40 NDP : Parameter: STATEMENT_HOLDER reflects Awake Sql value
//28/09/11 19:05 NDP : Parameter: add TEST_CRYPTO
//28/09/11 19:05 NDP : HttpServletRequestEncrypted:  use (TEST_CRYPTO, TEST_CRYPTO) couple to test the
//                     decryption
//30/09/11 15:25 NDP : Parameter: rewrite short values for each Parameter
//30/09/11 15:25 NDP : TokenUtil: token is cut to 20 chars
//30/09/11 15:25 NDP : Parameter: add TOKEN_LEFT_SIZE = 20
//30/09/11 15:25 NDP : AwakeFileSession:  authenticationToken = StringUtils.left(theToken, Parameter.TOKEN_LEFT_SIZE);
//07/10/11 11:00 NDP : Directory: rewrite
//07/10/11 13:20 NDP : ServerAwakeFileDispatch: use new JavaValueBuilder to decode params types & values in call
//07/10/11 13:20 NDP : JavaValueBuilder: creation
//07/10/11 20:05 NDP : AwakeFileSession: NO! Package name must not be removed from class name in call()
//08/10/11 13:40 NDP : Parameter: Keep long values because of backward compatibility
//10/10/11 12:10 NDP : AwakeConnectionPool: suppress multi-tests and better configuration error messages
//10/10/11 12:10 NDP : AwakeConnectionPool: suppress exception thrown if (maxConnectionTimeStr == null)
//                     because' we want to accept a default value of 1
//10/10/11 12:55 NDP : AwakeFileManager: add get method to display configuration info
//10/10/11 15:10 NDP : verify that all debug values are set to false and no more System.out.println
//17/10/11 12:25 NDP : Tag: add BatchUpdateException
//27/10/11 20:00 NDP : AwakeFileSession: null parameters are refused for call()
//29/10/11 19:40 NDP : AwakeDebug: creation
//31/10/11 14:50 NDP : DefaultAwakeFileConfigurator: change getServerRoot() to user.home/awake and
//		       useOneRootDirectoryPerUsername returns true
//10/11/11 11:05 NDP : DefaultAwakeCommonsConfigurator: cleaner Exception messages on getConnection()
//10/10/11 11:35 NDP : AwakeConnectionPool: load driver using Driver driver = (Driver) c.newInstance();
//21/11/11 16:45 NDP : AwakeFileManager: cleaner display of init parameters
//22/11/11 17:25 NDP : ServerAwakeFileDispatch: throw Exception on first getParameter(): means encryption fails
//28/11/11 13:20 NDP : Everywhere in exposed Javadoc: add @since 1/0 / @author Nicolas de Pomereu
//28/11/11 13:45 NDP : Everywhere in exposed Javadoc: clean
//30/11/11 18:15 NDP : FileUtil: add cleanTempDir()
//30/11/11 19:30 NDP : HttpTransferOne: delete the received file if it's an Exception
//30/11/11 19:35 NDP : AwakeFileSession: delete receiveFile if there is an Exception
//02/11/11 16:50 NDP : HttpTransferOne: wrap httpClient.getParams().setParameter(parameter, value) Exception
//
// v.1.0.4
// 07/12/11 18:10 NDP : AwakeFileSession: clean getRemoteFilesLength(List<String> remoteFilesPath) javadoc
// 07/12/11 18:10 NDP : AwakeFileSession: clean listRemoteXxxx javadoc
// 07/12/11 18:15 NDP : AwakeFileConfigurator: clean javadoc
// 07/12/11 18:15 NDP : DefaultAwakeFileConfigurator: clean javadoc
// 07/12/11 18:15 NDP : AwakeFileActionManager: clean javadoc
// 07/12/11 18:25 NDP : DefaultAwakeFileActionManager: clean javadoc
// 07/12/11 18:35 NDP : AwakeFileConfigurator: clean javadoc
//
// v1.0.5
// 10/12/11 15:10 NDP : AwakeFileSession: add setUseBase64EncodingForCall()
// 10/12/11 15:15 NDP : HttpServletRequestConvertor: convert from Base64 or from Html depending on client version
// 08/12/11 15:20 NDP : ServerAwakeFileDispatch: return result in base64 for call with parameter.CALL_ACTION
// 08/12/11 15:20 NDP : ServerAwakeFileDispatch: convert parameters from base64 for call with parameter.CALL_ACTION
// 02/11/11 16:40 NDP : HttpTransferOne: use BasicNameValuePairConvertor in downloadFile(): 
//			required by host for version
// 10/12/11 21:15 NDP : ServerAwakeFileDispatch: remove all unnecessary base64 conversions
// 10/12/11 21:45 NDP : ServerAwakeFileDispatch: actionListDirsOrFiles: list dir/fiels were inverted. Fixed.
// 12/12/11 15:25 NDP : HttpServletRequestConvertor: no more forced base64 conversion for old < v1.0.5 version
// 10/12/11 15:30 NDP : ServerAwakeFileDispatch: clean code if (action.equals(Action.CALL_ACTION))
// 12/12/11 17:30 NDP : AwakeFileSession: call(): no more base64 trap exception on Html decode 
// 12/12/11 21:30 NDP : BasicNameValuePairConvertor: encryption is done before to Html conversion
//
// v1.0 
// 19/12/11 23:10 NDP : reinit Awake File version to 1.0 (separated package)
// 20/12/11 19:30 NDP : HttpServletRequestConvertor: no more test on version value, just the fact version is not null
// 03/01/12 12:20 NDP : JavaValueBuilder: suppress Connection parameter
// 03/01/12 12:20 NDP : ServerAwakeFileDispatch: in actionCall(): create a Connection only if required
//			(Allows to use Awake File without configuring JDBC pool)
// 04/01/12 15:00 NDP : AwakeFileConfigurator: clean javadoc
// 04/01/12 15:15 NDP : ServerAwakeFileDispatch:  Run the runIfCallDisallowed() configured by the user
// 04/01/12 18:05 NDP : Version pass tests suite
// 04/01/12 19:35 NDP : ServerAwakeFileDispatch: Add Tag.AWAKE_SECURITY to AwakeSecurityException
// 05/01/12 15:25 NDP : Version pass tests suite
// 10/01/12 18:20 NDP : HttpConfigurationUtil: adapt code because 
//			AwakeFileConfigurator.getServerRoot()returns now a File
// 10/01/12 18:40 NDP : AwakeFileConfigurator: getServerRoot returns a File on the OS & clean javadoc
// 10/01/12 19:00 NDP : DefaultAwakeFileConfigurator: getServerRoot returns a File on the OS & 
//			directory is user.home/.awake & clean Javadoc
// 10/01/12 19:00 NDP : AwakeDataSource: getDefaultLogFile() uses DefaultAwakeFileConfigurator().getServerRoot()
// 10/01/12 19:20 NDP : AwakeDebug: AWAKE_DEBUG_INI location depends on DefaultAwakeFileConfigurator().getServerRoot()
// 10/01/12 19:20 NDP : Version pass tests suite
// 10/01/12 20:55 NDP : DefaultAwakeFileConfigurator: getServerRoot returns now user.home/.awake-server-root
// 10/01/12 20:55 NDP : Version pass tests suite
// 11/01/12 13:35 NDP : AwakeFileConfigurator: useOneRootDirectoryPerUsername renamed to oneRootPerUsername
// 11/01/12 13:35 NDP : DefaultAwakeFileConfigurator: useOneRootDirectoryPerUsername renamed to oneRootPerUsername
// 11/01/12 13:45 NDP : HttpConfigurationUtil: clean comments & modify / to  
//		        File.separator if no server root
// 12/01/12 14:25 NDP : Version pass tests suite
//
// 12/01/12 19:05 NDP : DefaultAwakeFileConfigurator: clean Javadoc
// 12/12/11 19:20 NDP : AwakeCommonsConfigurator: clean javadoc
// 12/12/11 19:35 NDP : org.awakefw.file.api.client.examples is now in src-examples (out of svn)
// 12/12/11 19:40 NDP : AwakeProgressManager: clean javadoc
//
// v.1.0.1
// 16/01/12 20:35 NDP : AwakeLogger: is now in org.awakefw.file.util
// 16/01/12 20:55 NDP : DbConnectionBroker is now in org.awakefw.commons.server.util
// 17/01/12 20:55 NDP : AwakeDataSource: clean Javadoc
// 17/01/12 21:15 NDP : AwakeDataSourceFactory: clean Javadoc
// 17/01/12 21:45 NDP : Delete class StringMgr
// 17/01/12 21:45 NDP : Version pass tests suite
// 03/02/12 19:20 NDP : AwakeDataSourceFactory: clean Javadoc
// 03/02/12 19:20 NDP : Version pass tests suite
// 03/02/12 21:10 NDP : AwakeDataSource: clean Javadoc
// 03/02/12 21:10 NDP : Version pass tests suite
// 06/02/12 21:10 NDP : Version pass tests suite
//
// v.1.0.2
// 16/02/12 15:20 NDP : ComputerInfo: move to org.awakefw.commons.api.server.util & clean Javadoc. 
// 16/02/12 15:20 NDP : Sha1: move to org.awakefw.commons.api.server.util & clean Javadoc. 
// 16/02/12 15:50 NDP : AwakeCommonsConfigurator: add computeAuthToken()
// 16/02/12 15:50 NDP : DefaultAwakeCommonsConfigurator: add computeAuthToken()
// 16/02/12 15:50 NDP : ServerAwakeSqlDispatch: use AwakeCommonsConfigurator.computeAuthToken()
// 16/02/12 15:50 NDP : ServerFileUploadAction: use AwakeCommonsConfigurator.computeAuthToken()
// 17/02/12 16:05 NDP : AbstractConnection: add Java 7 Connection methods for source code
//		        compatibility in Java 6 & Java 7
// 17/02/12 16:10 NDP : AbstractDatabaseMetaData: add Java 7 methods for source code
//		        compatibility in Java 6 & Java 7
// 17/02/12 16:10 NDP : AbstractPreparedStatement: add Java 7 methods for source code
//		        compatibility in Java 6 & Java 7
// 17/02/12 16:15 NDP : AbstractResultSet: add Java 7 methods for source code
//		        compatibility in Java 6 & Java 7
// 17/02/12 16:15 NDP : AbstractStatement: add Java 7 methods for source code
//		        compatibility in Java 6 & Java 7
// 17/02/12 16:20 NDP : AwakeDataSource: add Java 7 Connection methods for source code
//		        compatibility in Java 6 & Java 7
// 17/02/12 16:40 NDP : Source code is now Java6 & Java 7 compatible
// 21/02/12 16:50 NDP : AwakeCommonsConfigurator: clean Javadoc
// 21/02/12 16:50 NDP : Sha1: clean code
// 21/02/12 18:00 NDP : RequestInfoStore is now in org.awakefw.file.servlet package
// 21/02/12 18:00 NDP : ServerInfo: new name of ComputerInfo
// 21/02/12 19:35 NDP : AwakeDataSource is now org.awakefw.commons.api.server
// 21/02/12 19:35 NDP : AwakeDataSourceFactory is now org.awakefw.commons.api.server
// 22/02/12 19:40 NDP : Version pass tests suite
// 23/02/12 11:20 NDP : Clean Javadoc for JDBC 4.1 not implemented methods
// 23/02/12 11:50 NDP : DefaultAwakeCommonsConfigurator: clean Javadoc
// 23/02/12 11:50 NDP : AwakeCommonsConfigurator: clean Javadoc
//
// v.1.0.3
// 23/02/12 11:50 NDP : Fix Javadoc & remove example classes from final jar
//
// v.1.0.4
// 01/03/12 13:20 NDP : Use own AwakeBase64InputStream/AwakeBase64OutputStream
// 01/03/12 13:40 NDP : AwakeConnectionPool.startDbConnectionBroker: throw SQLException with
//			clean and complete message if url or properties are invalid
// 01/03/12 15:20 NDP : org.awakefw.commons.codec is completely independent of commons-codec
// 01/03/12 19:20 NDP : Version pass tests suite
// 27/09/10 19:30 NDP - StringUtil: no more usage of old internal Base64 (use commons codec rewrite)
// 01/03/12 23:15 NDP : HttpProtocolParameters: add isHtmlEncodingOn/setHtmlEncodingOn
// 03/03/12 13:05 NDP : HttpProtocolParameters: clean Javadoc
// 03/03/12 13:15 NDP : AwakeDriver: clean Javadoc
// 03/03/12 13:15 NDP : Version: clean PRODUCT.toString()
// 03/03/12 14:10 NDP : clean awake file names & Version pass tests suite
// 03/03/12 14:45 NDP : DefaultAwakeFileActionManager: do not trap any Exception
// 03/03/12 15:30 NDP : Use Lang Commons ExceptionUtils.getStackTrace() 
// 03/03/12 15:55 NDP : AwakeCommonsConfigurator: clean Javadoc for getLogger
// 03/03/12 15:55 NDP : DefaultAwakeCommonsConfigurator: clean Javadoc for getLogger()
// 03/03/12 15:55 NDP : DefaultAwakeFileConfigurator: runIfCallDisallowed is rewritten
// 03/03/12 16:05 NDP : AwakeLogger: remove unused code
// 03/03/12 16:20 NDP : StringUtil: add getTrimValue()
// 03/03/12 16:20 NDP : ServerCallAction: creation
// 03/03/12 16:20 NDP : ServerCallAction: actionCall is now ServerCallAction.call()
// 03/03/12 17:10 NDP : All server Exceptions are trapped with an explicit Level.WARNING
// 03/03/12 17:55 NDP : DefaultAwakeCommonsConfigurator: clean Javadoc for getLogger()
// 04/03/12 21:05 NDP : HttpProtocolParameters: new default values and clean Javadoc
// 05/03/12 17:15 NDP : Version pass tests suite
// 05/03/12 20:50 NDP : DefaultAwakeCommonsConfigurator: Logger is now a static member
// 05/03/12 20:50 NDP : Version pass tests suite
// 06/03/12 15:25 NDP : DefaultAwakeCommonsConfigurator: Remove all awake internal code
// 09/03/12 19:35 NDP : ConnectionHttp: add getMaxLengthForString() 
// 09/03/12 19:40 NDP : PreparedStatementHttp: test that string and object uploaded are < 
//			HttpProtocolParameters.getMaxLengthForString()
// 10/03/12 13:40 NDP : AwakeFileSession: fix javadocs bugs and and read error from file when 
//			HttpTransfer.setReceiveInFile(true) ==> Impact everywhere on classes
// 10/03/12 14:10 NDP : HttpTransferOne.getUrlContent(): test the string limit size to avoid 
//			outOfMemoryException
// 10/03/12 18:55 NDP : ServerAwakeFileDispatch: comments
// 10/03/12 19:25 NDP : AwakeFileSession: fix bug on downloadFile: invalid login was not correctly trapped
// 03/03/12 19:35 NDP : DefaultAwakeFileActionManager: downloadFile uses now IOUtils.copy()
// 10/03/12 19:55 NDP : HttpTransferOne: fix bug on downloadFile: invalid login was not correctly trapped
// 10/03/12 20:00 NDP : Version pass tests suite
// 10/03/12 20:00 NDP : AwakeFileConfigurator: oneRootPerUsername renamed useOneRootPerUsername
// 10/03/12 20:00 NDP : DefaultAwakeFileConfigurator: oneRootPerUsername renamed useOneRootPerUsername
// 11/03/12 15:35 NDP : HttpProtocolParameters: Clean Javadoc
// 11/03/12 14:05 NDP : HttpProtocolParameters: Clean Javadoc
// 11/03/12 20:20 NDP : Action: add MKDIR_ACTION
// 11/03/12 20:20 NDP : AwakeFileSession: add mkdir() and exists() methods
// 11/03/12 20:25 NDP : AwakeFileActionManager: add mkdir() and exists()
// 11/03/12 20:35 NDP : Action: add MKDIR_ACTION & EXISTS_ACTION
// 11/03/12 20:40 NDP : ServerAwakeFileDispatch: add mkdir() and exists() support
// 12/03/12 15:50 NDP : HttpTransferOne: rename downloadFile() to download()
// 12/03/12 16:00 NDP : AwakeFileSession: clean Javadoc
// 13/03/12 15:45 NDP : Version pass tests suite
// 15/03/12 12:15 NDP : Package org.awakefw.file.servlet.json is suppressed
// 15/03/12 12:15 NDP : ListOfStringTransport: Creation from JsonClientBuilder & JsonServerBuilder
// 15/03/12 12:15 NDP : All Json to/from calls are grouped in ListOfStringTransport
// 15/03/12 14:50 NDP : Version pass tests suite
// 13/03/12 16:15 NDP : AwakeFileSession: free memory with set null in close();
// 16/03/12 18:00 NDP : Version pass tests suite
// 17/03/12 16:45 NDP : Fix Javadoc bugs
// 18/03/12 15:55 NDP : AwakeFileSession: download() throw new IOException(Tag.AWAKE_FAIL 
// 			+ "Invalid received buffer: " + receive); if receive does not contain
// 			InvalidLogin or FileNotFound Exception
// 19/03/12 15:55 NDP : AwakeRemoteException: now extends IOException
// 19/03/12 15:55 NDP : AwakeSecurityException: now extends IOException
// 19/03/12 19:35 NDP : AwakeFileSession: no more AwakeSecurityException
// 19/03/12 19:35 NDP : HttpTransferOne: no more AwakeSecurityException
// 19/03/12 19:35 NDP : ServerCallAction: no more AwakeSecurityException
// 20/03/12 16:45 NDP : Everywhere: AwakeSecurityException is replaced by SecurityException
// 20/03/12 16:45 NDP : Everywhere: AwakeRemoteException is now RemoteException
// 20/03/12 18:20 NDP : AwakeFileSession: clean javadoc
// 20/03/12 18:45 NDP : AwakeCallableNoAuth: new name of AwakeCallableNotAuthenticated
// 21/03/12 17:15 NDP : Fix Javadoc & Version pass test suite
//
// v1.0.5
// 24/03/12 13:50 NDP : AwakeDataSourceFactory: cleaner error messages with Resource name
// 24/03/12 14:20 NDP : AwakeFileManager: configurator members are not anymore static
// 24/03/12 14:30 NDP : AwakeCommonsConfigurator remove (String username, String password)
// 24/03/12 19:35 NDP : DefaultAwakeCommonsConfigurator: remove (String username, String password)
// 27/03/12 16:30 NDP : AwakeFileVersionValues: increment date
// 27/03/12 16:35 NDP : AwakeFileVersionValues: test if awake progress manager is null before testing if canceled
// 27/03/12 17:40 NDP : Fix Javadoc & Version pass test suite
// 27/03/12 20:20 NDP : Add ServerUserException that traps cleanly user exceptions
// 28/03/12 11:25 NDP : Fix version date & pass test suite
// 28/03/12 16:25 NDP : AwakeConnectionPool: startDbConnectionBroker: throw a NullPointerException if Connection is null
// 28/03/12 20:50 NDP : pass test suite
// 29/03/12 11:40 NDP : AwakeFileSession: Add AWAKE_SESSION_IS_CLOSED = "Awake Session is closed."
// 29/03/12 13:45 NDP : AwakeFileManager: trap user configuration errors and send it to client side
// 29/03/12 19:40 NDP : AwakeFileManager: test awakeCommonsConfigurator.login()
// 30/03/12 10:50 NDP : pass test suite
//
// v1.0.6
// 02/04/12 11:30 NDP : AwakeFileSession: test that Java is at least 1.6
// 02/04/12 16:20 NDP : AwakeFileManager: trap complete exception if configuration occurs
// 02/04/12 16:20 NDP : ServerUserException : detect that the throwing class is a Configurator and a specific header
// 			message to exception.getMessage()
// 02/04/12 16:20 NDP : ServerLoginAction: add Tag.AWAKE_USER_CONFIG_FAIL to exception.getMessage()
//			thrown back to client if exception is thrown by a Configurator
// 02/04/12 16:20 NDP : ServerAwakeFileDispatch: add Tag.AWAKE_USER_CONFIG_FAIL to exception.getMessage()
//			thrown back to client if exception is thrown by a Configurator
// 02/04/12 16:20 NDP : ServerFileUploadAction: add Tag.AWAKE_USER_CONFIG_FAIL to exception.getMessage()
//			thrown back to client if exception is thrown by a Configurator
// 02/04/12 17:00 NDP : pass test suite
// 02/04/12 18:30 NDP : ServerAwakeFileDispatch: fix bug: serverCallAction.call was called with null for username
// 02/04/12 18:50 NDP : ServerCallAction Try to get a Connection for allowCallAfterAnalysis
//			Will be null if user has not configured a Connection, without Exception thrown
// 02/04/12 19:05 NDP : pass test suite
// 03/04/12 13:50 NDP : AwakeFileManager: test configurator methods only in get
// 03/04/12 16:35 NDP : ServerUserException : could throw a null pointer Exception. fixed.
// 03/04/12 16:40 NDP : HtmlConverter.toHtml(): supports now escaping non-ASCII - like in Lang Commons 2.6
// 03/04/12 16:45 NDP : pass test suite
// 03/04/12 19:30 NDP : Reuse org.awakefw.file.api.util.StringUtil with org.awakefw.file.api.util.Base64 
//			because of legacy reason (Safester)
// 03/04/12 20:05 NDP : Suppress AwakeBase64 class and usage (use now rg.awakefw.file.api.util.Base64 )
// 04/04/12 16:50 NDP : JavaVersionUtil: creation
// 04/04/12 16:50 NDP : pass test suite
//
// v1.0.7
// 18/04/12 15:05 NDP : Fix distribution bug: org.awakefw.file.util.JavaVersionUtil was not in jar
//
//v1.0.8
//02/05/12 18:00 NDP : ServerLoginAction: if Action.BEFORE_LOGIN_ACTION ==> return forceHttp boolean value
//02/05/12 18:00 NDP : VERSION is now noted DD-mon-YYYY
//02/05/12 18:05 NDP : AwakeFileSession: main constructor now tests if SSL required with Action.BEFORE_LOGIN_ACTION
//		       if SSL is required, constructor changes url with http:// to https://
//02/05/12 19:15 NDP : AwakeFileManager: display Awake SQL version on Tomcat logs + browser
//02/05/12 19:45 NDP : HttpProtocolParameters: add isAcceptAllSslCertificates/setAcceptAllSslCertificates
//02/05/12 20:20 NDP : ServerAwakeFileDispatch: clean variable names
//03/05/12 19:55 NDP : HttpTransferOne: do not set ssl certificat for non https url (http://)
//03/05/12 19:00 NDP : HttpProtocolParameters: clean Javadoc
//03/05/12 19:10 NDP : pass test suite
//
//
//v1.0.9
//27/05/12 21:00 NDP : DbConnectionBroker DEFAULTMAXCHECKOUTSECONDS = 0 ==> Connections are never recycled
//28/05/12 18:50 NDP : HtmlConverter: simple test of '&' presence in string makes fromHtml runs faster
//28/05/12 18:50 NDP : DefaultAwakeCommonsConfigurator: all members are static to be idempotent so that users
//		       may call new DefaultAwakeCommonsConfigurator() and that it does recreate a connection pool

//v1.0.10
//31/05/12 16:25 NDP : ServerAwakeFileDispatch: actionGetListFileLength: We must convert each element of List<String> files from Html
//01/06/12 19:10 NDP : pass test suite
//
//v1.1
//06/07/12 20:10 NDP : HttpTransferOne: add closeHttpClient for getInputStreeam
//06/07/12 20:10 NDP : RemoteInputStream: no more references to DefaultHttpClient
//06/07/12 20:30 NDP : HttpTransferOne: no more swing/awt calls in displayErrroMessageIfNoProxySet
//06/07/12 20:40 NDP : Create AwakeClientLogger: logger that will be used on client side only
//07/07/12 19:45 NDP : FileUtil: add getUserHome()
//07/07/12 19:50 NDP : Everywhere on client user: use FileUtil.getUserHome() to get "user.home" beacause of andro�d
//07/07/12 20:50 NDP : pass test suite
//08/07/12 20:50 NDP : JavaVersionUtil is suppressed
//08/07/12 20:50 NDP : AwakeSystemUtil: create with new isAndroid() method
//09/07/12 12:30 NDP : AwakeClientLogger: create a clean user.home/.awake/AwakeClient.log
//17/07/12 16:15 NDP : version pass test suite
//18/07/12 15:15 NDP : HttpTransferOne: replace deprecated HTTP-UTF8 by "UTF-8"
//25/07/12 17:35 NDP : Sha1: no more reference to "SUN" provider ==> fails on Android
//25/07/12 21:05 NDP : Rewrite all client side tests to be compatible with Android
//26/07/12 15:30 NDP : version pass test suite
//27/07/12 16:05 NDP : MessageDisplayer: is now in package org.awakefw.file.api.util
//27/07/12 18:45 NDP : AwakeSystemUtil: add getSystemProperties
//01/08/12 11:45 NDP : version pass test suite
//
//13/08/12 11:50 NDP : PooledConnection: add better debug
//15/08/12 15:15 NDP : DbConnectionBroker DEFAULTMAXCHECKOUTSECONDS = 180 seconds 
//15/08/12 15:55 NDP : AwakeDataSource: add maxCheckoutSeconds & logAppend parameters 
//15/08/12 15:55 NDP : AwakeConnectionPool: add maxCheckoutSeconds & logAppend parameters 
//15/08/12 15:55 NDP : AwakeDataSource: add maxCheckoutSeconds & logAppend parameters 
//15/08/12 16:05 NDP : AwakeDataSource: add getters to DbConnectionBroker idOfConnection() 
//		       / getAge(Connection conn) / getSize() /  getUseCount()
//15/08/12 15:55 NDP : AwakeDataSourceFactory: add maxCheckoutSeconds & logAppend parameters 
//16/08/12 10:26 NDP : version pass test suite

//v1.1.1b
//11/04/19 11:33 NDP : ServerCallAction: Force close of Connections 
//
//v1.1.1c
//18/05/19 15:24 NDP : allow to pass 2FA code
//
//v1.1.1d
//17/06/19 19:08 NDP : AwakeFileSession: make constructor with token public
//
//v1.1.1e
//26/06/19 23:35 NDP : Add CredentialsStore
//26/06/19 23:35 NDP : ServerCallAction & all other servlet classes: NO more AwakeLogger
//
//v1.1.1f
//03/07/19 12:38 NDP : HttpTransferOne: replace HttpClient lib with native Java HttpURLConnection (wrapped with KawanHttpClient)
//04/07/19 16:47 NDP : No HttpClient dependencies
//04/07/19 18:15 NDP : MultipartUtility: no use of CR_LF == \r\n instead, otw will fail on Mac
//
//v1.1.1g
//12/07/19 13:05 NDP : Prepare AwakeFileManager.service for Async
//12/07/19 15:05 NDP : Async done! (Pool size 50 ==> 100 instead of 100 ==> 200)
//
//v1.1.1h
//11/50/19 11:50 NDP : AwakeFileSession: make public constructor with token because of Safester need
//
//v1.1.1i
//10/10/19 15:39 NDP : KawanHttpClient: Add callWithPostMultiPart
//12/10/19 12:25 NDP : KawanHttpClient: Allows to get current uploaded file name 

/**
 * Contains the Awake File Version info.
 */

public class AwakeFileVersionValues {
    public static final String VERSION = "v1.1.1i";
    public static final String DATE = "12-Oct-2019";
}

// End
