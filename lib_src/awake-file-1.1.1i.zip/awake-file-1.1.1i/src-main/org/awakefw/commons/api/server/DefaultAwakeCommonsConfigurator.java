/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.api.server;

//DefaultAwakeCommonsConfigurator
//Copyright (c) Kawan Softwares S.A.S, 2012
//
//Last Updates: 
// 12 juil. 07 21:44:29 Nicolas de Pomereu
// 19/10/07 13:44 ABE : Allow doctors to connect
// 22/09/09 13:44 NDP : Uses new mechanism
// 23/09/09 15:30 NDP : Fix bug: doctors were always authorized 
// 15/12/09 15:25 NDP : Fix bug: admin could not log in!
// 15/09/09 16:00 NDP : Fix bug: doctors were not authorized (necessary for applet)
// 21/01/10 19:30 NDP - Add getCallableClassesWithoutAuthentication()
// 26/01/10 19:55 NDP - Add allowFileTransferOperation() & allowSqlOperation
// 03/10/10 16:40 NDP - Return  empty ArrayList instead of null
// 18/11/10 15:10 NDP : Add getEncryptionPasswordForHttpParameters()
// 10/03/11 15:40 NDP - DefaultAwakeCommonsConfigurator: add Comments to get/freeConnection()
// 15/03/11 17:20 NDP - DefaultAwakeCommonsConfigurator: add setAwakeJdbcInfoIni()
//
// 17/03/11 19:05 NDP - DefaultAwakeCommonsConfigurator: add getConnection(String awakeJdbcInfoIniStr) 
// 17/03/11 19:10 NDP - DefaultAwakeCommonsConfigurator: remove (File awakeJdbcInfoIni) method
// 18/03/11 18:25 NDP - DefaultAwakeCommonsConfigurator: Comments
// 19/04/11 12:25 NDP - DefaultAwakeCommonsConfigurator: suppress awakeJdbcInfoIni/dbPassword fields
// 03/06/11 18:55 NDP - DefaultAwakeCommonsConfigurator: Refactor checkLoginAndPassword() to login
// 09/06/11 16:15 NDP : DefaultAwakeCommonsConfigurator: add getBannedUsernames()
// 20/09/11 18:45 NDP : DefaultAwakeCommonsConfigurator: getBannedUsernames throws IOException & SQLException
// 20/09/11 18:45 NDP : DefaultAwakeCommonsConfigurator: getBannedIPs throws IOException & SQLException
// 20/09/11 18:45 NDP : DefaultAwakeCommonsConfigurator: login throws IOException & SQLException
// 20/09/11 18:45 NDP : DefaultAwakeCommonsConfigurator: freeConnection throws SQLException
// 20/09/11 19:45 NDP : DefaultAwakeCommonsConfigurator: addSecretForAuthToken throws IOException & SQLException
// 09/11/11 19:15 NDP : DefaultAwakeCommonsConfigurator: Add debug support
// 09/11/11 19:15 NDP : DefaultAwakeCommonsConfigurator: getConnection() uses the jdbc/awake-default resource
// 10/11/11 11:05 NDP : DefaultAwakeCommonsConfigurator: cleaner Exception messages on getConnection()
// 14/11/11 16:55 NDP : DefaultAwakeCommonsConfigurator: add getLoggingDirectory
// 21/11/11 13:25 NDP : DefaultAwakeCommonsConfigurator: add getConnection(String username, String password)
// 22/11/11 12:35 NDP : DefaultAwakeCommonsConfigurator: better Javadoc comments
// 23/11/11 13:30 NDP : DefaultAwakeCommonsConfigurator: getPasswordForHttpRequestEncryption()
// 			renamed to getEncryptionPassword()
// 19/12/11 21:30 NDP : DefaultAwakeCommonsConfigurator: DataSource ds is now a member (pool created only once)
// 10/01/12 19:00 NDP : getLogger() is now in user.home/.awake/log/Awake.log & clean Javadoc
// 16/02/12 15:50 NDP : DefaultAwakeCommonsConfigurator: add computeAuthToken()
// 23/02/12 11:50 NDP : DefaultAwakeCommonsConfigurator: clean Javadoc
// 03/03/12 17:55 NDP : DefaultAwakeCommonsConfigurator: clean Javadoc for getLogger()
// 05/03/12 20:50 NDP : DefaultAwakeCommonsConfigurator: Logger is now a static member
// 06/03/12 15:25 NDP : DefaultAwakeCommonsConfigurator: Remove all awake internal code
// 24/03/12 19:35 NDP : DefaultAwakeCommonsConfigurator: remove (String username, String password)
// 28/05/12 18:50 NDP : DefaultAwakeCommonsConfigurator: all members are static to be idempotent so that users
//			may call new DefaultAwakeCommonsConfigurator() and that it does recreate a connection pool

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.awakefw.commons.api.server.util.ServerInfo;
import org.awakefw.commons.api.server.util.Sha1;
import org.awakefw.file.util.Tag;

/**
 * 
 * Default implementation of the commons User Configuration for the Awake
 * Framework.
 * <p>
 * This defaults implementation will help for a quick start and to test the
 * Awake Framework, but <i><u>please note that is implementation is not secure
 * at all</i></u>. <br>
 * Especially: the <code>login</code> method will always return
 * <code>true</code>.
 * <p>
 * So:
 * <ul>
 * <li>The <code>forceSecureHttp</code> method should be set to true by your
 * implementation in order to prevent the login info and the data to be send in
 * clear over the Internet with http protocol</li>
 * frameworks.</li>
 * <li>The <code>login</code> method should be overridden by your specific
 * implementation.</li>
 * </ul>
 * <p>
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */

public class DefaultAwakeCommonsConfigurator implements
	AwakeCommonsConfigurator {

    /** The Logger to use */
    private static Logger AWAKE_LOGGER = null;

    /** The data source to use for connection pooling */
    private static DataSource DATA_SOURCE = null;

    /**
     * Constructor.
     */
    public DefaultAwakeCommonsConfigurator() {

    }

    /**
     * @return <code>false</code>. (Client programs will be allowed to send
     *         unsecured http requests).
     */
    @Override
    public boolean forceSecureHttp() {
	return false;
    }

    /**
     * @return Empty <code><b>HashSet</code></b>. (No banned IP usernames.)
     */
    @Override
    public Set<String> getBannedUsernames() throws IOException, SQLException {
	return new HashSet<String>();
    }

    /**
     * @return Empty <code><b>ArrayList</code></b>. (No banned IP addresses.)
     */
    @Override
    public List<String> getBannedIPs() throws IOException, SQLException {
	return new ArrayList<String>(); // Empty ArrayList
    }

    /**
     * @return <code>true</code>. (Client is always granted access).
     */
    @Override
    public boolean login(String username, char[] password) throws IOException,
	    SQLException {
	return true;
    }

    /**
     * @return the Connection extracted from the {@link AwakeDataSource}
     *         {@code DataSource} defined as a {@code 'jdbc/awake-default'}
     *         Resource in {@code server.xml} or {@code context.xml}. The Awake
     *         DataSource implements a default connection pool manager.
     */
    @Override
    public Connection getConnection() throws SQLException {

	if (DATA_SOURCE == null) {
	    String defaultResourceName = "jdbc/awake-default";

	    try {
		Context initCtx0 = (Context) new InitialContext()
			.lookup("java:comp/env");
		DATA_SOURCE = (DataSource) initCtx0.lookup(defaultResourceName);

	    } catch (NamingException e) {
		String message = Tag.AWAKE_USER_CONFIG_FAIL
			+ "Invalid <Resource> configuration. Lookup failed on Resource "
			+ defaultResourceName;
		throw new SQLException(message, e);
	    }
	}

	Connection connection = DATA_SOURCE.getConnection();
	return connection;
    }

    /**
     * @return <b><code>null</code></b>. It is highly recommended to override
     *         this method in order to set a secret value in order to reinforce
     *         the security of the Awake Server.
     */
    @Override
    public String addSecretForAuthToken() throws IOException, SQLException {
	return null;
    }

    /**
     * 
     * This default method is secure if client side always use SSL/TLS httpS
     * calls. <br>
     * <br>
     * You may override the method if you want to create the Authentication
     * Token with your own security rules (adding random values stored in
     * database, etc.)
     * 
     * @return <code>SHA-1(username + hostname + {@link #addSecretForAuthToken()})</code>
     *         first 20 hexadecimal characters.<br>
     *         where:
     *         <ul>
     *         <li>hostname: the hostname returned by the Unix/Linux/Window
     *         shell command "hostname" on the server side.</li>
     *         </ul>
     */
    @Override
    public String computeAuthToken(String username) throws Exception {

	// Add more secret info very hard to find for an external hacker
	StringBuilder tokenBuilder = new StringBuilder();
	tokenBuilder.append(username);
	tokenBuilder.append(ServerInfo.getHostname());

	if (addSecretForAuthToken() != null) {
	    tokenBuilder.append(addSecretForAuthToken());
	}

	Sha1 hashcode = new Sha1();
	String token = hashcode
		.getHexHash((tokenBuilder.toString()).getBytes());

	token = StringUtils.left(token, 20);

	return token;
    }

    /**
     * @return <b><code>null</code></b>. It is highly recommended to override
     *         this method in order to set a secret password in order to
     *         reinforce the security of the transport of request parameters.
     */

    @Override
    public char[] getEncryptionPassword() {
	return null;
    }

    /**
     * @return a Logger whose pattern is located in
     *         <code>user.home/.awake/log/Awake.log</code>, that uses a
     *         <code>SimpleFormatter</code> and that logs 50Mb into 4 rotating
     *         files.
     */

    @Override
    public Logger getLogger() throws IOException {

	if (AWAKE_LOGGER == null) {
	    String userHome = System.getProperty("user.home");
	    if (!userHome.endsWith(File.separator)) {
		userHome += File.separator;
	    }

	    File logDir = new File(userHome + ".awake" + File.separator + "log");
	    logDir.mkdirs();

	    String logFilePattern = logDir.toString() + File.separator
		    + "Awake.log";

	    AWAKE_LOGGER = Logger.getLogger("AwakeLogger");
	    int limit = 50 * 1024 * 1024;
	    Handler fh = new FileHandler(logFilePattern, limit, 4, true);
	    fh.setFormatter(new SimpleFormatter());
	    AWAKE_LOGGER.addHandler(fh);
	}

	return AWAKE_LOGGER;
    }

    /**
     * Default usage is that no 2FA acheck is done.
     * @return true
     */
    @Override
    public boolean check2faCode(String username, String double2faCode) throws IOException, SQLException {
	return true;
    }

}
