/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.api.server;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Interface that defines the common User Configuration for the Awake File and
 * Awake SQL Frameworks.
 * <p>
 * All the implemented methods will be called by the Awake Server programs when
 * a client program asks for access to the database from the remote Client side.
 * <p>
 * A concrete implementation should be developed on the Server side by a Awake
 * users in order to:
 * <ul>
 * <li>Define how to extract a JDBC Connection from a Connection Pool.</li>
 * <li>Define how to authenticate the remote (username, password) couple send by
 * the client side.</li>
 * <li>Define if the client must be in secured https prior to authentication.</li>
 * <li>Define the list of banned usernames.</li>
 * <li>Define the list of banned IPs.</li>
 * <li>Define a secret value to reinforce the strength of the hash value used
 * for Authentication Token.</li>
 * <li>Define a password that will be used to encrypt the http request
 * parameters sent by the client side.</li>
 * <li>Code the method that will compute a secure Authentication Token.</li>
 * <li>Define the Logger for Awake internal logging.</li>
 * </ul>
 * Please note that Awake comes with a Default AwakeCommonsConfigurator
 * implementation that may be extended:
 * <code>DefaultAwakeCommonsConfigurator</code>.
 * 
 * @see DefaultAwakeCommonsConfigurator
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */
public interface AwakeCommonsConfigurator {
    /**
     * Allows to define if the host url must be accessed in secured httpS.
     * 
     * If true, the Awake File Manager or Awake SQL Manager (AwakeFileManager or
     * AwakeSqlManager Servlet) will ask the client side to convert the url
     * scheme from "http" to secure "https" for all server requests. This will
     * be done automatically on the client side prior to authentication.
     * 
     * @return <code>true</code> if the host url must be in httpS
     */
    public boolean forceSecureHttp();

    /**
     * Allows to define the set of banned usernames. The Awake Server will
     * refuse access to client programs calling with a username in the set.
     * <p>
     * 
     * @return the set of banned usernames that are not allowed to access the
     *         service
     * @throws IOException
     *             if an IOException occurs
     * @throws SQLException
     *             if a SQLException occurs
     */
    public Set<String> getBannedUsernames() throws IOException, SQLException;

    /**
     * Allows to define the list of banned IP addresses. The Awake Server will
     * refuse access to client programs calling with an address in the list.
     * <p>
     * Subnet notations are supported: 1.1.1.1/255.255.255.255 or 1.1.1.1/32
     * (CIDR-Notation).
     * <p>
     * 
     * @return the list of banned IP addresses, that are not allowed to access
     *         the service
     * @throws IOException
     *             if an IOException occurs
     * @throws SQLException
     *             if a SQLException occurs
     */
    public List<String> getBannedIPs() throws IOException, SQLException;

    /**
     * Allows to authenticate the remote (username, password) couple send by the
     * client side and to give access to the Awaker Server.
     * <p>
     * The Awake Server will call the method in order to grant or not client
     * access.
     * <p>
     * Typical usage would be to check the (username, password) couple against a
     * table in a SQL database or against a LDAP, etc.
     * 
     * @param username
     *            the username sent by the client login
     * @param password
     *            the password to connect to the server
     *            <p>
     * @return <code>true</code> if the (login, password) couple is
     *         correct/valid. If false, the client side will not be authorized
     *         to send any command.
     * @throws IOException
     *             if an IOException occurs
     * @throws SQLException
     *             if a SQLException occurs
     */
    public boolean login(String username, char[] password) throws IOException,
	    SQLException;

    /**
     * <p>
     * Attempts to establish a connection with an underlying data source.
     * 
     * @return a connection to the data source
     * @exception SQLException
     *                if a database access error occurs
     */
    public Connection getConnection() throws SQLException;

    /**
     * Allows to define a secret value that will enforce the security of the
     * authentication defined in <code>computeAuthToken</code>.
     * 
     * @return the secret value to enforce the secure the authentication defined
     *         in <code>computeAuthToken</code>.
     * 
     * @see #computeAuthToken
     * 
     * @throws IOException
     *             if an IOException occurs
     * @throws SQLException
     *             if a SQLException occurs
     */
    public String addSecretForAuthToken() throws IOException, SQLException;

    /**
     * Allows to compute a secret value that will secure the authentication. <br>
     * <br>
     * After login() succeeds, the method uses username and the value returned
     * by {@link #addSecretForAuthToken()} to build and Authentication Token
     * that will be use by each following client call in order to authenticate
     * the calls. <br>
     * <br>
     * The Authentication Token default value built by the default
     * implementation in
     * {@link DefaultAwakeCommonsConfigurator#computeAuthToken(String)}
     * is: <br>
     * <code>SHA-1(username + hostname + addSecretForAuthToken()</code> first 20
     * hexadecimal characters.<br>
     * where:
     * <ul>
     * <li>username: the username of the client.</li>
     * <li>hostname: the hostname returned by the Unix/Linux/Window shell
     * command "hostname" on the server side.</li>
     * </ul>
     * The Awake Server will use this value to reinforce the strength of the
     * hash value used for Authentication Token at each method call.
     * 
     * @param username
     *            the database user on whose behalf the connection is being made
     * 
     * @return the computed Authentication Token that will be verified and
     *         recomputed at each client call.
     * 
     * @throws Exception
     *             if an Exception occurs
     */
    public String computeAuthToken(String username) throws Exception;

    /**
     * Allows to define the password that is used to encrypt from the Client all
     * the request parameters values for security reason (obfuscation and
     * transport encryption).
     * 
     * @return the password used to encrypt from Client all the request
     *         parameters values for security reason.
     */
    public char[] getEncryptionPassword();

    /**
     * Returns the {@link Logger} that will be used by Awake File or Awake SQL
     * logging:
     * <ul>
     * <li>All Exceptions thrown by server side will be logged.</li>
     * <li>Exceptions thrown are logged with <code>Level.WARNING</code>.</li>
     * </ul>
     * It is not necessary nor recommended to implement this method; do it only
     * if you want take control of the logging to modify the default
     * characteristics of {@link DefaultAwakeCommonsConfigurator#getLogger()}.
     * 
     * @return the java.util.logging.Logger that will be used by Awake File or
     *         Awake SQL logging;
     */
    public Logger getLogger() throws IOException;

    /**
     * Checks the 2FA auth. If 2FA is set for this username, double2faCode will be checked
     * @param username		the username to check the 2FA for
     * @param double2faCode	the 2FA 6 digits code
     * @return true if 2FA is not set for userna�e or if 2FA is set and code is valid.
     * @throws IOException
     *             if an IOException occurs
     * @throws SQLException
     *             if a SQLException occurs
     */
    public boolean check2faCode(String username, String double2faCode) throws IOException, SQLException;

}
