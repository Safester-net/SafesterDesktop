/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.kawansoft.httpclient;

import static java.lang.System.currentTimeMillis;
import static java.net.URLConnection.guessContentTypeFromName;
import static java.util.logging.Logger.getLogger;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Logger;

import org.apache.commons.io.IOUtils;
import org.awakefw.commons.api.client.AwakeProgressManager;
import org.awakefw.file.http.HttpTransfer;

/**
 * @author Nicolas de Pomereu
 *
 */
public class MultipartUtility {

    public boolean DEBUG = false;

    @SuppressWarnings("unused")
    private static final Logger log = getLogger(MultipartUtility.class.getName());

    // Keep this! No System.getProperty("line.separator") that fails on
    // Android
    private static final String CRLF = "\r\n";

    private static final String CHARSET = "UTF-8";

    private HttpURLConnection connection;

    private final OutputStream outputStream;
    private final Writer writer;
    private final String boundary;

    // for log formatting only
    @SuppressWarnings("unused")
    private final URL url;
    @SuppressWarnings("unused")
    private final long start;

    private long filesLength;

    private AwakeProgressManager awakeProgressManager = null;

    private String currentFilename = null;

    public MultipartUtility(final URL url, HttpURLConnection connection, int connectTimeout,
	    AwakeProgressManager awakeProgressManager) throws IOException {
	start = currentTimeMillis();

	if (url == null) {
	    throw new IllegalArgumentException("url is null!");
	}

	if (connection == null) {
	    throw new IllegalArgumentException("connection is null!");
	}

	this.awakeProgressManager = awakeProgressManager;
	this.url = url;
	this.connection = connection;

	boundary = "---------------------------" + currentTimeMillis();

	this.connection.setRequestProperty("Accept-Charset", CHARSET);
	this.connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

	// outputStream = connection.getOutputStream();
	//TimeoutConnector timeoutConnector = new TimeoutConnector(connection, connectTimeout);
	//outputStream = timeoutConnector.getOutputStream();
	outputStream = new BufferedOutputStream(connection.getOutputStream());
	
	writer = new PrintWriter(new OutputStreamWriter(outputStream, CHARSET));
    }

    /**
     * @return true is there is an owner AND it's interrupted
     */
    private boolean isAwakeProgressManagerInterrupted() {
	if (awakeProgressManager == null) {
	    return false;
	}

	debug("awakeProgressManager.isCancelled(): " + awakeProgressManager.isCancelled());

	return awakeProgressManager.isCancelled();
    }

    /**
     * Set the owner current value for progression bar
     * 
     * @param current
     */
    private void addOneToAwakeProgressManager() {
	if (awakeProgressManager != null) {
	    int current = awakeProgressManager.getProgress();
	    current++;

	    if (current < HttpTransfer.MAXIMUM_PROGRESS_100) {
		awakeProgressManager.setProgress(current);
	    }
	}
    }

    public void addFormField(final String name, final String value) throws IOException {
	
	if (name == null) {
	    throw new NullPointerException("name cannot be null!");
	}
	if (value == null) {
	    throw new NullPointerException("value cannot be null!");
	}
		
	writer.append("--").append(boundary).append(CRLF).append("Content-Disposition: form-data; name=\"").append(name)
		.append("\"").append(CRLF).append("Content-Type: text/plain; charset=").append(CHARSET).append(CRLF)
		.append(CRLF).append(value).append(CRLF);
    }

    public void addFilePart(final String fieldName, InputStream inputStream, String fileName)
	    throws IOException, InterruptedException {
	
	if (fieldName == null) {
	    throw new NullPointerException("fieldName cannot be null!");
	}
	if (inputStream == null) {
	    throw new NullPointerException("inputStream cannot be null!");
	}
	if (fileName == null) {
	    throw new NullPointerException("fileName cannot be null!");
	}	
	
	this.currentFilename = fileName;
	
	// final String fileName = uploadFile.getName();
	writer.append("--").append(boundary).append(CRLF).append("Content-Disposition: form-data; name=\"")
		.append(fieldName).append("\"; filename=\"").append(fileName).append("\"").append(CRLF)
		.append("Content-Type: ").append(guessContentTypeFromName(fileName)).append(CRLF)
		.append("Content-Transfer-Encoding: binary").append(CRLF).append(CRLF);

	writer.flush();
	// outputStream.flush();

	uploadUsingInputStream(inputStream);
	// HACK NDP 10/10/19
	writer.append(CRLF);
	writer.flush();  

    }

    public void addFilePart(final String fieldName, final File uploadFile) throws IOException, InterruptedException {
	
	if (fieldName == null) {
	    throw new NullPointerException("fieldName cannot be null!");
	}
	if (uploadFile == null) {
	    throw new NullPointerException("uploadFile cannot be null!");
	}
	if (! uploadFile.exists()) {
	    throw new FileNotFoundException("uploadFile does not exists:" + uploadFile);
	}
	
	final String fileName = uploadFile.getName();
	this.currentFilename = fileName;
	
	writer.append("--").append(boundary).append(CRLF).append("Content-Disposition: form-data; name=\"")
		.append(fieldName).append("\"; filename=\"").append(fileName).append("\"").append(CRLF)
		.append("Content-Type: ").append(guessContentTypeFromName(fileName)).append(CRLF)
		.append("Content-Transfer-Encoding: binary").append(CRLF).append(CRLF);

	writer.flush();
	// outputStream.flush();

	InputStream inputStream = new BufferedInputStream(new FileInputStream(uploadFile));
	uploadUsingInputStream(inputStream);
	
	// HACK NDP 10/10/19
	writer.append(CRLF);
	writer.flush();  

    }
    
    private void uploadUsingInputStream(InputStream inputStream) throws IOException, InterruptedException {
	try {

	    addOneToAwakeProgressManager();

	    /*
	     * int readBufferSize = 4096;
	     * 
	     * final byte[] buffer = new byte[readBufferSize]; int bytesRead; while
	     * ((bytesRead = inputStream.read(buffer)) != -1) { outputStream.write(buffer,
	     * 0, bytesRead); }
	     */

	    if (awakeProgressManager != null) {
		this.filesLength = awakeProgressManager.getLengthToTransfer();
	    }

	    debug("Uploading data!");
	    debug("filesLength: " + filesLength);

	    
	    // Case no progress/cancelled/totaLenth set: direct copy
	    if (filesLength <= 0 || awakeProgressManager == null) {
		IOUtils.copy(inputStream, outputStream);
		return;
	    }
	    
	    int tempLen = 0;
	    byte[] buffer = new byte[4096 * 10];
	    int n = 0;

	    while ((n = inputStream.read(buffer)) != -1) {
		
		debug("uploading: " + n);
		
		tempLen += n;

		if (filesLength > 0 && tempLen > filesLength / HttpTransfer.MAXIMUM_PROGRESS_100) {
		    tempLen = 0;
		    
		    try {
			Thread.sleep(10); // TODO: adjust sleep time
			// depending on fileIn length
		    } catch (InterruptedException e) {
			e.printStackTrace();
		    }
		    
		    // For ProgressMonitor
		    // progress bar

		    addOneToAwakeProgressManager();

		    if (isAwakeProgressManagerInterrupted()) {
			debug("writeTo() INTERRUPTED!");
//			throw new HttpTransferInterruptedException(Tag.AWAKE
//				+ "File upload interrupted by user.");

			return;
		    }
		}

		outputStream.write(buffer, 0, n);
		//outputStream.flush();
		//writer.flush();
	    }

	    //outputStream.flush();
	    //writer.append(CRLF); // No! will fail by adding it to the uploaded file
	} finally {

	    if (inputStream != null) {
		try {
		    inputStream.close();
		} catch (Exception ignore) {
		    // ignore
		}
	    }
	    
	    outputStream.flush();
	    writer.flush();
	}
    }

    public void addHeaderField(String name, String value) throws IOException {
	writer.append(name).append(": ").append(value).append(CRLF);
    }

    public void finish() throws IOException {
	writer.append(CRLF).flush();
	writer.append("--").append(boundary).append("--").append(CRLF);
	writer.flush();
	writer.close();

    }

    /**
     * Returns the current HttpUrlConnection in use.
     * 
     * @return the current HttpUrlConnection in use
     */
    public HttpURLConnection getConnection() {
	return connection;
    }

    
    public String getCurrentFilename() {
        return currentFilename;
    }

    private void debug(String s) {
	if (DEBUG) {
	    System.out.println(new java.util.Date() +  " " + MultipartUtility.class.getSimpleName() + " " + s);
	}
    }
}
