/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.UnknownServiceException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.ProtocolException;

import com.safelogic.pgp.api.util.crypto.PgpUserId;
import com.safelogic.pgp.api.util.msg.LanguageManager;
import com.safelogic.pgp.api.util.parms.Parms;
import com.safelogic.pgp.apispecs.HttpTransfer;
import com.safelogic.pgp.util.Util;

/**
 * API neeeded for registration phasis:
 * <br> - Send userId to server for token building.
 * <br> - Send token + userId to server for validation.
 * @author Nicolas de Pomereu
 */
public class PgeepRegister
{
    /** The debug flag */ 
    protected boolean DEBUG = true; //Debug.isSet(this);
    
    /** The error Manager */
    private ErrorManager errorMan;
    
    /**
     * Constructor
     */
    public PgeepRegister()
    {
        errorMan = new ErrorManager();
    }


    /**
     * @return Returns tuee if the opeation is Ok.
     */
    public boolean isOperationOk()
    {
        return this.errorMan.isOperationOk();
    }
    
    /**
     * @return the Error Code as a generic string
     */
    public String getErrorCode()
    {
        return this.errorMan.getErrorCode();
    }

    /**
     * Get a clean error label that may be displayed to the final user
     * @return the error label
     */
    public String getErrorLabel()
    {
        return this.errorMan.getErrorLabel();
    }
    
    /**
     * @return the last Exception stack trace as a String.
     */
    public String getStackTrace()
    {
        return this.errorMan.getStackTrace();
    }
        
    /**
     * Sends the try-to-register user Id to server and ask for register 
     * email send from server to client
     * 
     * @param userId        the candidate User Id
     * @param receiveInfos  if true, the user will be registered to the mailing list
     * 
     * @return the Register Status send back by the server:
     * <br> - REGISTER_IS_SUSPENDED         : the registration process is suspended
     * <br> - REGISTER_ERROR_EMAIL_NOT_SEND : The registration email could not be send
     * <br> - REGISTER_OK_EMAIL_SEND        : Registration is OK and email has been send
     */
    public int sendUserIdForRegister(String userId, boolean receiveInfos)
    {
                
        PgpUserId pgpUserId = null;

        try
        {
            errorMan.setOperationOk();
            pgpUserId = new PgpUserId(userId);
        }
        catch (IllegalArgumentException e)
        {
            errorMan.setErrorCode(Parms.ERR_INVALID_USER_ID, e);
            return 0;        
        }
                
        Map<String, String> mapRecv = new HashMap();
        
        // The action is eitheir Parms.ACTION_EXISTS_PUBKEY or Parms.ACTION_EXISTS_PRIVKEY
        mapRecv.put(Parms.ACTION, Parms.ACTION_UPLOAD_USERID);
        mapRecv.put(Parms.USER_NAME, pgpUserId.getUserName());
        mapRecv.put(Parms.USER_EMAIL, pgpUserId.getKeyId());
        mapRecv.put(Parms.RECEIVE_INFOS, Boolean.toString(receiveInfos));
        mapRecv.put(Parms.USER_LANGUAGE, LanguageManager.getLanguage());
        
        // Put the Map into a String
        String string = mapRecv.toString();
        
        // Prepare the HTTP output
        HttpTransfer httpTransfer = new HttpTransferOne();
                      
        try
        {
            // Send!
            errorMan.setOperationOk();
            httpTransfer.send(string);
        }
        catch (ConnectException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_CONNECT_EXCEPTION, e1);
            return 0; 
        }
        catch (SocketException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_SOCKET_EXCEPTION, e1);
            return 0;             
        }
        catch (UnknownServiceException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_UNKNOWN_SERVICE_EXCEPTION, e1);
            return 0;           
        }
        catch (ProtocolException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_PROTOCOL_EXCEPTION, e1);
            return 0;            
        }
        catch (IOException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_IO_EXCEPTION, e1);
            return 0;             
        }
                    
        // Ok, get the key from the stream
        String recv = httpTransfer.recv();
        
        Map<String, String> map = Util.toMap(recv);
        
        String registerStatus= map.get(Parms.REGISTER_STATUS);    
        
        debug("registerStatus: " + registerStatus + ":");
        
        return Integer.parseInt(registerStatus);
                
    }
    
    /**
     * Sends the try-to-register Hash Id to server to test validity
     * 
     * @param hashId        the candidate Hash Id
     * 
     * @return  true if the Hash Id is valid
     */
    public boolean sendHashIdToCheck(String hashId)
    {
                               
        Map<String, String> mapRecv = new HashMap();
        
        // The action is eitheir Parms.ACTION_EXISTS_PUBKEY or Parms.ACTION_EXISTS_PRIVKEY
        mapRecv.put(Parms.ACTION, Parms.ACTION_UPLOAD_HASHID);
        mapRecv.put(Parms.HASH_ID, hashId);
        
        // Put the Map into a String
        String string = mapRecv.toString();
        
        // Prepare the HTTP output
        HttpTransfer httpTransfer = new HttpTransferOne();
                      
        try
        {
            // Send!
            errorMan.setOperationOk();
            httpTransfer.send(string);
        }
        catch (ConnectException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_CONNECT_EXCEPTION, e1);
            return false; 
        }
        catch (SocketException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_SOCKET_EXCEPTION, e1);
            return false;             
        }
        catch (UnknownServiceException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_UNKNOWN_SERVICE_EXCEPTION, e1);
            return false;           
        }
        catch (ProtocolException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_PROTOCOL_EXCEPTION, e1);
            return false;            
        }
        catch (IOException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_IO_EXCEPTION, e1);
            return false;             
        }
                    
        // Ok, get the key from the stream
        String recv = httpTransfer.recv();
        
        Map<String, String> map = Util.toMap(recv);
        
        String hashIdTokenValidity = map.get(Parms.HASHID_TOKEN_VALIDITY);    
        
        debug("hashIdTokenValidity: " + hashIdTokenValidity + ":");
        
        return Boolean.parseBoolean(hashIdTokenValidity);
                
    }    

    /**
     * debug tool
     */
    private void debug(String s)
    {
        if (DEBUG)
        {
            System.out.println(s);
            //System.out.println(this.getClass().getName() + " " + new Date() + " " + s);
        }
    }   
    
}

/**
 * 
 */
