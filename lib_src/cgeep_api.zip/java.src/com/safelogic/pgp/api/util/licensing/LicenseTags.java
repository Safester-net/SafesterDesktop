/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api.util.licensing;

public class LicenseTags
{
    // Chars
    protected static String space       = " ";
    protected static String _underscore = "_";
    protected static String column      = ":";
    protected static String dot         = ".";
    protected static String exclam      = "!";
    
    // Lowercase
    protected static String r = "r";
    protected static String s = "s";
    protected static String t = "t";
    
    protected static String o = "o";
    protected static String p = "p";
    protected static String q = "q";    
    
    protected static String i = "i";
    protected static String j = "j";
    protected static String k = "k";
    
    protected static String x = "x";
    protected static String y = "y";
    protected static String z = "z";
    
    protected static String l = "l";
    protected static String m = "m";
    protected static String n = "n";

    protected static String u = "u";
    protected static String v = "v";
    protected static String w = "w";

    protected static String d = "d";
    protected static String e = "e";
    protected static String f = "f";
    
    protected static String g = "g";
    protected static String h = "h";
    
    protected static String a = "a";
    protected static String b = "b";
    protected static String c = "c";
    
    //  Uppercase
    protected static String R = "R";
    protected static String S = "S";
    protected static String T = "T";
                                    
    protected static String O = "O";
    protected static String P = "P";
    protected static String Q = "Q";
                                    
    protected static String I = "I";
    protected static String J = "J";
    protected static String K = "K";
                                    
    protected static String X = "X";
    protected static String Y = "Y";
    protected static String Z = "Z";
                                    
    protected static String L = "L";
    protected static String M = "M";
    protected static String N = "N";
                                    
    protected static String U = "U";
    protected static String V = "V";
    protected static String W = "W";
                                    
    protected static String D = "D";
    protected static String E = "E";
    protected static String F = "F";
                                    
    protected static String G = "G";
    protected static String H = "H";
                                    
    protected static String A = "A";
    protected static String B = "B";
    protected static String C = "C";
    
    
    
}

