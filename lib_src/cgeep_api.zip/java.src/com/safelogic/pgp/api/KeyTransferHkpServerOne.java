/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.UnknownServiceException;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.ProtocolException;
import org.apache.commons.lang3.StringUtils;

import com.safelogic.pgp.api.util.crypto.PgpUserId;
import com.safelogic.pgp.api.util.parms.Parms;
import com.safelogic.pgp.api.util.parms.PgpTags;
import com.safelogic.pgp.apispecs.HttpTransfer;
import com.safelogic.pgp.apispecs.KeyHandler;
import com.safelogic.pgp.apispecs.KeyTransferHkpServer;
import com.safelogic.pgp.apispecs.StringTriplet;
import com.safelogic.pgp.util.JOptionPaneCustom;
import com.safelogic.utilx.Debug;

/**
 * @author Nicolas de Pomereu
 * <br>
 * KeyTransferHkpServer concrete implementation
 */
public class KeyTransferHkpServerOne implements KeyTransferHkpServer 
{
    /** The limit of full public keys that may be imported in one request */
    private static int LIMIT_FOR_FULL_KEYS_NUMBER = 200;
    
	/** The debug flag */ 
	protected boolean DEBUG = Debug.isSet(this);
    
    /** The error Manager */
    private ErrorManager errorMan;
	
    /** The HKP Server url, with port included */    
    private String serverUrl = null;
    
	/**
	 * Constructor
	 * @param serverUrl The HKP Server url, with port included 
	 */
	public KeyTransferHkpServerOne(String serverUrl)
	{
	    this.serverUrl = serverUrl;
        this.errorMan = new ErrorManager();
	}


    /* (non-Javadoc)
     * @see com.safelogic.pgp.api.KeyTransferHkpServer#isOperationOk()
     */
    public boolean isOperationOk()
    {
        return this.errorMan.isOperationOk();
    }
    
    /* (non-Javadoc)
     * @see com.safelogic.pgp.api.KeyTransferHkpServer#getErrorCode()
     */
    public String getErrorCode()
    {
        return this.errorMan.getErrorCode();
    }

    /* (non-Javadoc)
     * @see com.safelogic.pgp.api.KeyTransferHkpServer#getException()
     */
    public Exception getException()
    {
        return this.errorMan.getException();
    }
    
    
    /* (non-Javadoc)
     * @see com.safelogic.pgp.api.KeyTransferHkpServer#getErrorLabel()
     */
    public String getErrorLabel()
    {
        return this.errorMan.getErrorLabel();
    }
    
    /* (non-Javadoc)
     * @see com.safelogic.pgp.api.KeyTransferHkpServer#getStackTrace()
     */
    public String getStackTrace()
    {
        return this.errorMan.getStackTrace();
    }

        
    /* (non-Javadoc)
     * @see com.safelogic.pgp.api.KeyTransferHkpServer#getRemoteSearchedKey(java.lang.String)
     */
    
    public List<StringTriplet> getRemoteSearchedKey(String searchText, boolean includePublicKeyBlock)
    {        
        if (searchText == null || searchText.equals(""))
        {
            throw new IllegalArgumentException("Search String can't be null");
        }
                
        // Prepare the HTTP output
        HttpTransfer httpTransfer = new HttpTransferOne();
                        
        try
        {            
            //http://pgp.mit.edu:11371/pks/lookup?search=npomereu&op=index&options=mr
                
            String urlSearch = serverUrl + "/pks/lookup?";
            
            NameValuePair[] data = 
                {
                    new NameValuePair("search", searchText),
                    new NameValuePair("op",     "index"),
                    new NameValuePair("options", "mr"),
                };
                                    
            for (int i = 0; i < data.length; i++)
            {
                if (i != 0)
                {
                    urlSearch += "&";
                }
                
                urlSearch += data[i].getName() + "=" + data[i].getValue();
            }
            
            debug("urlSearch: "  + urlSearch);
            
            // Send!
            errorMan.setOperationOk();
            httpTransfer.send(urlSearch, "GET", data); 

        }
        catch (ConnectException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_CONNECT_EXCEPTION, e1);
            return null; 
        }
        catch (SocketException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_SOCKET_EXCEPTION, e1);
            return null;             
        }
        catch (UnknownServiceException e1)
        {
            // Can happen on some key servers
            //errorMan.setErrorCode(Parms.ERR_HTTP_UNKNOWN_SERVICE_EXCEPTION, e1);
            //return null;     
            return new Vector<StringTriplet>();
        }
        catch (ProtocolException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_PROTOCOL_EXCEPTION, e1);
            return null;             
        }
        catch (IOException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_IO_EXCEPTION, e1);
            return null;             
        }        
                
        // Ok, get the keys list from the stream
        String recv = httpTransfer.recv();
                    
        debug("recv: " + recv);
        
        HkpServerResultExtractor hkpServerResultExtractornew = null;
        
        List<StringTriplet> foundKeys = new Vector<StringTriplet>();
        
        try
        {
            hkpServerResultExtractornew = new HkpServerResultExtractor(serverUrl, recv);
            foundKeys = hkpServerResultExtractornew.getPgpIdsAndUserIdsCommaSeparated();
        }
        catch (IOException e)
        {
            // Should never happen, because IO is on a String
            JOptionPaneCustom.showException(null, e);
        }
       
        // If we need to add the public key block: for each element in triplet add it!
        // It could be a cleaner way to do.        
        if (includePublicKeyBlock)
        {
            updateListWithPublicKeyBlock(foundKeys);
        }
        
        return foundKeys;
        
    }
    
    /**
     * Update each row of the the StringTriplet with the corresponding 
     * PGP Public key block
     * 
     * @param foundKeys     the triplet (PGP Id, User Id, Public key Block 
     */
    private void updateListWithPublicKeyBlock(List<StringTriplet> foundKeys)
    {        
        for (int i = 0; i < foundKeys.size(); i++)
        {
            if (i > LIMIT_FOR_FULL_KEYS_NUMBER)
            {
                break;
            }
            
            StringTriplet stringTriplet = foundKeys.get(i);
            String pgpId = stringTriplet.getElement1();
            String publicKeyBlock = this.getRemoteAscPgpPublicKeyAsAsc(pgpId); 
            stringTriplet.setElement3(publicKeyBlock);    
            foundKeys.set(i, stringTriplet);
        }
    }
    
    /**
     * Test if a remote Public Key or Private Key exists.
     * @param pgpId		    the PGP Id
     */
    public boolean existsRemotePubKey(String pgpId)
    {    	
    	PgpUserId pgpUserId = null;

        try
        {
            errorMan.setOperationOk();
            pgpUserId = new PgpUserId(pgpId);
        }
        catch (IllegalArgumentException e)
        {
            errorMan.setErrorCode(Parms.ERR_INVALID_USER_ID, e);
            return false;         
        }
        
        String email = pgpUserId.getKeyId();
        
        List<StringTriplet> keys = getRemoteSearchedKey(email, false);
        
        if (keys.isEmpty())
        {
            return false;
        }
        else
        {
            return true;
        }        
    }
    
    
	/* (non-Javadoc)
     * @see com.safelogic.pgp.api.KeyTransferHkpServer#getRemoteAscPgpPublicKey(java.lang.String)
     */
    public String getRemoteAscPgpPublicKeyAsAsc(String pgpId)    
	{
		
        if (pgpId == null || pgpId.equals(""))
        {
            throw new IllegalArgumentException("pgpId String can't be null");
        }
                
        if ( ! pgpId.startsWith("0x") || pgpId.length() != 10)
        {
            throw new IllegalArgumentException("pgpId String must be 10 hex chars long and must start with \"0x\"");
        }
        
        // Prepare the HTTP output
        HttpTransfer httpTransfer = new HttpTransferOne();
                        
        try
        {            
            //http://pgp.mit.edu:11371/pks/lookup?search=npomereu&op=index&options=mr
                
            String urlSearch = serverUrl + "/pks/lookup?";
            
            NameValuePair[] data = 
                {
                    new NameValuePair("search", pgpId),
                    new NameValuePair("op",     "get"),
                    new NameValuePair("options", "mr"),
                };
                                    
            for (int i = 0; i < data.length; i++)
            {
                if (i != 0)
                {
                    urlSearch += "&";
                }
                
                urlSearch += data[i].getName() + "=" + data[i].getValue();
            }
            
            debug("urlSearch: "  + urlSearch);
            
            // Send!
            errorMan.setOperationOk();
            httpTransfer.send(urlSearch, "GET", data); 

        }
        catch (ConnectException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_CONNECT_EXCEPTION, e1);
            return null; 
        }
        catch (SocketException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_SOCKET_EXCEPTION, e1);
            return null;             
        }
        catch (UnknownServiceException e1)
        {
            // Can happen on some key servers
            // errorMan.setErrorCode(Parms.ERR_HTTP_UNKNOWN_SERVICE_EXCEPTION, e1);
            // return null;     
            
            return null;
        }
        catch (ProtocolException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_PROTOCOL_EXCEPTION, e1);
            return null;             
        }
        catch (IOException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_IO_EXCEPTION, e1);
            return null;             
        }        
                
        // Ok, get the keys list from the stream
        String recv = httpTransfer.recv();
		
        if (recv == null)
        {
            return null;
        }
        
        if (! recv.contains(PgpTags.BEGIN_PGP_PUBLIC_KEY_BLOCK) || 
            ! recv.contains(PgpTags.END_PGP_PUBLIC_KEY_BLOCK))
        {
            return null;
        }
        
        recv = StringUtils.substringBetween(recv, 
                                            PgpTags.BEGIN_PGP_PUBLIC_KEY_BLOCK,
                                            PgpTags.END_PGP_PUBLIC_KEY_BLOCK);
        
        recv = PgpTags.BEGIN_PGP_PUBLIC_KEY_BLOCK
               + recv
               + PgpTags.END_PGP_PUBLIC_KEY_BLOCK;
        
        return recv;
		
	}
	
     
    /**
     * Upload the PGP public key in asc format to the server
     * 
     * @return  the PGP public key  corresponding to the PGP key id in armor format
     * 
     */            
    public void putRemoteAscPgpPublicKeyAsAsc(String publicKeyBlock)
    {
        
        if (publicKeyBlock == null || publicKeyBlock.equals(""))
        {
            throw new IllegalArgumentException("publicKeyBlock String can't be null");
        }
                
        // trim!
        publicKeyBlock = publicKeyBlock.trim();
        
        if ( ! publicKeyBlock.startsWith(PgpTags.BEGIN_PGP_PUBLIC_KEY_BLOCK)) 
        {
            throw new IllegalArgumentException("publicKeyBlock String must start with: " 
                    + PgpTags.BEGIN_PGP_PUBLIC_KEY_BLOCK);
        }
        
        if ( ! publicKeyBlock.contains(PgpTags.BEGIN_PGP_PUBLIC_KEY_BLOCK)) 
        {
            throw new IllegalArgumentException("publicKeyBlock String must contains at end: " 
                    + PgpTags.END_PGP_PUBLIC_KEY_BLOCK);
        }        
        
        // Prepare the HTTP output
        HttpTransfer httpTransfer = new HttpTransferOne();
                        
        try
        {                            
            String urlPost = serverUrl + "/pks/add";
            
            NameValuePair[] data = 
                {
                    new NameValuePair("keytext", publicKeyBlock),
                };
                
            //DEBUG= true;
            debug("urlPost: "  + urlPost);
            
            // Send!
            errorMan.setOperationOk();
            httpTransfer.send(urlPost, "POST", data); 

        }
        catch (ConnectException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_CONNECT_EXCEPTION, e1);
            return; 
        }
        catch (SocketException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_SOCKET_EXCEPTION, e1);
            return;             
        }
        catch (UnknownServiceException e1)
        {
            // Repsons in case the status is not OK ==> bad submissions
            errorMan.setErrorCode(Parms.ERR_HTTP_UNKNOWN_SERVICE_EXCEPTION, e1);            
            return;
        }
        catch (ProtocolException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_PROTOCOL_EXCEPTION, e1);
            return;             
        }
        catch (IOException e1)
        {
            errorMan.setErrorCode(Parms.ERR_HTTP_IO_EXCEPTION, e1);
            return;             
        }        
                        
    }

    /**
     * debug tool
     */
    private void debug(String s)
    {
        if (DEBUG)
        {
            System.out.println(s);
            //System.out.println(this.getClass().getName() + " " + new Date() + " " + s);
        }
    }        

    
    public static void main(String[] args)
    throws Exception
    {
        String server = null;
        
        boolean mit = true;
        
        if (mit)
        {
            server  = "http://pgp.mit.edu:11371";        
        }
        else
        {
            server = "http://keyserver.ubuntu.com:11371";      
        }
         
        System.out.println(new Date() + " HKP Server is: " + server);
        System.out.println();
        
        KeyTransferHkpServer keyTransferHkpServer = new KeyTransferHkpServerOne(server);
                
        String keyToExport = "testpom@testpom.com";
        
        KeyHandler keyHandler = new KeyHandlerOne();
        String keyAsc = keyHandler.exportAscPgpPublicKey(keyToExport);
        
        keyTransferHkpServer.putRemoteAscPgpPublicKeyAsAsc(keyAsc);
        
        if (! keyTransferHkpServer.isOperationOk())
        {
            System.out.println(keyTransferHkpServer.getErrorCode());
            System.out.println(keyTransferHkpServer.getErrorLabel());
            System.out.println(keyTransferHkpServer.getException().toString());
            return;
        }        
        
        if (true) return;
                
        boolean includePublicKeyBlock = true;
        
        List<StringTriplet> keys = keyTransferHkpServer.getRemoteSearchedKey("testpom", includePublicKeyBlock);
        
        if (! keyTransferHkpServer.isOperationOk())
        {
            System.out.println(keyTransferHkpServer.getErrorCode());
            System.out.println(keyTransferHkpServer.getErrorLabel());
            System.out.println(keyTransferHkpServer.getException().toString());
            return;
        }
        
        if (keys.isEmpty())
        {
            System.out.println("No keys found!");
        }
        
        System.out.println();
        
        for (int i = 0; i < keys.size(); i++)
        {
            System.out.println(keys.get(i));
        }         

        for (int i = 0; i < keys.size(); i++)
        {
            String key = keys.get(i).getElement1();
            
            System.out.println();
            String publicKeyBlock = "";
            
            if (includePublicKeyBlock)
                publicKeyBlock = keyTransferHkpServer.getRemoteAscPgpPublicKeyAsAsc(key);
                
            System.out.println(publicKeyBlock);
        } 
        
        System.out.println();
        System.out.println(new Date());

        
    }    
    
}
