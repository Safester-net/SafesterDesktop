/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.bcpg.attr.ImageAttribute;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPUserAttributeSubpacketVector;
import org.bouncycastle.openpgp.PGPUserAttributeSubpacketVectorGenerator;
import org.bouncycastle.openpgp.PGPUtil;

import com.safelogic.pgp.api.util.crypto.PgpUserId;
import com.safelogic.pgp.apispecs.KeyHandler;
import com.safelogic.pgp.apispecs.KeyImageHandler;
import com.safelogic.utilx.Debug;

/**
 * @author Nicolas de Pomereu
 *
 */
public class KeyImageHandlerOne implements KeyImageHandler 
{

    /** The debug flag */ 
    protected boolean DEBUG = Debug.isSet(this);

    /**
     * Constructor. Loads theBouncy Castle OpenPGP Provider
     */
    public KeyImageHandlerOne()
    {

    }

    /**
     * Add an Image (Photo) to a PGP Key
     * 
     * @param userId         The user Id of the PGP private key
     * @param passphrase     The passphrase of the PGP private key
     * @param image          The JPEG image as byte array
     * 
     * @throws IllegalArgumentException        if passphrase is invalid
     */
    public void addImageToPgpKey(String userId, char[] passphrase, byte[] image)
        throws NoSuchAlgorithmException, NoSuchProviderException,
               IllegalArgumentException, IOException, KeyException, 
               SignatureException, KeyStoreException 	
    {
        try
        {

            PGPPublicKeyRing pgpPublicKeyRing = getPGPPublicKeyRing(userId);
            PGPSecretKeyRing pgpSeccretKeyRing = getPGPSecretKeyRing(userId);

            Iterator    it0 = pgpPublicKeyRing.getPublicKeys();

            PGPPublicKey    pubKeyMaster = null;

            int i = 0;

            List<PGPPublicKey> pubKeyList = new Vector<PGPPublicKey>();

            while (it0.hasNext())
            {                
                PGPPublicKey pubKey = (PGPPublicKey)it0.next();

                debug("i= " + i);
                debug("pubKey.isMasterKey    (): " + pubKey.isMasterKey());
                debug("pubKey.isEncryptionKey(): " + pubKey.isEncryptionKey());

                if (pubKey.isMasterKey())
                {
                    pubKeyMaster = pubKey;
                }   

                pubKeyList.add(pubKey);

                i++;                
            }    	       	

            PGPUserAttributeSubpacketVectorGenerator vGen = new PGPUserAttributeSubpacketVectorGenerator(); 

            vGen.setImageAttribute(ImageAttribute.JPEG, image);

            PGPUserAttributeSubpacketVector uVec = vGen.generate();

            //PGPSignatureGenerator sGen = new PGPSignatureGenerator(PublicKeyAlgorithmTags.RSA_GENERAL, 
            //                                                       HashAlgorithmTags.SHA1, "BC");

            //05/03/08 12:20 NDP - PGPSignatureGenerator: no more public key algorihtm in static
            PGPSignatureGenerator sGen = new PGPSignatureGenerator(pgpSeccretKeyRing.getSecretKey().getPublicKey().getAlgorithm(),
                                                                   HashAlgorithmTags.SHA1, "BC");            
            
            try
            {
                sGen.initSign(PGPSignature.POSITIVE_CERTIFICATION, pgpSeccretKeyRing.getSecretKey().extractPrivateKey(passphrase, "BC"));
            }
            catch (PGPException e)
            {
                throw new IllegalArgumentException("Invalid passphrase for image signature.");
            }

            PGPSignature sig = sGen.generateCertification(uVec, pubKeyMaster);

            PGPPublicKey nKey = PGPPublicKey.addCertification(pubKeyMaster, uVec, sig);

            Iterator it = nKey.getUserAttributes();
            int count = 0;

            while (it.hasNext())
            {
                PGPUserAttributeSubpacketVector attributes = (PGPUserAttributeSubpacketVector)it.next();

                Iterator    sigs = nKey.getSignaturesForUserAttribute(attributes);
                int sigCount = 0;

                while (sigs.hasNext())
                {
                    PGPSignature s = (PGPSignature)sigs.next();

                    s.initVerify(nKey, "BC");

                    if (!s.verifyCertification(attributes, nKey))
                    {
                       //JOptionPane.showMessageDialog(null, "Image Add Failure: Added signature failed verification");
                        throw new IllegalArgumentException("cGeep - Image Add Failure: Added signature failed verification");
                    }

                    sigCount++;
                }

                if (sigCount != 1)
                {
                    //JOptionPane.showMessageDialog(null, "Image Add Failure: Failed added user attributes signature check");
                    throw new IllegalArgumentException("cGeep - Image Add Failure: Failed added user attributes signature check");
                }
                count++;
            }

            if (count != 1)
            {
                //JOptionPane.showMessageDialog(null, "Image Add Failure: Did not find added user attributes");
                throw new IllegalArgumentException("cGeep - Image Add Failure: Did not find added user attributes");
            }

            ByteArrayOutputStream bos = new  ByteArrayOutputStream();                
            OutputStream os = new ArmoredOutputStream(bos);

            for (int j = 0; j < pubKeyList.size(); j++)
            {
                PGPPublicKey pgpPublicKey = pubKeyList.get(j);

                if (pgpPublicKey.isMasterKey())
                {
                    nKey.encode(os);  // Encode with the replace master key
                }
                else
                {
                    pgpPublicKey.encode(os);
                }
            } 

            os.close();
            String armored = bos.toString();

            KeyHandler keyHandler = new KeyHandlerOne();
            keyHandler.deletePubKeyFromKeyRing(userId);
            keyHandler.importPgpPublicKeyFromAsc(armored);

        }
        catch (PGPException e)
        {
            throw new KeyException(e);
        }	    
    }

    /**
     * Remove an Image from a PgpPublicKey
     * 
     * @param userId         The user Id of the PGP private key
     */
    public void removeImageFromPgpKey(String userId)
        throws NoSuchAlgorithmException, NoSuchProviderException,
               IllegalArgumentException, IOException, KeyException, 
               SignatureException, KeyStoreException              
    {

        PGPPublicKeyRing pgpPublicKeyRing = getPGPPublicKeyRing(userId);
        PGPSecretKeyRing pgpSeccretKeyRing = getPGPSecretKeyRing(userId);

        Iterator    it0 = pgpPublicKeyRing.getPublicKeys();

        List<PGPPublicKey> pubKeyList = new Vector<PGPPublicKey>();

        while (it0.hasNext())
        {                
            PGPPublicKey pubKey = (PGPPublicKey)it0.next();

            //debug("i= " + i);
            //debug("pubKey.isMasterKey    (): " + pubKey.isMasterKey());
            //debug("pubKey.isEncryptionKey(): " + pubKey.isEncryptionKey());
                
            Iterator it =  pubKey.getUserAttributes();
            
            while (it.hasNext())
            {
                PGPUserAttributeSubpacketVector attributes = (PGPUserAttributeSubpacketVector)it.next();

                ImageAttribute imageAttribute = attributes.getImageAttribute();
                
                if (imageAttribute != null)
                {
                    pubKey = pubKey.removeCertification(pubKey, attributes);
                }
            }

            pubKeyList.add(pubKey);                
        }    

        ByteArrayOutputStream bos = new  ByteArrayOutputStream();                
        OutputStream os = new ArmoredOutputStream(bos);

        for (int j = 0; j < pubKeyList.size(); j++)
        {
            PGPPublicKey pgpPublicKey = pubKeyList.get(j);
            pgpPublicKey.encode(os);
        } 

        os.close();
        String armored = bos.toString();

        KeyHandler keyHandler = new KeyHandlerOne();
        keyHandler.deletePubKeyFromKeyRing(userId);
        keyHandler.importPgpPublicKeyFromAsc(armored);


    }    

    /**
     * Return the image as a byte array from any PGP Public key
     * 
     * @param userId         The user Id of the PGP public key
     * @return   the image as a byte array from any PGP Public key.
     *           null if the key has no image
     */
    public byte [] getImageFromPgpPublicKey(String userId)
        throws IOException, FileNotFoundException, 
               IllegalArgumentException, KeyException, NoSuchAlgorithmException 
    {
        KeyHandler keyHandler = new KeyHandlerOne();
        PgeepPublicKey key = (PgeepPublicKey)keyHandler.getPgpPublicKey(userId);

        if (key == null) // Should not happen, but cleaner.
        {
            return null;
        }

        PubkeyDescriptorOne descKey = new PubkeyDescriptorOne(key);

        byte [] image = descKey.getImage();

        return image;
    }

    /**
     * Return the image as a byte array from any PGP Public key contained in
     * an InputStream.
     * 
     * @param in             The InputStream of the Keyring Collection
     * @return   the image as a byte array from any PGP Public key.
     *           null if the key has no image
     */
    
    public byte [] getImageFromPgpPublicKey(InputStream in)
        throws IOException, FileNotFoundException, 
               IllegalArgumentException, KeyException, NoSuchAlgorithmException 
    {
        KeyHandler keyHandler = new KeyHandlerOne();
        PgeepPublicKey key = null;
                
        //
        // Don't know why : throws Exception in ButtonColumn.getImage() because of renderer
        //
        try
        {
            key = (PgeepPublicKey)keyHandler.getPgpPublicKeyFromAsc(in);
        }
        catch (RuntimeException e)
        {
            e.printStackTrace();
        }        
        
        if (key == null) // Should not happen, but cleaner.
        {
            return null;
        }

        PubkeyDescriptorOne descKey = new PubkeyDescriptorOne(key);

        byte [] image = descKey.getImage();

        return image;
    }
    

    /**
     * 
     * @param keyId        the userId to extract the PGPSecretKeyRing for
     * @return             the BC PGPSecretKeyRing
     * 
     * @throws FileNotFoundException
     * @throws IOException
     * @throws KeyException
     */
    public static PGPSecretKeyRing getPGPSecretKeyRing(String keyId) 
        throws FileNotFoundException, IOException, KeyException 
    {
        File secKeyring = new File(PgpUserId.getPrivKeyRingFilename());
        InputStream in = new FileInputStream(secKeyring);

        in = PGPUtil.getDecoderStream(in);
        try {
            PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(in);
            in.close();
            Iterator rIt = pgpSec.getKeyRings();
            while (rIt.hasNext())
            {
                PGPSecretKeyRing    kRing = (PGPSecretKeyRing)rIt.next();    
                Iterator            kIt = kRing.getSecretKeys();

                while (kIt.hasNext())
                {
                    PGPSecretKey    k = (PGPSecretKey)kIt.next();

                    Iterator    ituser = k.getUserIDs();
                    while (ituser.hasNext())
                    {                                               
                        String userIdInKeyRing = (String) ituser.next();
                        if(userIdInKeyRing.contains(keyId) || keyId.contains(userIdInKeyRing) )
                        {
                            return kRing;
                        }
                    }
                }
            }

            return null;

        }
        catch (PGPException e) {
            throw new KeyException(e);
        }
    }   


    /**
     * 
     * @param keyId        the userId to extract the PGPPublicKeyRing for
     * @return             the BC PGPPublicKeyRing
     * 
     * @throws IOException
     * @throws FileNotFoundException
     * @throws IllegalArgumentException
     * @throws KeyException
     * @throws NoSuchAlgorithmException
     */
    public  static PGPPublicKeyRing getPGPPublicKeyRing (String keyId) 
        throws IOException, FileNotFoundException, IllegalArgumentException, KeyException, 
               NoSuchAlgorithmException 
    {
        if(keyId == null)
        {
            throw new IllegalArgumentException("Key Id cannot be null");
        }

        PgpUserId pgpUserId = new PgpUserId(keyId); // Checks the userId format

        String pubKeyRingFile = pgpUserId.getPubKeyRingFilename();

        try
        {
            PGPUtil.setDefaultProvider("BC");

            InputStream in = new FileInputStream(pubKeyRingFile);
            in = PGPUtil.getDecoderStream(in);

            PGPPublicKeyRingCollection        pgpPub = new PGPPublicKeyRingCollection(in);

            //
            // iterate through the key rings.
            //
            Iterator rIt = pgpPub.getKeyRings();

            // BEWARE
            // This will contain AT FIRST ITERATION ONLY on PGPPublicKey.getUserIDs()
            // The userid name. Aka, the second iteration, there will be no value
            String userIdInKeyRing = null;

            // The armored key to export
            String armoredKey = null;

            PGPPublicKeyRing pgpPublicKeyRing = null;

            while (rIt.hasNext())
            {
                pgpPublicKeyRing = (PGPPublicKeyRing)rIt.next();    
                Iterator            kIt = pgpPublicKeyRing.getPublicKeys();

                ByteArrayOutputStream bos = new  ByteArrayOutputStream();                
                OutputStream os = new ArmoredOutputStream(bos);

                while (kIt.hasNext())
                {
                    PGPPublicKey    pgpPubKey = (PGPPublicKey)kIt.next();                      
                    Iterator    ituser = pgpPubKey.getUserIDs();

                    while (ituser.hasNext())
                    {                                               
                        userIdInKeyRing = (String) ituser.next();

                        //debug("User ID as param  : " + keyId);  
                        //debug("User ID in keyring: " + userIdInKeyRing);                                                              
                        //debug("");

                        if (userIdInKeyRing.contains(keyId))
                        {                            
                            return pgpPublicKeyRing;                            
                        }         

                    } //HACK: BRACKET MOOVED!!
                }
            }

            return pgpPublicKeyRing;
        }
        catch (PGPException e)
        {
            throw new KeyException(e);
        }

    }

    
    /**
     * 
     * @param keyId        the userId to extract the PGPSecretKeyRing for
     * @return             the BC PGPSecretKeyRing
     * 
     * @throws FileNotFoundException
     * @throws IOException
     * @throws KeyException
     */
    public static PGPSecretKeyRing getPGPSecretKeyRingFromAsc(String keyId, String privateKeyBloc) 
        throws FileNotFoundException, IOException, KeyException 
    {
        InputStream in = new ByteArrayInputStream(privateKeyBloc.getBytes());

        in = PGPUtil.getDecoderStream(in);
        try {
            PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(in);
            in.close();
            Iterator rIt = pgpSec.getKeyRings();
            while (rIt.hasNext())
            {
                PGPSecretKeyRing    kRing = (PGPSecretKeyRing)rIt.next();    
                Iterator            kIt = kRing.getSecretKeys();

                while (kIt.hasNext())
                {
                    PGPSecretKey    k = (PGPSecretKey)kIt.next();

                    Iterator    ituser = k.getUserIDs();
                    while (ituser.hasNext())
                    {                                               
                        String userIdInKeyRing = (String) ituser.next();
                        if(userIdInKeyRing.contains(keyId) || keyId.contains(userIdInKeyRing) )
                        {
                            return kRing;
                        }
                    }
                }
            }

            return null;

        }
        catch (PGPException e) {
            throw new KeyException(e);
        }
    }   
    
    /**
     * Displays the specified message if the DEBUG flag is set.
     * @param   sMsg    the debug message to display
     */

    protected void debug(String sMsg)
    {
        if(DEBUG)
            System.out.println("DBG> " + sMsg) ;
    }
    
}

//End
