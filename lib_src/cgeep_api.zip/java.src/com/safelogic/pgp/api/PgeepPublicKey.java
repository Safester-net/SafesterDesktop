/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api;

import java.security.NoSuchProviderException;
import java.security.PublicKey;

import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;

/**
 * PGP Public Key Holder
 * 
 * Necessary because some provider implementations do not define their PGP Public Key as
 * Java PublicKey
 * 
 * @author Nicolas de Pomereu
 *
 */
public class PgeepPublicKey implements PublicKey
{
    
    private PGPPublicKey    m_pgpKey = null;
    
    /**
     * Constructor
     */
    public PgeepPublicKey(PGPPublicKey pgpKey)
    {
        this.m_pgpKey = pgpKey;
    }

    /**
     * @return Returns the pgpKey.
     */
    public PGPPublicKey getKey()
    {
        return m_pgpKey;
    }

    /* (non-Javadoc)
     * @see java.security.Key#getAlgorithm()
     */
    public String getAlgorithm()
    {
        String algorihtm = null;
        
        try
        {
            algorihtm = (m_pgpKey.getKey("BC")).getAlgorithm();
        }
        catch (NoSuchProviderException e)
        {
            //e.printStackTrace();
        }
        catch (PGPException e)
        {
            //e.printStackTrace();
        }
        
        return algorihtm;
        
    }

    /* (non-Javadoc)
     * @see java.security.Key#getEncoded()
     */
    public byte[] getEncoded()
    {
        try
        {
            return (m_pgpKey.getKey("BC")).getEncoded();
        }
        catch (NoSuchProviderException e)
        {
            //e.printStackTrace();
            return null;
        }
        catch (PGPException e)
        {
            //e.printStackTrace();
            return null;
        }

    }

    /* (non-Javadoc)
     * @see java.security.Key#getFormat()
     */
    public String getFormat()
    {
        try
        {
            return (m_pgpKey.getKey("BC")).getFormat();
        }
        catch (NoSuchProviderException e)
        {
            //e.printStackTrace();
            return null;
        }
        catch (PGPException e)
        {
            //e.printStackTrace();
            return null;
        }
    }
    
    
}

