/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.KeyException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPDataValidationException;
import org.bouncycastle.openpgp.PGPEncryptedData;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPBEEncryptedData;
import org.bouncycastle.openpgp.PGPUtil;

import com.safelogic.pgp.api.engines.CryptoEngine;
import com.safelogic.pgp.api.util.crypto.CgeepTagArmoredOutputStream;
import com.safelogic.pgp.api.util.msg.MessagesManager;
import com.safelogic.pgp.apispecs.PgpSymActions;
import com.safelogic.pgp.util.Util;
import com.safelogic.utilx.Debug;

/**
 * 
 * @author Nicolas de Pomereu
 *
 * This implementation uses org.bouncycastle.openpgp.examples.ByteArrayHandler example 
 * class adapatation  from Bouncy Castle
 */

public class PgpSymActionsOne implements PgpSymActions
{
    /** The debug flag */
    protected boolean DEBUG = Debug.isSet(this);
    
    /** The files size - is used by the Progress indicator */
    private long filesLength = 0;
    
    /** The calling/owner thread */
    private CryptoEngine m_owner = null;
    
    /** Messages for I18N */
    private MessagesManager messages = new  MessagesManager();

    /** 
     * If true, all files with be encrypted and/or signed with armored format
     * true is the best solution for email sending/receptions 
     */
    private boolean armorMode = false;
    
    /**
     * Defaut constructor.
     */
    public PgpSymActionsOne()
    {      
        Security.addProvider(new BouncyCastleProvider());        
    }

    /**
     * Constructor to be called when a Progress Monitor 
     * @param owner
     */
    public PgpSymActionsOne(CryptoEngine owner)
    {
        Security.addProvider(new BouncyCastleProvider()); 
        this.m_owner = owner;
    }      
    
    /**
     * Signal that the file operation is terminated 
     * (to be used in cGeepApi)
     */
    public void setMaximumProgress()
    {
        m_owner.setCurrent(CryptoEngine.MAXIMUM_PROGRESS);
    }
    
    /**
     * @param armorMode if true, the encrypted file will be PGP armored
     */
    public void setArmorMode(boolean armorMode)
    {
        this.armorMode = armorMode;
    }
    
    /**
     * @param filesLength the total files Size
     */
    public void setFilesLength(long filesLength)
    {
        this.filesLength = filesLength;
    }
    
    /**
     * Set th owner current value for progression bar
     * @param current
     */
    private void setOwnerCurrent(int current)
    {
        if (m_owner != null)
        {
            m_owner.setCurrent(current);
        }
    }
    
    /**
     * Set the owner current value for progression bar
     * @param current
     */
    private void addOneOwnerCurrent()
    {
        if (m_owner != null)
        {
            int current = m_owner.getCurrent();
            current++;
            
            // Do no force interruption. 
            //
            // 16/12/09 19:55 NDP - Pgp(Sym)ActionsOnecurrent < CryptoEngine.MAXIMUM_PROGRESS instead of <= (thread would stop)
            if (current < CryptoEngine.MAXIMUM_PROGRESS)
            {                
                m_owner.setCurrent(current);
            }
            
            debug("current: " + current);
        }
    }
    
    /**
     * Set the owner current note for progression bar
     * @param current
     */
    private void setOwnerNote(String note)
    {
        if (m_owner != null)
        {
            m_owner.setNote(note);
        }
    }    
    
    /**
     * @return true is there is an owner AND it's interrupted
     */
    private boolean isOwnerInterrupted()
    {
        if (m_owner == null)
        {
            return false;
        }
        
        // 08/10/08 17:10 NDP - use non static method in isOwnerInterrupted() for APIs
        //return ((Thread)m_owner).interrupted();
        return ((Thread)m_owner).isInterrupted();
    }    
    
    /**
     * Encrypt a byte array using a PGP symetric encryption with a passphrase (PBE type)
     * 
     * @param clearData     The byte array to encrypt
     * @param passphrase    The passphrase for symetric 
     * @return              The encrypted byte array
     * 
     * @throws IllegalArgumentException If a requiered argument is null
     * @throws KeyException             If an error occurs during encryption
     * @throws Exception                If any other error occurs
     */
    public byte[] encryptSymmetricPgp (byte[] clearData, char [] passPhrase)
    throws IllegalArgumentException, KeyException, Exception
    {         
        
        int algorithm =  0;
        
        // Use CAST5 if armored. better to always use it
        algorithm = PGPEncryptedDataGenerator.CAST5;
        
        String fileName= PGPLiteralData.CONSOLE;
                        
        ByteArrayOutputStream    encOut = new ByteArrayOutputStream();
        
        OutputStream out = encOut;
                              
        // DO NOT ARMOR! NEVER! 
        // Will not be decrypt correctly
        
//        if (armorMode)
//        {
//            out = new CgeepTagArmoredOutputStream(out);
//        }

        ByteArrayOutputStream   bOut = new ByteArrayOutputStream();


        PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(
                                                        PGPCompressedDataGenerator.ZIP);
        OutputStream cos = comData.open(bOut); // open it with the final destination
        PGPLiteralDataGenerator lData = new PGPLiteralDataGenerator();

        // we want to generate compressed data. This might be a user option later,
        // in which case we would pass in bOut.
        OutputStream  pOut = lData.open(cos, // the compressed output stream
                                        PGPLiteralData.BINARY,
                                        fileName,  // "filename" to store
                                        clearData.length, // length of clear data
                                        new Date()  // current time
                                      );
        pOut.write(clearData);

        lData.close();
        comData.close();

        PGPEncryptedDataGenerator   cPk = new PGPEncryptedDataGenerator(algorithm, new SecureRandom(), "BC");

        cPk.addMethod(passPhrase);

        byte[]              bytes = bOut.toByteArray();

        OutputStream    cOut = cPk.open(out, bytes.length);

        cOut.write(bytes);  // obtain the actual bytes from the compressed stream

        cOut.close();
        
        return  encOut.toByteArray();

    }


    /**
     * Decrypt a byte array using a PGP symetric encryption with a passphrase (PBE type)
     * 
     * @param encrypted                 The encrypted byte array
     * @param passphrase                The passphrase for symetric 
     * @return                          The decrypted byte array
     * 
     * @throws PGPDataValidationException   If passphrase is invalid
     * @throws KeyException                 If the passed byte array is not PGP encrypted
     * 
     * @throws Exception                    If any other error occurs
     */
    public byte[] decryptSymmetricPgp(byte[] encrypted, char [] passPhrase)
        throws PGPDataValidationException, PGPException, Exception
    {
        InputStream in = new ByteArrayInputStream(encrypted);

        in = PGPUtil.getDecoderStream(in);

        PGPObjectFactory         pgpF = new PGPObjectFactory(in);
        PGPEncryptedDataList   enc = null;
        Object                          o = pgpF.nextObject();
        
        //
        // the first object might be a PGP marker packet.
        //
        if (o instanceof PGPEncryptedDataList)
        {
            enc = (PGPEncryptedDataList)o;
        }
        else
        {
            enc = (PGPEncryptedDataList)pgpF.nextObject();
        }

        //PGPPBEEncryptedData pbe = (PGPPBEEncryptedData)enc.get(0);
        
        PGPPBEEncryptedData pbe = null;

        try
        {
            pbe = (PGPPBEEncryptedData)enc.get(0);
        }
        catch (Exception e)
        {
            // This happens if the string was not PGP encrypted
            throw new PGPException("String is not PGP encrypted!");
        }        

        //InputStream clear = pbe.getDataStream(passPhrase, "BC");

        InputStream clear = null;

        try
        {
            clear = pbe.getDataStream(passPhrase, "BC");
        }
        catch (Exception e)
        {
            // This happens if the passphrase is invalid
            throw new PGPDataValidationException ("Invalid passphrase for String symmetric decryption!");            
        }        
        
        PGPObjectFactory        pgpFact = new PGPObjectFactory(clear);

        PGPCompressedData   cData = (PGPCompressedData)pgpFact.nextObject();

        pgpFact = new PGPObjectFactory(cData.getDataStream());

        PGPLiteralData  ld = (PGPLiteralData)pgpFact.nextObject();

        InputStream unc = ld.getInputStream();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int ch;

        while ((ch = unc.read()) >= 0)
        {
            out.write(ch);
        }
        
        byte[] returnBytes = out.toByteArray();
        out.close();
        return returnBytes;
        
        
    }

    
    /*
     * (non-Javadoc)
     * @see com.safelogic.pgp.apispecs.PgpSymActions#encryptFileSymmetricPgp(java.io.File, java.io.File, char[])
     */
    public void encryptFileSymmetricPgp(File fileIn, File fileOut, char[] passphrase)
        throws IllegalArgumentException, KeyException, Exception {

        boolean withIntegrityCheck = true;
        
        if(fileIn == null)
        {
            throw new IllegalArgumentException("In File parameter cannot be null.");
        }
        
        if(fileOut == null)
        {
            throw new IllegalArgumentException("Out File parameter cannot be null.");
        }
        
        if(passphrase == null)
        {
            throw new IllegalArgumentException("Passphrase cannot be null.");
        }

        OutputStream out = new BufferedOutputStream( new FileOutputStream(fileOut));
        
        if (armorMode)
        {
            out = new CgeepTagArmoredOutputStream(out);
        }
        
        String strFileIn =  fileIn.toString();
                
        try
        {           
            PGPEncryptedDataGenerator   cPk = new PGPEncryptedDataGenerator(PGPEncryptedData.CAST5, 
                                                   withIntegrityCheck, 
                                                   new SecureRandom(), 
                                                   "BC");
            
            cPk.addMethod(passphrase);
            
            OutputStream                cOut = cPk.open(out, new byte[1 << 16]);
            
            PGPCompressedDataGenerator  comData = new PGPCompressedDataGenerator(
                                                                    PGPCompressedData.ZIP);
                                                                    
            writeFileToLiteralData(comData.open(cOut), 
                    PGPLiteralData.BINARY, 
                    fileIn, 
                    new byte[1 << 16]);
            
            comData.close();
            
            cOut.close();

            out.close();                  
           
        }
        catch (RuntimeException e)
        {
            throw e;
        }
        finally
        {
            IOUtils.closeQuietly(out);
        }
                
    }

    /**
     * write out the passed in file as a literal data packet in partial packet format.
     * 
     * @param out
     * @param fileType the LiteralData type for the file.
     * @param file
     * @param buffer buffer to be used to chunk the file into partial packets.
     * 
     * @throws IOException
     */
    private void writeFileToLiteralData(
        OutputStream    out,
        char            fileType,
        File            file,
        byte[]          buffer)
        throws IOException, InterruptedException
    {
        PGPLiteralDataGenerator lData = new PGPLiteralDataGenerator();
        
        OutputStream            pOut = lData.open(out, fileType, file.getName(), new Date(file.lastModified()), buffer);
        
        //FileInputStream         in = new FileInputStream(file);
        BufferedInputStream     in = new BufferedInputStream(new FileInputStream(file));
        
        byte[]                  buf = new byte[buffer.length];
        int                     len;
        
        if (filesLength == 0)
        {
            setFilesLength(file.length());
        }

        setOwnerNote(messages.getMessage("progress_crypt_file") + " " + file.getName()); // + " ==> " + fileIn.getName() + ".pgeep");
        addOneOwnerCurrent();
        
        int tempLen = 0;
        
        while ((len = in.read(buf)) > 0)
        {
            tempLen  += len;
            
            if (tempLen > filesLength / CryptoEngine.MAXIMUM_PROGRESS)
            {                  
                tempLen = 0;
                Thread.sleep(10); // TODO: adjust sleep time depending on fileIn length                                        
                addOneOwnerCurrent(); // For ProgressMonitor progress bar 
            }
            
            if (isOwnerInterrupted())
            {
                lData.close();

                IOUtils.closeQuietly(in);
                IOUtils.closeQuietly(pOut);
                throw new InterruptedException();
            }
            
            pOut.write(buf, 0, len);
        }
        
        lData.close();
        IOUtils.closeQuietly(in);
        IOUtils.closeQuietly(pOut);
        
    }    
    

    /*
     * (non-Javadoc)
     * @see com.safelogic.pgp.apispecs.PgpSymActions#decryptFileSymmetricPgp(java.io.File, java.io.File, char[])
     */
    public void decryptFileSymmetricPgp(File fileIn, File fileOut, char[] passphrase)
        throws PGPDataValidationException, PGPException, Exception
    {

        if(fileIn == null)
        {
            throw new IllegalArgumentException("In File parameter cannot be null.");
        }
        
        if(fileOut == null)
        {
            throw new IllegalArgumentException("Out File parameter cannot be null.");
        }
        
        if(passphrase == null)
        {
            throw new IllegalArgumentException("Passphrase cannot be null.");
        }
        
        InputStream in      = new BufferedInputStream(new FileInputStream(fileIn));
        OutputStream out    = new BufferedOutputStream(new FileOutputStream(fileOut));
        
        try
        {            
            in = PGPUtil.getDecoderStream(in);
            
            PGPObjectFactory        pgpF = new PGPObjectFactory(in);
            PGPEncryptedDataList    enc;
            Object                  o = pgpF.nextObject();
            
            //
            // the first object might be a PGP marker packet.
            //
            if (o instanceof PGPEncryptedDataList)
            {
                enc = (PGPEncryptedDataList)o;
            }
            else
            {
                enc = (PGPEncryptedDataList)pgpF.nextObject();
            }

            PGPPBEEncryptedData     pbe = null;

            try
            {
                pbe = (PGPPBEEncryptedData)enc.get(0);
            }
            catch (Exception e)
            {
                // This happens if the string was not PGP encrypted
                throw new PGPException("File is not PGP encrypted!");
            }
                    
            InputStream clear = null;
            
            try
            {
                clear = pbe.getDataStream(passphrase, "BC");
            }
            catch (Exception e)
            {
                // This happens if the passphrase is invalid
                throw new PGPDataValidationException ("Invalid passphrase for File symmetric decryption!");            
            }

            
            PGPObjectFactory        pgpFact = new PGPObjectFactory(clear);
                        
            /*
            PGPCompressedData       cData = (PGPCompressedData)pgpFact.nextObject();
        
            pgpFact = new PGPObjectFactory(cData.getDataStream());
            
            PGPLiteralData          ld = (PGPLiteralData)pgpFact.nextObject();
            */                        
            
            // 13/05/08 21:30 NDP - FIX: decryptFileSymmetricPgp()
            //                           would not test if file was compressed
           
           Object message = pgpFact.nextObject();
            
           if (message instanceof PGPCompressedData)
           {
               PGPCompressedData   cData = (PGPCompressedData)message;
               InputStream         compressedStream = new BufferedInputStream(cData.getDataStream());
               pgpFact = new PGPObjectFactory(compressedStream);            
               
               try
               {
                   message = pgpFact.nextObject();
               }
               catch (IOException e)
               {
                   throw new UnsupportedEncodingException(e.getMessage());
               }            
           }                          

            PGPLiteralData          ld = (PGPLiteralData)message;
                                   
            //FileOutputStream        fOut = new FileOutputStream(ld.getFileName());
            
            
            InputStream    unc = ld.getInputStream();
            int    ch;
            
            byte[]                  buf = new byte[4086];
            int                     len;
            
            if (filesLength == 0)
            {
                setFilesLength(fileIn.length());
            }
            
            setOwnerNote(messages.getMessage("progress_decrypt_file") + " " + fileIn.getName()); // + " ==> " + fileIn.getName() + ".pgeep");
            addOneOwnerCurrent();
            
            // For ProgressMonitor 
            long tempLen = 0;
            
            //while ((ch = unc.read()) >= 0)
            //{          
                
            while ((len = unc.read(buf)) > 0)
            {
                tempLen  += len;                
                
                if (tempLen > filesLength / CryptoEngine.MAXIMUM_PROGRESS)
                {                  
                    tempLen = 0;
                    Thread.sleep(10); // TODO: adjust sleep time depending on fileIn length                    
                    addOneOwnerCurrent();  // For ProgressMonitor progress bar 
                }
                
                if (isOwnerInterrupted())
                {
                    out.flush();
                    IOUtils.closeQuietly(in);
                    IOUtils.closeQuietly(out);
                    throw new InterruptedException();
                }                
                
                //out.write(ch);
                out.write(buf, 0, len);
                
            }
            
//            if (pbe.isIntegrityProtected())
//            {
//                if (!pbe.verify())
//                {
//                    System.err.println("message failed integrity check");
//                }
//                else
//                {
//                    System.err.println("message integrity check passed");
//                }
//            }
//            else
//            {
//                System.err.println("no message integrity check");
//            }            
        }
        catch (Exception e)
        {
           throw e;
        }      
        finally
        {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
        }

    }

    
    
    /*
     * (non-Javadoc)
     * @see com.safelogic.pgp.apispecs.PgpSymActions#decryptFileSymmetricPgp(java.io.File, java.io.File, char[])
     */
    public InputStream  decryptFileSymmetricPgp(File fileIn, char[] passphrase)
        throws PGPDataValidationException, PGPException, Exception
    {

        if(fileIn == null)
        {
            throw new IllegalArgumentException("In File parameter cannot be null.");
        }
        
        
        if(passphrase == null)
        {
            throw new IllegalArgumentException("Passphrase cannot be null.");
        }
        
        InputStream in      = new BufferedInputStream(new FileInputStream(fileIn));
        
        try
        {            
            in = PGPUtil.getDecoderStream(in);
            
            PGPObjectFactory        pgpF = new PGPObjectFactory(in);
            PGPEncryptedDataList    enc;
            Object                  o = pgpF.nextObject();
            
            //
            // the first object might be a PGP marker packet.
            //
            if (o instanceof PGPEncryptedDataList)
            {
                enc = (PGPEncryptedDataList)o;
            }
            else
            {
                enc = (PGPEncryptedDataList)pgpF.nextObject();
            }

            PGPPBEEncryptedData     pbe = null;

            try
            {
                pbe = (PGPPBEEncryptedData)enc.get(0);
            }
            catch (Exception e)
            {
                // This happens if the string was not PGP encrypted
                throw new PGPException("File is not PGP encrypted!");
            }
                    
            InputStream clear = null;
            
            try
            {
                clear = pbe.getDataStream(passphrase, "BC");
            }
            catch (Exception e)
            {
                // This happens if the passphrase is invalid
                throw new PGPDataValidationException ("Invalid passphrase for File symmetric decryption!");            
            }

            
            PGPObjectFactory        pgpFact = new PGPObjectFactory(clear);
                        
            /*
            PGPCompressedData       cData = (PGPCompressedData)pgpFact.nextObject();
        
            pgpFact = new PGPObjectFactory(cData.getDataStream());
            
            PGPLiteralData          ld = (PGPLiteralData)pgpFact.nextObject();
            */                        
            
            // 13/05/08 21:30 NDP - FIX: decryptFileSymmetricPgp()
            //                           would not test if file was compressed
           
           Object message = pgpFact.nextObject();
            
           if (message instanceof PGPCompressedData)
           {
               PGPCompressedData   cData = (PGPCompressedData)message;
               InputStream         compressedStream = new BufferedInputStream(cData.getDataStream());
               pgpFact = new PGPObjectFactory(compressedStream);            
               
               try
               {
                   message = pgpFact.nextObject();
               }
               catch (IOException e)
               {
                   throw new UnsupportedEncodingException(e.getMessage());
               }            
           }                          

            PGPLiteralData          ld = (PGPLiteralData)message;                                   
            //FileOutputStream        fOut = new FileOutputStream(ld.getFileName());            
            
            InputStream    unc = ld.getInputStream();
            return unc;
          
        }
        catch (Exception e)
        {
           throw e;
        }      

    }    
    
    
 
    /**
     * debug tool
     */
    private void debug(String s)
    {
        if (DEBUG)
        {
            System.out.println(s);
            //System.out.println(this.getClass().getName() + " " + new Date() + " " + s);
        }
    }  

    public static void main(
            String[] args)
    throws Exception
    {

        String passPhrase = "passphrase";
        char[] passArray = passPhrase.toCharArray();

        // 
        // String encryption
        // 
        byte[] original = "Hello world".getBytes();
        System.out.println("Starting PGP test");

        PgpSymActions pgpSymActions = new PgpSymActionsOne();

        byte[] encrypted = pgpSymActions.encryptSymmetricPgp(original, passArray);

        System.out.println(Util.CR_LF + "encrypted data = '" + new String(encrypted)+"'");

        byte[] decrypted= pgpSymActions.decryptSymmetricPgp(encrypted, passArray);

        System.out.println(Util.CR_LF + "decrypted data = '"+new String(decrypted)+"'");
        
        // 
        // File encryption
        // 
        File fClear = null;
        File fEncrypted  = null;
        
        //File fClear = new File("c:\\temp\\avgarkt-setup-1.1.0.42.exe");
        //File fEncrypted = new File("c:\\temp\\avgarkt-setup-1.1.0.42.exe.pgp");
        
        fClear = new File("c:\\temp\\cGeepPro_License.txt");
        fEncrypted = new File("c:\\temp\\cGeepPro_License.txt.pgp");    
        
        pgpSymActions.encryptFileSymmetricPgp(fClear, fEncrypted, passArray);
        //new PgeepPassphraseSymmetric(null, fEncrypted);
        
    }

}

