/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.UnknownServiceException;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.ProtocolException;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.io.IOUtils;

import com.safelogic.pgp.api.engines.DownloaderEngine;
import com.safelogic.pgp.api.util.msg.MessagesManager;
import com.safelogic.pgp.apispecs.HttpTransfer;
import com.safelogic.pgp.util.HttpProxyDetector;
import com.safelogic.pgp.util.UrlUtil;
import com.safelogic.pgp.util.UserPreferencesManager;
import com.safelogic.pgp.util.Util;
import com.safelogic.pgp.util.WindowsHttpProxyDetector;

/**
 * HttpTransferOne - 
 * Please note that in implementation, result is read in the send method
 * to be sure to release ASAP the server.
 * <br>
 * @see com.safelogic.pgp.apispecs.HttpTransfer for usage.
 */

public class HttpTransferOne implements HttpTransfer
{
    /** The maximum size of a string read from input stream */
    private static final int MAX_LENGTH_FOR_STRING = 3000000;

    /** Number of milliseconds a Http Client will try to connect before error message */
    private static final int TIMEOUT_HTTP_CONNECTION_MILLIS  = 15 * 1000;    // 15 seconds
    
    /** Number of milliseconds a socket will try an operation before error message */
    private static final int TIMEOUT_SOCKET_MILLIS           = 120 * 1000; // 120 seconds
    
    private final static String HTTP_WWW_GOOGLE_COM  = "http://www.google.com";    
    private final static String HTTP_WWW_PGEEP_COM   = "http://www.cgeep.com";
    private final static String HTTPS_WWW_PGEEP_COM  = "https://www.cgeep.com";
    
    /** The debug flag */ 
    protected boolean DEBUG = true; //Debug.isSet(this);
        
    /** Indicator if a send command has failed */
    public static final String SEND_FAILED = "SEND_FAILED";

    /** Indicator if a send command has suceeded */
    public static final String SEND_OK = "SEND_OK";

    /** GetMethod instance **/
    private GetMethod m_method  = null;
    
    /** Response from http server container */
    private String m_responseBody  = null;
    
    /** is true if the last sebd/recv wa ok **/
    private boolean m_isSendOk = false;
      
    /** The calling/owner thread */
    private DownloaderEngine m_owner = null;
    
    /** Messages for I18N */
    private MessagesManager messages = new  MessagesManager(); 
    
    /**
     * Constructor.
     */
    public HttpTransferOne()
    {    
                
    }
        
    /**
     * Constructor.
     */
    public HttpTransferOne(DownloaderEngine owner)
    {    
        this.m_owner = owner;
    }
    
    
    /**
     * Set the Http Client Timeout for initial connection & sockets
     * 
     * @param httpClient        the Http Client instance
     */
    public void setHttpClientTimeout(HttpClient httpClient)
    {
	
//	HttpConnectionManager ccm = httpClient.getHttpConnectionManager();
//	SSLSocketFactory sslsf = new SSLSocketFactory(
//		new TrustSelfSignedStrategy());
//	Scheme https = new Scheme("https", 444, sslsf);
//	ccm.getSchemeRegistry().register(https);
		
        httpClient.getParams().setParameter("http.socket.timeout",      new Integer(HttpTransferOne.TIMEOUT_SOCKET_MILLIS));
        httpClient.getParams().setParameter("http.connection.timeout",  new Integer(HttpTransferOne.TIMEOUT_HTTP_CONNECTION_MILLIS));
    }       
    
    
    /**
     * Test if there is a System Proxy defined in Windows IE & Configuration Panel
     * @return       0: if there is no System Proxy in use
     *               1: there is a System Proxy in use defined in IE
     *              -1: It's impossible to know because there is no Internet Connection!    
     */
    
    public int diagnoseProxySetting()
    {
        boolean googleAccessOk = false;
        boolean pgeepHttpSecureAccessOk = false;
          
        //
        // 1) Test with no Proxy
        //
        
        UserPreferencesManager.setUseProxy(false);
        
        googleAccessOk = this.isHttpReachable(HttpTransferOne.HTTP_WWW_GOOGLE_COM);        
        pgeepHttpSecureAccessOk = this.isHttpReachable(HttpTransferOne.HTTP_WWW_PGEEP_COM);
        
        // If either Google or Pgeep are acccessible, there is (probably) no Proxy in use
        if (googleAccessOk || pgeepHttpSecureAccessOk)
        {
            return 0;
        }
                
        //
        // 2) Test with the Proxy values stored in IE
        //
        
        googleAccessOk = false;
        pgeepHttpSecureAccessOk = false;
        
        UserPreferencesManager.setUseProxy(true);
                
        HttpProxyDetector proxyDetector = new WindowsHttpProxyDetector();
        
        if (proxyDetector.getProxyAddress() != null)
        {
            String proxyHost = proxyDetector.getProxyAddress();
            int proxyPort = proxyDetector.getProxyPort();
            
            System.setProperty("http.proxyHost", proxyHost);
            System.setProperty("http.proxyPort", Integer.toString(proxyPort)); 
            
            UserPreferencesManager.setProxyAddress(proxyHost);
            UserPreferencesManager.setProxyPort("" + proxyPort);
            
            googleAccessOk = this.isHttpReachable(HttpTransferOne.HTTP_WWW_GOOGLE_COM);             
        }
         
        if (proxyDetector.getSecureProxyAddress() != null)
        {
            String secureProxyHost = proxyDetector.getSecureProxyAddress();
            int secureProxyPort = proxyDetector.getSecureProxyPort();
            
            System.setProperty("https.proxyHost", secureProxyHost);
            System.setProperty("https.proxyPort", Integer.toString(secureProxyPort)); 
            
            UserPreferencesManager.setProxyAddress(secureProxyHost);
            UserPreferencesManager.setProxyPort("" + secureProxyPort);
            
            pgeepHttpSecureAccessOk = this.isHttpReachable(HttpTransferOne.HTTPS_WWW_PGEEP_COM);
        }
                            
        // If either Google or Pgeep are acccessible, there is (probably) a Proxy in use
        if (googleAccessOk || pgeepHttpSecureAccessOk)
        {
            return 1;
        }
        
        // We don't know.
        UserPreferencesManager.setUseProxy(false);  // Clean proxy settings
        UserPreferencesManager.setProxyAddress(null);
        UserPreferencesManager.setProxyPort(null);
        
        return -1;
    }
    
    
    /**
     * Send a String to any web server server using a post method
     * @param s     string to send
     * 
     * @throws SocketException           if there is no HTTP access 
     * @throws ConnectException          if the www.cgeep.com is not reachable (Tomcat down, etc.)
     * @throws UnknownServiceException   if the wwwcgeep.com/do/Recv servlet is not found
     * @throws ProtocolException         if the Recv does not send a clear feedback (program error)
     * @throws IOException               For all other IO / Network / System Error
     */
    public void send (String s)
        throws SocketException, 
        ConnectException, 
        UnknownServiceException,
        ProtocolException,
        IOException    
    {
        NameValuePair[] data = 
            {
                new NameValuePair("string", s)
            };

        String url = UrlUtil.getCgeepUrl() + "/do/Recv";
                
        send(url, "POST",  data);

        // Analyse applicative response header
        // "SEND_OK"
        // "SEND_FAILED"
        
        System.out.println();
        System.out.println("m_responseBody:");
        System.out.println(m_responseBody);

        if (m_responseBody.startsWith(SEND_OK))
        {
            // OK!
            // Extract the response ant put inin memory
            m_isSendOk = true;
            m_responseBody = m_responseBody.substring(SEND_OK.length() + 1);
        }
        else if (m_responseBody.startsWith(SEND_FAILED))
        {   
            m_isSendOk = false;
            m_responseBody = m_responseBody.substring(SEND_FAILED.length() + 1);            
        }
        else 
        {   
            m_isSendOk = false;
            throw new ProtocolException("Response message does not start with SEND_OK or SEND_FAILED!");
        }
            
    }
    
    
    
    /**
     * Send a String to the cGeep HTTP server using the http://www.cgeep.com/do/recv Servlet
     * 
     * @param url       the url of the site. Example http://www.cgeep.com/do/recv 
     * @param method    GET or POST only
     * @param data      the (name, value) pairs for POST methods only
     * 
     * @throws SocketException           if there is no HTTP access 
     * @throws ConnectException          if the www.cgeep.com is not reachable (Tomcat down, etc.)
     * @throws UnknownServiceException   if the wwwcgeep.com/do/Recv servlet is not found
     * @throws ProtocolException         if the Recv does not send a clear feedback (program error)
     * @throws IOException               For all other IO / Network / System Error
     */
    public void send(String url, String method, NameValuePair[] data) 
        throws SocketException, 
               ConnectException, 
               UnknownServiceException,
               ProtocolException,
               IOException
    {   
        if (url == null)
        {
            throw new IllegalArgumentException("url can not be null!");
        }
        
        if (method == null)
        {
            throw new IllegalArgumentException("method can not be null!");
        }
         
        if (! method.equalsIgnoreCase("get") && ! method.equalsIgnoreCase("post"))
        {
            throw new IllegalArgumentException
                        ("Invalid method. Must be GET or POST:  " + method);            
        }
        
        HttpMethod post = null;
        
        try
        {
            
            // Create an instance of HttpClient.
            HttpClient httpClient = new HttpClient();
            
            // Set the Proxy Values
            setProxy(httpClient);            
            
            //NOT NECESSARY WITH POST METHOD!
            //s = URLEncoder.encode(s, "UTF-8");
            
            //String urlControlerServlet = UrlUtil.getCgeepUrl() + "/do/Recv";
            
            //debug(url);
            //debug("");
            
            if (method.equalsIgnoreCase("post"))
            {                     
                // execute method and handle any error responses.
                post = new PostMethod(url);
                ((PostMethod) post).setRequestBody(data);                
            }
            else
            {
                post = new GetMethod(url);
            }

            // Analyse technical response
            // Execute the method.
            int statusCode = 0;
                        
            // Execute the request and analyse the error

            try
            {
                //debug("Before client.executeMethod(post)");
                
                statusCode = httpClient.executeMethod(post);

                //debug("After  client.executeMethod(post)");
            }
            catch (UnknownHostException uhe)
            {                               
                // Bad host passed.
                // This can hardly happen
                System.out.println("UnknownHostException uhe: " + uhe);
                uhe.printStackTrace();
                throw new ConnectException(uhe.getMessage());                
            }
            catch (ConnectException ce)
            {
                System.out.println("ConnectException ce: " + ce);
                
                // User is connected to Internet, the DNS exists, but not accessible :
                // Two causes 1) Web (Tomcat) Server down.  Probable cause.
                //            2) Routing table failure...   Less probable cause.
                throw ce;
            }                      
            catch (IOException ie)
            {
                ie.printStackTrace();
                System.out.println("IOException ie: " + ie);
                throw ie;
            }            
            if (statusCode != HttpStatus.SC_OK) 
            {
                // The server is up, but the servlet is not accessible
                throw new UnknownServiceException("Servlet Method failed: " 
                                + post.getStatusLine() + " status: " + statusCode);
            }        
            
            // Read the response body.
            InputStream in = post.getResponseBodyAsStream();
            
            LineNumberReader lineNumbeRreader 
                    = new LineNumberReader(new InputStreamReader(in)); 
                        
            StringBuilder sb = new StringBuilder();
            String line = null;
            
            long size = 0;
            while ((line = lineNumbeRreader.readLine()) != null) 
            {
                size += line.length();
                sb.append(line + Util.CR_LF);
                
                
                if (size > MAX_LENGTH_FOR_STRING)
                {
                    
                 // 13/10/08 13:30 NDP - No more Swing message display if send request is interrupted by response size
                 //                  (Isolation for Apis)
                    
//                    JOptionPane.showMessageDialog(null, 
//                            "HTTP Request was interrupted because maximum size in bytes has been reached: " 
//                                + MAX_LENGTH_FOR_STRING);
                    break;
                }
            }
            
            m_responseBody = sb.toString();            

        }
        finally
        {
            if (post != null)
            {
                post.releaseConnection();
            }
        }
                           
    }

    /**
     * Download & create a File from an URL.
     * 
     * @param file      the file to create from the download.
     * @param url       the url of the site. Example http://www.cgeep.com/donwload/cGeep_Setup.exe
     * 
     * @throws SocketException           if there is no HTTP access 
     * @throws ConnectException          if the www.cgeep.com is not reachable (Tomcat down, etc.)
     * @throws UnknownServiceException   if the wwwcgeep.com/do/Recv servlet is not found
     * @throws ProtocolException         if the Recv does not send a clear feedback (program error)
     * @throws IOException               For all other IO / Network / System Error
     * @throws InterruptedException      if user interrupts thread
     */
    public void downloadFileFromUrl(File file, long fileLength, String url) 
        throws SocketException, 
               ConnectException, 
               UnknownServiceException,
               ProtocolException,
               IOException,
               InterruptedException
    {   
        if (file == null)
        {
            throw new IllegalArgumentException("file can not be null!");
        }
        
        if (url == null)
        {
            throw new IllegalArgumentException("url can not be null!");
        }
                
        HttpMethod getMethod = null;
        InputStream in = null;
        FileOutputStream out = null;
        
        try
        {            
            // Create an instance of HttpClient.
            HttpClient httpClient = new HttpClient();
            
            // Set the Proxy Values
            setProxy(httpClient);            
            
            //debug(url);
            getMethod = new GetMethod(url);

            // Analyse technical response
            // Execute the method.
            int statusCode = 0;
                        
            // Execute the request and analyse the error
            try
            {
                //debug("Before client.executeMethod(post)");                
                statusCode = httpClient.executeMethod(getMethod);
                //debug("After  client.executeMethod(post)");
            }
            catch (UnknownHostException uhe)
            {                               
                // Bad host passed.
                // This can hardly happen
                System.out.println("UnknownHostException uhe: " + uhe);
                throw new ConnectException(uhe.getMessage());                
            }
            catch (ConnectException ce)
            {
                System.out.println("ConnectException ce: " + ce);
                
                // User is connected to Internet, the DNS exists, but not accessible :
                // Two causes 1) Web (Tomcat) Server down.  Probable cause.
                //            2) Routing table failure...   Less probable cause.
                throw ce;
            }                      
            catch (IOException ie)
            {
                ie.printStackTrace();
                System.out.println("IOException ie: " + ie);
                throw ie;
            }            
            
            if (statusCode != HttpStatus.SC_OK) 
            {
                // The server is up, but the servlet is not accessible
                throw new UnknownServiceException("Servlet Method failed: " 
                                + getMethod.getStatusLine() + " status: " + statusCode);
            }        
            
            // Read the response body.
            in = getMethod.getResponseBodyAsStream();
            out = new FileOutputStream(file);
            
            byte[]                  buf = new byte[4096];
            int                     len;
            
            int tempLen = 0;                        
            int totalLen = 0;
            
            setOwnerNote(messages.getMessage("DOWNLOADING_FILE") + " " + file.getName()); 
            
            while ((len = in.read(buf)) > 0)
            {
                tempLen  += len;
                totalLen += len;
                                    
                if (tempLen > fileLength / DownloaderEngine.getMAXIMUM_PROGRESS())
                {                  
                    tempLen = 0;
                    Thread.sleep(10);                                           
                    addOneOwnerCurrent(); // For ProgressMonitor progress bar 
                }
                            
                if (isOwnerInterrupted())
                {
                    throw new InterruptedException();
                }
                
                out.write(buf, 0, len);
            }
            
        }
        finally
        {
            IOUtils.closeQuietly(out);
            IOUtils.closeQuietly(in);  
            
            if (getMethod != null)
            {
                getMethod.releaseConnection();
            }                      
        }
                           
    }
    
    /**
     * @return true is there is an owner AND it's interrupted
     */
    private boolean isOwnerInterrupted()
    {
        if (m_owner == null)
        {
            return false;
        }
        
        return ((Thread)m_owner).interrupted();
    }
    
    /**
     * Set the owner current note for progression bar
     * @param current
     */
    private void setOwnerNote(String note)
    {
        if (m_owner != null)
        {
            m_owner.setNote(note);
        }
    }  
    
    /**
     * Set th owner current value for progression bar
     * @param current
     */
    private void addOneOwnerCurrent()
    {
        
        if (m_owner != null)
        {
            int current = m_owner.getCurrent();
            current++;
            
            // Do no force interruption
            if (current < DownloaderEngine.getMAXIMUM_PROGRESS())
            {                
                m_owner.setCurrent(current);
            }
            
            //debug("current: " + current);
        }
        
    }    
    
    /**
     * Set the proxy values for this session
     * 
     * @param httpClient    the Http Client instance
     */
    private void setProxy(HttpClient httpClient)
    {
        String proxyAddress = null;            
        int proxyPort = 0;
        
        // Verify if there is a Proxy defined in Preeferences
        if (UserPreferencesManager.getUseProxy())
        {
            proxyAddress        = UserPreferencesManager.getProxyAddress();            
            String proxyPortStr = UserPreferencesManager.getProxyPort();
            
            if (proxyPortStr == null)
            {
                proxyPortStr = "0";
            }
                
            try
            {
                proxyPort = Integer.parseInt(proxyPortStr);
            }
            catch (NumberFormatException e)
            {
                e.printStackTrace(); // Should not happen
            }
            
            if (proxyPort == 0)
            {
                proxyPort = 80;
            }
            
            if (proxyAddress != null && proxyAddress.length() > 1)
            {
              System.setProperty("http.proxyHost", proxyAddress);
              System.setProperty("http.proxyPort", Integer.toString(proxyPort)); 
              
              System.setProperty("https.proxyHost", proxyAddress);
              System.setProperty("https.proxyPort", Integer.toString(proxyPort)); 
              
              // Hre is the important part
              httpClient.getHostConfiguration().setProxy(proxyAddress, proxyPort);      
                            
              // Does the proxy requires Credentieml
              if (UserPreferencesManager.getUseProxyAuth())
              {
                  String proxyUsername = UserPreferencesManager.getProxyUsername();
                  String proxyPassword = UserPreferencesManager.getProxyPassword();
                  
                  // In case of authentication proxy 
                  if (proxyUsername != null && proxyUsername.length() > 1)
                  {                    
                      System.out.println("proxyAuthUsername :" + proxyUsername + ":");
                      System.out.println("proxyAuthPassword :" + proxyPassword + ":");
                      
                      Credentials defaultcreds 
                              = new UsernamePasswordCredentials(proxyUsername, proxyPassword);
                                   
                      httpClient.getState().setProxyCredentials(new AuthScope(proxyAddress, 
                                                                              proxyPort,
                                                                              AuthScope.ANY_REALM), 
                                                                              defaultcreds);
                  }                   
              }

            }                               
        }
        
        setHttpClientTimeout(httpClient);
    }
    
    /**
     * @return true is the last send() command successfully executed
     */
    public boolean isSendOk()
    {
        return this.m_isSendOk;
    }    
    
    /* (non-Javadoc)
     * @see com.safelogic.pgp.apispecs.HttpTransfer#recv()
     */
    public String recv()
    {
        return m_responseBody;
    }
    
    /**
     * Test if a http address is reachable.
     * <br>
     * This means a call with GET method using Jakarata will return a page:
     * <br> - http://www.google.com
     * <br> - https://www.pgeep.com
     * 
     * @param url   the http address or url to test.
     * 
     * @return true if a get method on http address is ok.
     */
    public boolean isHttpReachable(String url)
    {
        boolean isReachable = false;
        
        String recv = null;
        try
        {
            HttpTransferOne httpTransferOne = new  HttpTransferOne();
            httpTransferOne.send(url, "get", null); 
            recv = httpTransferOne.recv();
            
            recv = recv.toLowerCase();
                        
            if (recv != null && recv.contains("<html>"))
            {
                // Reached!
                isReachable = true; 
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
        return isReachable;
    }
    
    
    
//    /**
//     * Test if a http address is reachable.
//     * 
//     * @param httpAddress   the http address to test.
//     * 
//     * @return true if a get method on http address is ok.
//     */
//    private boolean isHttpReachableOLD(String httpAddress)
//    {
//        if (httpAddress == null)
//        {
//            throw new IllegalArgumentException("httpAddress is null!");
//        }
//        
//        String proxyAddress = null;            
//        int proxyPort = 0;
//                    
//        // Get the 10 first lines of the web site. If it's null ==> Not reachable       
//        String content = null;
//        content = getHttpContentFirstLines(httpAddress);
//        
//        if (content != null)
//        {
//            return true;
//        }
//        else
//        {
//            return false;
//        }
//        
//    }
//    
//
//    /**
//     * Get Http Content using native Java apis
//     * 
//     * @param httpAddress       The Http address of the web site
//     * @return  the first 10 lines of the http address
//     */
//    private String getHttpContentFirstLines(String httpAddress)
//    {
//        String content = null;
//        
//        try
//        {
//            URL url = new URL(httpAddress);
//            URLConnection conn = url.openConnection();
//   
//            BufferedReader in = new BufferedReader(
//                    new InputStreamReader(
//                            conn.getInputStream()));
//            String inputLine;
//            
//            int i = 0;
//            
//            while ((inputLine = in.readLine()) != null) 
//            {
//                if (i == 0)
//                {
//                    content = Util.CR_LF + inputLine;
//                }
//                else
//                {
//                    content += Util.CR_LF + inputLine;
//                }
//                
//                i++;
//                
//                if (i > 10)
//                {
//                    break;
//                }
//                
//            }
//
//            in.close();
//        }
//        catch (MalformedURLException e)
//        {
//            e.printStackTrace();
//            content = null;
//        }
//        catch (IOException e)
//        {
//            e.printStackTrace();
//            content = null;
//        }
//        
//        return content;
//    }    
    



    /**
     * debug tool
     */
    private void debug(String s)
    {
        if (DEBUG)
        {
            System.out.println(s);
            //System.out.println(this.getClass().getName() + " " + new Date() + " " + s);
        }
    } 
    
    /** Main */
    public static void main(String[] args)  
        throws Exception
    {
        HttpTransferOne httpTransferOne = new  HttpTransferOne();
        
        httpTransferOne.send("http://www.google.com", "get", null); 
        String recv = httpTransferOne.recv();
        System.out.println(recv);
        
        httpTransferOne.downloadFileFromUrl(new File("c:\\temp\\cGeep_Setup_v3.23a_en.exe"), 
                                           10 * 1024 * 1024, 
                                           "http://www.cgeep.com/download/cGeep_Setup_v3.23a_en.exe");
        System.out.println("done!");
    }
}
