/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.api;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;

import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPSecretKey;

/**
 * PGP Private Key Holder
 * 
 * Necessary because some provider implementations do not define their PGP Private Key as
 * Java PrivateKey
 * 
 * @author Nicolas de Pomereu
 *
 */
public class PgeepPrivateKey implements PrivateKey
{
    
    private PGPSecretKey m_pgpKey = null;
    private char [] pass = null;
    
    /**
     * Constructor
     */
    public PgeepPrivateKey(PGPSecretKey pgpKey, char[] passphrase)
    {
        this.m_pgpKey = pgpKey;
    }

    /**
     * @return Returns the pgpKey.
     */
    public PGPSecretKey getPGPSecretKey()
    {
        return m_pgpKey;
    }
    
    
    /* (non-Javadoc)
     * @see java.security.Key#getAlgorithm()
     */
    public String getAlgorithm()
    {
        try
        {
            return (m_pgpKey.extractPrivateKey(pass, "BC").getKey()).getAlgorithm();
        }
        catch (NoSuchProviderException e)
        {
           // e.printStackTrace();
            return null;
        }
        catch (PGPException e)
        {
            //e.printStackTrace();
            return null;
        }
    }

    /* (non-Javadoc)
     * @see java.security.Key#getEncoded()
     */
    public byte[] getEncoded()
    {
        try
        {
            return m_pgpKey.getEncoded();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    /* (non-Javadoc)
     * @see java.security.Key#getFormat()
     */
    public String getFormat()
    {
        //return m_pgpKey.getFormat();
        return null;
    }

    //Rule 8: Make your classes noncloneable
    public final Object clone() throws java.lang.CloneNotSupportedException {
        throw new java.lang.CloneNotSupportedException();
    }

    //Rule 9: Make your classes nonserializeable
    private final void writeObject(ObjectOutputStream out)
        throws java.io.IOException {
        throw new java.io.IOException("Object cannot be serialized");
    }

    //Rule 10: Make your classes nondeserializeable
    private final void readObject(ObjectInputStream in)
        throws java.io.IOException {
        throw new java.io.IOException("Class cannot be deserialized");
    }        
    
}

