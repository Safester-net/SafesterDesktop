/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.pgp.apispecs;

import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.UnknownServiceException;

import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.ProtocolException;

/**
 * HttpTransfer - 
 * Simple send() and recv() commands on PC side.
 * <br>
 * Purpose of this interface is to wrap the underlying HTTP tool in use in implementation.
 * Default implementation will use HttpClient (http://jakarta.apache.org/commons/httpclient) 
 * <br>
 * Note: 
 * <br> - This interface is not *usable* on HTTP Server side
 * <br> - Design of server will use a ServletControler. The ServletControler will retrieve string
 * with GET.
 * <br> - The ServletControler will send back string using a Serlvet that writes an output on
 * output stream.
 * <br><br>
 * Usage:
 * <br>- Eeach send() must be followed by:
 * <br>-- A isSendOk() to test is all operations are Ok.
 * <br>-- A recv() to get the result as a String()
 * <br>
 * Class includes a downloadFileFromUrl() as it says.
 * <br>
 */
public interface HttpTransfer
{

    /**
     * Send a String to the cGeep HTTP server using the http://www.cgeep.com/do/recv Servlet
     * 
     * @param url       the url of the site. Example http://www.cgeep.com/do/recv 
     * @param method    GET or POST only
     * @param data      the (name, value) pairs for POST methods only
     * 
     * @throws SocketException           if there is no HTTP access 
     * @throws ConnectException          if the www.cgeep.com is not reachable (Tomcat down, etc.)
     * @throws UnknownServiceException   if the www.cgeep.com/do/Recv servlet is not found
     * @throws ProtocolException         if the Recv does not send a clear feedback (program error)
     * @throws IOException               For all other IO / Network / System Error
     */
    public void send(String url, String method, NameValuePair[] data)
        throws  SocketException, 
        ConnectException, 
        UnknownServiceException,
        ProtocolException,
        IOException;
     
   /**
    * Send a String to the cGeep HTTP server using the http://www.cgeep.com/do/recv Servlet
    * @param s     string to send
    * @throws SocketException           if there is no HTTP access 
    * @throws ConnectException          if the www.cgeep.com is not reachable (Tomcat down, etc.)
    * @throws UnknownServiceException   if the wwwcgeep.com/do/Recv servlet is not found
    * @throws ProtocolException         if the Recv does not send a clear feedback (program error)
    * @throws IOException               For all other IO / Network / System Error
    */
    public void send(String s)
    throws  SocketException, 
            ConnectException, 
            UnknownServiceException,
            ProtocolException,
            IOException;
    
    /**
     * @return true is the last send() command successfully executed
     */
    public boolean isSendOk();
    
    /**
     * Receive a String from the HTTP Server.
     * 
     * @return the received string from the HTTP Server
     */
    
    public String recv();
    
    
    /**
     * Download & create a File from an URL.
     * 
     * @param file      the file to create from the download.
     * @param url       the url of the site. Example http://www.cgeep.com/donwload/cGeep_Setup.exe
     * 
     * @throws SocketException           if there is no HTTP access 
     * @throws ConnectException          if the www.cgeep.com is not reachable (Tomcat down, etc.)
     * @throws UnknownServiceException   if the wwwcgeep.com/do/Recv servlet is not found
     * @throws ProtocolException         if the Recv does not send a clear feedback (program error)
     * @throws IOException               For all other IO / Network / System Error
     * @throws InterruptedException      if user interrupts thread
     */
    public void downloadFileFromUrl(File file, long fileLength, String url) 
        throws SocketException, 
               ConnectException, 
               UnknownServiceException,
               ProtocolException,
               IOException,
               InterruptedException;
    
    /**
     * return true if Yahoo is Reachable ==> connected to the Internet.
     * @param httpAddress   the Http Address to test.  Ex: http://www.google.com
     */
    public boolean isHttpReachable(String httpAddress);
    
    
    /**
     * Test if there is a System Proxy defined in Windows
     * @return       0: if there is no System Proxy in use
     *               1: there is a System Proxy in use
     *              -1: It's impossible to know because there is no Internet Connection!    
     */
    
    public int diagnoseProxySetting();
   
}
