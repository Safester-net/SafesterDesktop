/*
 * This file is part of Safester.                                    
 * Copyright (C) 2019, KawanSoft SAS
 * (https://www.Safester.net). All rights reserved.                                
 *                                                                               
 * Safester is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Safester is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 * 
 * Any modifications to this file must keep this entire header
 * intact.
 */
package com.safelogic.utilx.io.pool;

// 22/07/02 12:30 NDP - creation 
// 24/07/02 17:45 NDP - add fault tolerance on secondary stream 
// 26/07/02 17:10 NDP - new name & package
// 30/07/02 18:25 NDP - cleaner warning message with stream index

import java.io.IOException;
import java.io.OutputStream;

/**
 * This class implements all operations in simultaneous for two 
 * or more FilterOutputStream.
 * 
 * <br>- The first one is the "primary" or "main".
 * <br>- The other ones are the "secondaries" or backup stream.
 * <br>
 * There is a "tolerance" mode that allows to continue if an exception occurs 
 * on the secondary streams.
 */

public class OutputStreamPool extends OutputStream 
{
	/** Message to display if a failure happens on secondary stream  */
	public static final String FAILURE_MESSAGE = "WARNING! FAILURE ON SECONDARY IO STREAM!";
	
	/** The OutputStream Pool */
	private OutputStream[] m_osArray;
	
	
	/** If true, any Exception is tolerated on secondary stream. Defaults to false */
	private boolean m_bContinueOnFailure = false;	
	
    /**
     * Mainn Constructor.
     * Create a pool of filter output stream
	 * @param osArray the  output stream array
     */
    public OutputStreamPool(OutputStream[] osArray) 
	{
		this.m_osArray = new OutputStream[osArray.length];	
		
		createAllStreams(osArray);		
    }
	
    /**
     * Mainn Constructor.
     * Create a pool of filter output stream
     * @param osArray the  output stream array
	 * @param bContinueOnFailure if true, accepts faults on any secondary connection
     */
    public OutputStreamPool(OutputStream[] osArray,  boolean bContinueOnFailure) 
	{
		this.m_osArray = new OutputStream[osArray.length];				
		this.m_bContinueOnFailure = bContinueOnFailure;
	
		createAllStreams(osArray);
    }	
	
	
	/**
	 * Creates all the Connectionn into memory
	 * @param osArray the  output stream array
	 */
	private void createAllStreams(OutputStream[] osArray)
	{
		for(int i=0 ; i < osArray.length ; i++)
		{
			this.m_osArray[i] = osArray[i];				
		}			
	}	
		
	/**
	 * Treat the Exception raised, depending on m_bContinueOnFailure
	 * @param	e		The exception raised
	 * @param   nIndex	The index in use
	 */
	
	protected void treatException(Exception e, int nIndex)
		throws IOException
	{
		if (this.m_bContinueOnFailure && nIndex != 0)
		{			
			//CmSystemLogger sl = new CmSystemLogger();
			//sl.log(FAILURE_MESSAGE + " (" + nIndex + ") " + e);			
			//sl.close();						
		}
		else {			
			if (e instanceof IOException)
			{
				throw (IOException)e;
			}
			else if (e instanceof NullPointerException)
			{
				throw (NullPointerException)e;
			}
			else 
			{
				throw new IOException(e.getMessage());
			}
		}		
	}			
		
    /**
     * Writes the specified byte to this output stream. The general 
     * contract for <code>write</code> is that one byte is written 
     * to the output stream. The byte to be written is the eight 
     * low-order bits of the argument <code>b</code>. The 24 
     * high-order bits of <code>b</code> are ignored.
     * <p>
     * Subclasses of <code>OutputStream</code> must provide an 
     * implementation for this method. 
     *
     * @param      b   the <code>byte</code>.
     * @exception  IOException  if an I/O error occurs. In particular, 
     *             an <code>IOException</code> may be thrown if the 
     *             output stream has been closed.
     */
		
	public void write (int b)
		throws IOException
	{
		
		for(int i=0 ; i < m_osArray.length ; i++)
		{			
			try 
			{
				this.m_osArray[i].write(b);
			}
			catch (Exception e)
			{
				treatException(e, i);			
			}							
		}			
		
	}

    /**
     * Writes <code>b.length</code> bytes from the specified byte array 
     * to this output stream. The general contract for <code>write(b)</code> 
     * is that it should have exactly the same effect as the call 
     * <code>write(b, 0, b.length)</code>.
     *
     * @param      b   the data.
     * @exception  IOException  if an I/O error occurs.
     * @see        java.io.OutputStream#write(byte[], int, int)
     */
    public void write(byte b[]) throws IOException {
		this.write(b, 0, b.length);
    }	
	
    /**
     * Writes <code>len</code> bytes from the specified byte array 
     * starting at offset <code>off</code> to this output stream. 
     * The general contract for <code>write(b, off, len)</code> is that 
     * some of the bytes in the array <code>b</code> are written to the 
     * output stream in order; element <code>b[off]</code> is the first 
     * byte written and <code>b[off+len-1]</code> is the last byte written 
     * by this operation.
     * <p>
     * The <code>write</code> method of <code>OutputStream</code> calls 
     * the write method of one argument on each of the bytes to be 
     * written out. Subclasses are encouraged to override this method and 
     * provide a more efficient implementation. 
     * <p>
     * If <code>b</code> is <code>null</code>, a 
     * <code>NullPointerException</code> is thrown.
     * <p>
     * If <code>off</code> is negative, or <code>len</code> is negative, or 
     * <code>off+len</code> is greater than the length of the array 
     * <code>b</code>, then an <tt>IndexOutOfBoundsException</tt> is thrown.
     *
     * @param      b     the data.
     * @param      off   the start offset in the data.
     * @param      len   the number of bytes to write.
     * @exception  IOException  if an I/O error occurs. In particular, 
     *             an <code>IOException</code> is thrown if the output 
     *             stream is closed.
     */
    public void write(byte b[], int off, int len) throws IOException {
	if (b == null) {
	    throw new NullPointerException();
	} else if ((off < 0) || (off > b.length) || (len < 0) ||
		   ((off + len) > b.length) || ((off + len) < 0)) {
	    throw new IndexOutOfBoundsException();
	} else if (len == 0) {
	    return;
	}
	for (int i = 0 ; i < len ; i++) {
	    this.write(b[off + i]);
	}
    }

    /**
     * Flushes this output stream and forces any buffered output bytes 
     * to be written out. The general contract of <code>flush</code> is 
     * that calling it is an indication that, if any bytes previously 
     * written have been buffered by the implementation of the output 
     * stream, such bytes should immediately be written to their 
     * intended destination.
     * <p>
     * The <code>flush</code> method of <code>OutputStream</code> does nothing.
     *
     * @exception  IOException  if an I/O error occurs.
     */
    public void flush() throws IOException 
	{		
		for(int i=0 ; i < m_osArray.length ; i++)
		{			
			try 
			{
				this.m_osArray[i].flush();
			}
			catch (Exception e)
			{
				treatException(e, i);			
			}							
		}	
    }

    /**
     * Closes this output stream and releases any system resources 
     * associated with this stream. The general contract of <code>close</code> 
     * is that it closes the output stream. A closed stream cannot perform 
     * output operations and cannot be reopened.
     * <p>
     * The <code>close</code> method of <code>OutputStream</code> does nothing.
     *
     * @exception  IOException  if an I/O error occurs.
     */
    public void close() throws IOException 
	{
		for(int i=0 ; i < m_osArray.length ; i++)
		{			
			try 
			{
				this.m_osArray[i].flush();
			}
			catch (Exception e)
			{
				treatException(e, i);			
			}							
		}
    }	
	
}

// End
