/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api.client.quickstart;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.SystemUtils;
import org.awakefw.commons.api.client.HttpProxy;
import org.awakefw.file.api.client.AwakeFileSession;
import org.awakefw.file.api.client.AwakeUrl;

/**
 * 
 * This example:
 * <ul>
 * <li>Creates a remote directory.</li>
 * <li>Uploads two files to the remote directory.</li>
 * <li>Lists the content of the remote directory.</li>
 * <li>Downloads the files of the remote directory.</li>
 * </ul>
 * 
 * @author Nicolas de Pomereu
 */
public class MyAwakeFileSession1_1 {

    /** The session to the remote Awaker File server */
    private AwakeFileSession awakeFileSession = null;

    /**
     * AwakeFileSession Quick Start client example. Creates an Awake File
     * Session.
     * 
     * @return the Awake File Session to the remote Awake File server
     * @throws IOException
     *             if communication or configuration error is raised
     */
    public static AwakeFileSession awakeFileSessionBuilder() throws IOException {

	HttpProxy httpProxy = new HttpProxy("127.0.0.1", 8080);
	
	System.out.println(new Date() + " java: " + SystemUtils.JAVA_VERSION);	
	System.out.println(new Date() + " connecting with proxy " + httpProxy);
	AwakeUrl awakeUrl = new AwakeUrl(httpProxy);

        //debug(new Date() + " checkUrlDownload(): awakeSession.downloadUrl()..." );
        
        @SuppressWarnings("unused")
        String content = awakeUrl.download(new URL("http://www.google.com"));
        
	System.out.println("Connected! Content: " + content.length());
	
	// Modify the URL of the path to your AwakeFileManager Servlet:
	String url = "https://www.safester.net/safester_vault/AwakeFileServer";

	// (usename, password) for authentication on server side.
	// No authentication will be done for our Quick Start:
	String username = "demo";
	char[] password = { 'd', 'e', 'm', 'o' };
		
	System.out.println(new Date() + " Connecting...");
		
	// Create the Awake File Session to the remote server:
	AwakeFileSession awakeFileSession = new AwakeFileSession(url, username,
		password, httpProxy);
	System.out.println(new Date() + " Connected...");
	return awakeFileSession;
    }

    /**
     * Do some Awake File operations. This example:
     * <ul>
     * <li>Creates a remote directory.</li>
     * <li>Uploads two files to the remote directory.</li>
     * <li>Lists the content of the remote directory.</li>
     * <li>Downloads the files of the remote directory.</li>
     * </ul>
     * 
     * @throws IOException
     *             if communication or configuration error is raised
     */
    public void doIt() throws IOException {

	// Define userHome var
	String userHome = System.getProperty("user.home") + File.separator;

	// Create a remote directory on the server:
	awakeFileSession.mkdirs("/mydir");

	// Upload two files image-1.jpg and image-2.jpg file located in our
	// user.home directory to the remote directory /mydir
	File image1 = new File(userHome + "image-1.jpg");
	File image2 = new File(userHome + "image-2.jpg");

	awakeFileSession.upload(image1, "/mydir/image-1.jpg");
	awakeFileSession.upload(image2, "/mydir/image-2.jpg");

	// List the subdirectories of our virtual server
	List<String> remoteDirs = awakeFileSession.listDirectories("/");
	System.out.println("directories located in /: " + remoteDirs);

	// List the files located in remote directory /mydir
	List<String> remoteFiles = awakeFileSession.listFiles("/mydir");
	System.out.println("files located in /mydir: " + remoteFiles);

	// Download the files - with a new name - in our user.home directory
	File downloadedImage1 = new File(userHome + "downloaded-image-1.jpg");
	File downloadedImage2 = new File(userHome + "downloaded-image-2.jpg");

	awakeFileSession.download("/mydir/image-1.jpg", downloadedImage1);
	awakeFileSession.download("/mydir/image-2.jpg", downloadedImage2);

	System.out.println("done!");
    }

    /**
     * Constructor
     * 
     * @param awakeFileSession
     *            the Awake File Session to use for this session
     */
    private MyAwakeFileSession1_1(AwakeFileSession awakeFileSession) {
	this.awakeFileSession = awakeFileSession;
    }

    /**
     * Main
     * 
     * @param args
     *            not used
     */
    public static void main(String[] args) throws IOException {

	AwakeFileSession awakeFileSession = MyAwakeFileSession1_1
		.awakeFileSessionBuilder();
	MyAwakeFileSession1_1 myAwakeFileSession = new MyAwakeFileSession1_1(
		awakeFileSession);
	myAwakeFileSession.doIt();

    }

}
