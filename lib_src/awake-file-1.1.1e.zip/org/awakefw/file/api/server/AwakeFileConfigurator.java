/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api.server;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.awakefw.commons.api.server.AwakeCommonsConfigurator;

/**
 * 
 * Interface that defines the User Configuration for the Awake File Framework.
 * <p>
 * All the implemented methods will be called by the Awake Server programs when
 * a client program asks for a file operation from the client, or when a client
 * program asks for a RPC call of a Java.
 * <p>
 * A concrete implementation should be developed on the server side in order to:
 * <ul>
 * <li>Define the Awake File Server root directory.</li>
 * <li>Define if each client username has his own root directory.</li>
 * <li>Define a specific piece of Java code to analyze the method name and it's
 * parameter values before allowing or not it's execution.</li>
 * <li>Execute a specific piece of Java code if the method not allowed.</li>
 * </ul>
 * Please note that Awake File comes with a Default AwakeFileConfigurator
 * implementation that is *not* secured and should be extended:
 * {@link DefaultAwakeFileConfigurator}.
 * <p>
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */

public interface AwakeFileConfigurator {

    /**
     * Allows to define the Awake File Server root directory for the file
     * storage & access.
     * 
     * @return the path of the Server Root. <code>null</code> if there is no
     *         server root to define (adress of files will be absolute when
     *         uploading, downloading, etc.)
     */
    public File getServerRoot();

    /**
     * Allows to define if the Awake File Server must use a root directory per
     * client username for the file storage & access. <br>
     * If <code>true</code>, the name of the username will be used as root
     * directory per user.
     * 
     * @return <code>true</code> if there is one root directory per client
     *         username
     */
    public boolean useOneRootPerUsername();

    /**
     * Allows, for the passed client username, to define  a specific piece of Java code to 
     * analyze the method name and it's parameter values before allowing or not it's execution.
     * <br>
     * If the analysis defined by the method returns false, the the method call won't be
     * executed.
     * 
     * @param username
     *            the client username to check the rule for
     * @param connection
     *            the SQL Connection as configured in
     *            {@link AwakeCommonsConfigurator#getConnection()}
     *            implementation. Will be null if {@code getConnection()} was no
     *            configured.
     * @param methodName
     *            the full method name to call in the format
     *            <code>org.acme.config.package.MyClass.myMethod</code>
     * @param params
     *            the list of parameters passed to the method. Empty list if
     *            none.
     * 
     * @return <code>true</code> if the analyzed call is validated.
     *         <p>
     * @throws IOException
     *             if an IOException occurs
     * @throws SQLException
     *             if a SQLException occurs
     */
    public boolean allowCallAfterAnalysis(String username,
	    Connection connection, String methodName, List<Object> params)
	    throws IOException, SQLException;

    /**
     * Allows to implement specific a Java rule immediately after a call has
     * been refused to a user and <code>allowCallAfterAnalysis</code> returned
     * <code>false</code>. <br>
     * <br>
     * Examples:
     * <ul>
     * <li>Delete the user from the username Sql table so that he never comes
     * back,</li>
     * <li>Log the IP address,</li>
     * <li>Log the info,</li>
     * <li>Send a alert message/email to a Security Officer,</li>
     * <li>Etc.</li>
     * </ul>
     * 
     * @param username
     *            the client username
     * @param connection
     *            the SQL Connection as configured in
     *            {@link AwakeCommonsConfigurator#getConnection()}
     *            implementation. Will be null if {@code getConnection()} was no
     *            configured.
     * @param ipAddress
     *            the IP address of the client user
     * @param methodName
     *            the full method name to call in the format
     *            <code>org.acme.config.package.MyClass.myMethod</code>
     * @param params
     *            the list of parameters passed to the method
     *            <p>
     * @throws IOException
     *             if an IOException occurs
     * @throws SQLException
     *             if a SQLException occurs
     */
    public void runIfCallRefused(String username, Connection connection,
	    String ipAddress, String methodName, List<Object> params)
	    throws IOException, SQLException;

}
