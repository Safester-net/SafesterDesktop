/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api.server;

//Copyright (c) Kawan Softwares S.A.S, 2000 - 2009
//
//Last Updates: 
// 12 juil. 07 21:44:29 Nicolas de Pomereu
// 19/10/07 13:44 ABE : Allow doctors to connect
// 22/09/09 13:44 NDP : Uses new mechanism
// 23/09/09 15:30 NDP : Fix bug: doctors were always authorized 
// 15/12/09 15:25 NDP : Fix bug: admin could not log in!
// 15/09/09 16:00 NDP : Fix bug: doctors were not authorized (necessary for applet)
// 21/01/10 19:30 NDP - Add getCallableClassesWithoutAuthentication()
// 26/01/10 19:55 NDP - Add allowFileTransferOperation() & allowSqlOperation
// 25/09/10 09:10 NDP - DefaultAwakeFileConfigurator: add allowExecuteAfterAnalysis()
// 03/10/10 16:40 NDP - Return  empty Set instead of null
// 06/06/11 17:40 NDP : DefaultAwakeFileConfigurator: add method name and parameters into actionIfCallDisallowed()
// 16/07/11 13:15 NDP : DefaultAwakeFileConfigurator: remove getCallableXxx() methods
// 17/07/11 15:25 NDP : DefaultAwakeFileConfigurator: new name for actionIfCallDisallowed ==>  runIfCallDisallowed
// 17/07/11 20:05 NDP : DefaultAwakeFileConfigurator: not secured at all for immediate start
// 20/09/11 18:40 NDP : DefaultAwakeFileConfigurator: allowCallAfterAnalysis throws IOException
// 20/09/11 18:40 NDP : DefaultAwakeFileConfigurator: allowCallAfterAnalysis throws IOException & SQLException
// 20/09/11 19:10 NDP : DefaultAwakeFileConfigurator: runIfCallDisallowed throws IOException & SQLException
// 31/10/11 14:50 NDP : DefaultAwakeFileConfigurator: change getServerRoot() to user.home/awake and
//			useOneRootDirectoryPerUsername returns true
// 25/11/11 16:15 NDP : DefaultAwakeFileConfigurator: parameterValues list are now Object
// 07/12/11 18:15 NDP : DefaultAwakeFileConfigurator: clean javadoc
// 10/01/12 19:00 NDP : DefaultAwakeFileConfigurator: getServerRoot returns a File on the OS & 
//			directory is user.home/.awake & clean Javadoc
// 10/01/12 20:55 NDP : DefaultAwakeFileConfigurator: getServerRoot returns now user.home/.awake-server-root
// 11/01/12 13:35 NDP : DefaultAwakeFileConfigurator: useOneRootDirectoryPerUsername renamed to oneRootPerUsername
// 12/01/12 19:05 NDP : DefaultAwakeFileConfigurator: clean Javadoc
// 03/03/12 15:55 NDP : DefaultAwakeFileConfigurator: runIfCallDisallowed is rewritten
//10/03/12 20:00 NDP : DefaultAwakeFileConfigurator: oneRootPerUsername renamed useOneRootPerUsername

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.awakefw.commons.api.server.DefaultAwakeCommonsConfigurator;

/**
 * Default implementation of server side configuration for the Awake File
 * Framework:
 * <ul>
 * <li>The Awake File root directory will be {@code user.home/.awake-server-root}, where {@code user.home} is
 * the one of the Servlet container.</li>
 * <li>The Awake File Manager will use one root directory per username.</li>
 * </ul>
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */
public class DefaultAwakeFileConfigurator implements AwakeFileConfigurator {

    /**
     * Constructor.
     */
    public DefaultAwakeFileConfigurator() {

    }

    /**
     * @return <code>user.home/.awake-server-root</code>. ({@code user.home} is the one of the
     *         servlet container).
     */
    @Override
    public File getServerRoot() {
	String userHome = System.getProperty("user.home");
	if (!userHome.endsWith(File.separator)) {
	    userHome += File.separator;
	}
	userHome += ".awake-server-root";
	return new File(userHome);
    }

    /**
     * @return <b><code>true</code></b>: each user have it's own root
     *         directory. (The root directory name is the login username).
     */
    @Override
    public boolean useOneRootPerUsername() {
	return true;
    }

    /**
     * @return <code><b>true</b></code>: all methods called are always allowed
     *         for all client usernames
     */
    @Override
    public boolean allowCallAfterAnalysis(String username,
	    Connection connection, String methodName, List<Object> params)
	    throws IOException, SQLException {
	return true;
    }

    /**
     * 
     * The event will be logged as <code>Level.WARNING</code> in the
     * <code>user.home/.awake/log/Awake.log</code> file
     */
    @Override
    public void runIfCallRefused(String username, Connection connection,
	    String ipAddress, String methodName, List<Object> params)
	    throws IOException, SQLException {
		
	Logger logger = new DefaultAwakeCommonsConfigurator().getLogger();
	
	logger.log(Level.WARNING, "Client " + username + "(IP: "
		+ ipAddress + ") has been denied executing method: "
		+ methodName + " with parameters: " + params);
    }

}
