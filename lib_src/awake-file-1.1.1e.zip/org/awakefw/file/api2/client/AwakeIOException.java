/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api2.client;

import java.io.IOException;

/**
 * Signals a wrapped Exception - can be a local Exception or a remote SQL
 * Exception. Use <code>getCause</code> to get the original local or remote
 * Exception.
 */

public final class AwakeIOException extends IOException {

    private static final long serialVersionUID = 513945620132796805L;

    private String remoteStackTrace = null;

    /**
     * Constructs a <code>AwakeIOException</code> object with a given
     * <code>reason</code>. The <code>SQLState</code> is initialized to
     * <code>null</code> and the vender code is initialized to 0.
     * 
     * The <code>cause</code> is not initialized, and may subsequently be
     * initialized by a call to the
     * {@link Throwable#initCause(java.lang.Throwable)} method.
     * <p>
     * 
     * @param reason
     *            a description of the exception
     */
    public AwakeIOException(String reason) {
	super(reason);
    }

    /**
     * Constructs a <code>AwakeIOException</code> object with a given
     * <code>cause</code>. The <code>SQLState</code> is initialized to
     * <code>null</code> and the vendor code is initialized to 0. The
     * <code>reason</code> is initialized to <code>null</code> if
     * <code>cause==null</code> or to <code>cause.toString()</code> if
     * <code>cause!=null</code>.
     * <p>
     * 
     * @param cause
     *            the underlying reason for this <code>SQLException</code>
     *            (which is saved for later retrieval by the
     *            <code>getCause()</code> method); may be null indicating the
     *            cause is non-existent or unknown.
     * @since 1.6
     */
    public AwakeIOException(Throwable cause) {
	super(cause);
    }

    /**
     * Constructs a <code>AwakeIOException</code> object with a given
     * <code>reason</code> and <code>cause</code>. The <code>SQLState</code> is
     * initialized to <code>null</code> and the vendor code is initialized to 0.
     * <p>
     * 
     * @param reason
     *            a description of the exception.
     * @param cause
     *            the underlying reason for this <code>SQLException</code>
     *            (which is saved for later retrieval by the
     *            <code>getCause()</code> method); may be null indicating the
     *            cause is non-existent or unknown.
     * @since 1.6
     */
    public AwakeIOException(String reason, Throwable cause) {
	super(reason, cause);
    }

    /**
     * Constructs a <code>AwakeIOException</code> object with a given
     * <code>reason</code> and <code>cause</code>. The <code>SQLState</code> is
     * initialized to <code>null</code> and the vendor code is initialized to 0.
     * <p>
     * 
     * @param reason
     *            a description of the exception.
     * @param cause
     *            the underlying reason for this <code>SQLException</code>
     *            (which is saved for later retrieval by the
     *            <code>getCause()</code> method); may be null indicating the
     *            cause is non-existent or unknown.
     * @param remoteStackTrace
     *            the remote stack trace as string to use
     * @since 1.6
     */
    public AwakeIOException(String reason, Throwable cause,
	    String remoteStackTrace) {
	super(reason, cause);
	this.remoteStackTrace = remoteStackTrace;
    }

    /**
     * Returns the remote Stack Trace as a display string
     * 
     * @return the remote Stack Trace as a display string
     */
    public String getRemoteStackTrace() {
	return this.remoteStackTrace;
    }

}
