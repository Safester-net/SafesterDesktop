/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.api2.client;

import java.io.File;

/**
 * @author Nicolas de Pomereu
 * 
 */
@SuppressWarnings("unused")
public class RemoteFile {
    File file = null;

    /**
     * The ServerCallerNew instance. May be reused for file transfers, per
     * example
     */
    private AwakeFileSessionNew awakeFileSession = null;

    /**
     * Constructor
     * 
     * @param awakeFileSession
     */
    public RemoteFile(AwakeFileSessionNew awakeFileSession) {
	this.awakeFileSession = awakeFileSession;
    }

    /**
     * @return
     * @see java.io.File#exists()
     */
    public boolean exists() {
	return this.file.exists();
    }

    /**
     * @return
     * @see java.io.File#isDirectory()
     */
    public boolean isDirectory() {
	return this.file.isDirectory();
    }

    /**
     * @return
     * @see java.io.File#isFile()
     */
    public boolean isFile() {
	return this.file.isFile();
    }

    /**
     * @return
     * @see java.io.File#length()
     */
    public long length() {
	return this.file.length();
    }

    /**
     * @return
     * @see java.io.File#delete()
     */
    public boolean delete() {
	return this.file.delete();
    }

    /**
     * @return
     * @see java.io.File#list()
     */
    public String[] list() {
	return this.file.list();
    }

    /**
     * @return
     * @see java.io.File#mkdir()
     */
    public boolean mkdir() {
	return this.file.mkdir();
    }

    /**
     * @return
     * @see java.io.File#mkdirs()
     */
    public boolean mkdirs() {
	return this.file.mkdirs();
    }

}
