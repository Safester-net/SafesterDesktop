/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.util;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;

/**
 * @author Nicolas de Pomereu
 *
 */
public class TrustCert {

    /**
     * 
     */
    public TrustCert() {
	// TODO Auto-generated constructor stub
    }

    public DefaultHttpClient getDefaultHttpClientWithCertTrust()
	    throws IOException, GeneralSecurityException {

	TrustStrategy acceptingTrustStrategy = new TrustSelfSignedStrategy() {
	    @Override
	    public boolean isTrusted(X509Certificate[] certificate,
		    String authType) {
		return true;
	    }
	};
	System.out.println("In getDefaultHttpClientWithCertTrust");
	SSLSocketFactory sf = new SSLSocketFactory(acceptingTrustStrategy,
		SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	SchemeRegistry registry = new SchemeRegistry();
	registry.register(new Scheme("https", 8443, sf));
	ClientConnectionManager ccm = new PoolingClientConnectionManager(
		registry);

	DefaultHttpClient httpClient = new DefaultHttpClient(ccm);
	return httpClient;

    }
    
    public DefaultHttpClient forceTls() throws Exception {
        SSLContext ctx = SSLContext.getInstance("TLS");
        
//        X509TrustManager tm = new X509TrustManager() {
//
//            public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
//            }
//
//            public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
//            }
//
//            public X509Certificate[] getAcceptedIssuers() {
//                return null;
//            }
//        };

        DefaultHttpClient base = new DefaultHttpClient();
        ctx.init(null, null, null);
        SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        
        ClientConnectionManager ccm = base.getConnectionManager();
        SchemeRegistry sr = ccm.getSchemeRegistry();
        sr.register(new Scheme("https", 443, ssf));


        DefaultHttpClient httpClient = new DefaultHttpClient(ccm, base.getParams());
        return httpClient;
    }

}
