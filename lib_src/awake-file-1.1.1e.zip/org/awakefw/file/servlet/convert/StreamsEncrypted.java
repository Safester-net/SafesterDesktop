/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.servlet.convert;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.fileupload.util.Streams;
import org.apache.commons.lang3.StringUtils;
import org.awakefw.commons.api.server.AwakeCommonsConfigurator;
import org.awakefw.file.util.Tag;
import org.awakefw.file.util.convert.Pbe;

/**
 * 
 * Wrapper/holder for org.apache.commons.fileupload.util.Streams that will allow
 * to decrypt correctly the request.getParameter()
 * 
 * @author Nicolas de Pomereu
 * 
 */

public class StreamsEncrypted {

    /**
     * Protected constructor
     */
    protected StreamsEncrypted() {

    }

    /**
     * @param stream
     *            The ServletFileUpload input stream
     * @param awakeCommonsConfigurator
     *            Used to get the password for encryption
     */
    public static String asString(InputStream stream,
	    AwakeCommonsConfigurator awakeCommonsConfigurator)
	    throws IOException {
	String value = Streams.asString(stream);

	if (isEncrypted(value, awakeCommonsConfigurator)) {
	    try {
		value = StringUtils.substringAfter(value, Pbe.AWAKE_ENCRYPTED);
		value = new Pbe().decryptFromHexa(value,
			awakeCommonsConfigurator
				.getEncryptionPassword());
		return value;
	    } catch (Exception e) {
		String message = Tag.AWAKE_USER_CONFIG_FAIL
			+ "Impossible to decrypt the value " + value;
		message += ". Check that password values are the same on client and server side.";

		throw new IOException(message, e);
	    }
	} else {
	    return value;
	}
    }

    /**
     * Says it the request is encrypted
     * 
     * @param parameterName
     *            the parameter name
     * @return if the request is encrypted
     */
    private static boolean isEncrypted(String value,
	    AwakeCommonsConfigurator awakeCommonsConfigurator) {
	if (awakeCommonsConfigurator != null
		&& awakeCommonsConfigurator
			.getEncryptionPassword() != null) {
	    if (value != null && !value.isEmpty()
		    && value.startsWith(Pbe.AWAKE_ENCRYPTED)) {
		return true;
	    } else {
		return false;
	    }
	} else {
	    return false;
	}
    }

}
