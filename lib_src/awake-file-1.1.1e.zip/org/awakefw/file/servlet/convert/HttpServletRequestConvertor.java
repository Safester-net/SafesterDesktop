/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.file.servlet.convert;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.lang3.StringUtils;
import org.awakefw.commons.api.server.AwakeCommonsConfigurator;
import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.api.util.HtmlConverter;
import org.awakefw.file.util.Tag;
import org.awakefw.file.util.convert.Pbe;
import org.awakefw.file.util.parms.Parameter;

/**
 * Wrapper/holder for HttpServletRequest that will allow to decrypt correctly
 * the request.getParameter()
 * 
 * @author Nicolas de Pomereu
 * 
 */
public class HttpServletRequestConvertor extends HttpServletRequestWrapper {
    
    private static boolean DEBUG = AwakeDebug
	    .isSet(HttpServletRequestConvertor.class);
    
    /**
     * The AwakeCommonsConfigurator instance. Used to get the password for
     * encryption
     */
    private AwakeCommonsConfigurator awakeCommonsConfigurator = null;

    /**
     * Constructor
     * 
     * @param request
     *            the underlying HttpServletRequest
     * @param awakeCommonsConfigurator
     *            Used to get the password for encryption
     */
    public HttpServletRequestConvertor(HttpServletRequest request,
	    AwakeCommonsConfigurator awakeCommonsConfigurator) {
	super(request);
	this.awakeCommonsConfigurator = awakeCommonsConfigurator;
    }

    /**
     * Will decrypt - if necessary - the parameter and return it's decrypted
     * value caller
     * 
     * @param parameterName
     *            the encrypted or not parameter name
     * @return the parameter value, decrypted if necessary.
     */
    @Override
    public String getParameter(String parameterName) {
	String value = super.getParameter(parameterName);

	if (parameterName.equals(Parameter.STATEMENT_HOLDER) || value == null
		|| value.isEmpty()) {
	    return value;
	}

	try {
	    value = decryptValue(parameterName, value);
	} catch (Exception e) {
	    String message = Tag.AWAKE_USER_CONFIG_FAIL
		    + "Impossible to decrypt the value of the parameter "
		    + parameterName;
	    message += ". Check that password values are the same on client and server side.";

	    throw new IllegalArgumentException(message, e);
	}

	// The values are HTML converted in new version >= v1.0.5
	// This is just for transition when calling call()
	String version = super.getParameter(Parameter.VERSION);
	
	debug("param name : " + parameterName);
	debug("param value: " + value);
	
	if (version != null) {
	    // New protocol (implemented for Awake SQL version >= v1.0.5
	    value = HtmlConverter.fromHtml(value);
	}
		
	return value;
    }

   
    /**
     * Says it the request is encrypted
     * 
     * @param parameterName
     *            the parameter name
     * @return if the request is encrypted
     */
    private boolean isRequestEncrypted(String parameterName) {
	String value = super.getParameter(parameterName);
	if (value != null && !value.isEmpty()
		&& value.startsWith(Pbe.AWAKE_ENCRYPTED)) {
	    return true;
	} else {
	    return false;
	}
    }

    /**
     * Decrypt the value
     * 
     * @param parameterName
     * @param value
     * @return
     * @throws Exception
     * @throws IllegalArgumentException
     */
    private String decryptValue(String parameterName, String value)
	    throws Exception, IllegalArgumentException {
	
	if (! isRequestEncrypted(parameterName)) {
	    return value;
	}
	
	value = StringUtils.substringAfter(value, Pbe.AWAKE_ENCRYPTED);
	value = new Pbe().decryptFromHexa(value,
		awakeCommonsConfigurator.getEncryptionPassword());

	debug("value: " + value);
	
	// Check coherence for known parms and value
	// Parameter.ACTION, Parameter.TEST_CRYPTO

	if (parameterName.equals(Parameter.TEST_CRYPTO)) {
	    if (!value.equals(Parameter.TEST_CRYPTO)) {
		String message = Tag.AWAKE_USER_CONFIG_FAIL
			+ "Impossible to decrypt correctly the value of the parameter "
			+ parameterName;
		message += ". Check that password values are the same on client and server side.";

		throw new IllegalArgumentException(message);
	    }
	}
	return value;
    }
    
    private void debug(String s) {
	if (DEBUG) {
	    //AwakeServerLogger.log(s);
	    System.out.println(new Date() + " " + HttpServletRequestConvertor.class.getSimpleName() + " " + s);
	}
    }    
}
