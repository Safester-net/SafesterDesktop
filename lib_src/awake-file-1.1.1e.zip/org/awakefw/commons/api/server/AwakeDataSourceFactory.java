/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.api.server;

import java.io.File;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;
import javax.sql.DataSource;

import org.awakefw.file.api.util.AwakeDebug;
import org.awakefw.file.util.Tag;

/**
 * 
 * JNDI object factory that creates an instance of the
 * <code>{@link AwakeDataSource}</code> class for the Awake default connection
 * pooling system.<br>
 * <br>
 * This class must *not* be called directly by a user program. <br>
 * <br>
 * This class will be called/created automatically by any Java EE compatible
 * modern application/web server.<br>
 * ( <a href="http://glassfish.java.net/">GlassFish</a>, <a
 * href="http://www.jboss.org">JBoss</a>, <a
 * href="http://wiki.jonas.ow2.org/xwiki/bin/view/Main/">JOnAS</a>, <a
 * href="http://www.orionserver.com">Orion</a>, <a
 * href="http://jakarta.apache.org/tomcat">Tomcat</a>, <a href=
 * "http://www.oracle.com/technetwork/middleware/weblogic/overview/index.html"
 * >WebLogic</a>, <a
 * href="http://www.ibm.com/software/websphere/">WebSphere</a>, etc.). <br>
 * <br>
 * The <code>{@link javax.naming.RefAddr}</code> values of the specified
 * <code>{@link javax.naming.Reference}</code> must match the names and data
 * types of the {@link AwakeDataSource} bean properties. <br>
 * <br>
 * Please configure your application server to load this factory and configure
 * the values of the <code>RefAddr</code> parameters in a {@code <Resource>}
 * <ul>
 * <li><b>driverClassName</b>: Fully qualified Java class name of your JDBC
 * driver to be used.</li>
 * <li><b>url</b>: Connection URL to be passed to your JDBC driver.</li>
 * <li><b>username</b>: Database username to be passed to your JDBC driver.</li>
 * <li><b>password</b>: Database password to be passed to your JDBC driver.</li>
 * <li><b>minConns</b>: Minimum number of connections to start with. Must be
 * &gt; 0.</li>
 * <li><b>maxConns</b>: Maximum number of connections in dynamic pool. Must be
 * &gt;= minConns.</li>
 * <li><b>maxConnTime</b>: Time in days between connection resets. Defaults to
 * 1. (Reset does a basic cleanup.)</li>
 * <li><b>maxCheckoutSeconds</b>: Maximum time in seconds a
 * <code>Connection</code> can be checked out before being recycled. This value
 * is thus the maximum duration of a SQL request. Default value is 180 seconds.
 * Zero value turns option off.</li>
 * <li><b>logAppend</b>: Boolean that says if log is in append mode. Defaults to false.</li>
 * <li><b>logFile</b>: Absolute path name for log file. e.g. '/tmp/mylog.log'.
 * Defaults to 'user.home/.awake/log/DbConnectionBroker.log'</li>
 * 
 * </ul>
 * 
 * <br>
 * Configuration example in server.xml:
 * 
 * <pre>
 * <code>
 * &lt;Context path="/awake-test"&gt;
 * &nbsp;
 *   &lt;!-- JDBC Driver values used by DefaultAwakeCommonsConfigurator.getConnection() --&gt; 
 *   &lt;!-- Modify the driver info according to your JDBC Driver --&gt; 
 * &nbsp;
 *   &lt;Resource name="jdbc/awake-oracle"
 *             auth="Container"
 *             type="javax.sql.DataSource"
 *             factory="org.awakefw.commons.api.server.AwakeDataSourceFactory"
 * &nbsp;
 *             driverClassName="oracle.jdbc.driver.OracleDriver"
 *             url="jdbc:oracle:thin:awake-example@//localhost:1521/XE"
 *             username="user1"
 *             password="password1"
 *             minConns="2"
 *             maxConns="10" /&gt;
 *             
 * &lt;/Context&gt;
 * </pre>
 * 
 * </code> Corresponding Java code in a concrete
 * {@link AwakeCommonsConfigurator} implementation in order to retrieve a
 * Connection from the pool:
 * 
 * <pre>
 * <code>
 * // The connection pool will be loaded only once and the kept in memory: 
 * private DataSource dataSource = null;
 * &nbsp;
 * <code>@Override</code>
 *     public Connection getConnection() throws SQLException {
 * &nbsp;
 * 	String defaultResourceName = "jdbc/awake-oracle";
 * &nbsp;
 * 	// Load only once the pool
 * 	if (this.dataSource == null) {
 * 	    try {
 * 		Context initCtx0 = (Context) new InitialContext()
 * 			.lookup("java:comp/env");
 * 		dataSource = (DataSource) initCtx0.lookup(defaultResourceName);
 * 
 * 	    } catch (NamingException e) {
 * 		throw new SQLException(
 * 			"Invalid <Resource> configuration. Lookup failed on resource: ",
 * 			e);
 * 	    }
 * 	}
 * &nbsp;
 * 	return dataSource.getConnection();
 *     }
 * </code>
 * </pre>
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */

public class AwakeDataSourceFactory implements ObjectFactory {

    static boolean DEBUG = AwakeDebug.isSet(AwakeDataSourceFactory.class);

    private static String DRIVER_CLASS_NAME = "driverClassName";
    private static String URL = "url";
    private static String USERNAME = "username";
    private static String PASSWORD = "password";
    private static String MIN_CONNS = "minConns";
    private static String MAX_CONNS = "maxConns";
    private static String MAX_CONN_TIME = "maxConnTime";
    private static String MAXCHECKOUTSECONDS = "maxCheckoutSeconds";
    private static String LOG_APPEND = "logAppend";
    private static String LOG_FILE = "logFile";


    /** Contains all properties names */
    private static String[] PROPERTIES_ARRAY = { DRIVER_CLASS_NAME, URL,
	    USERNAME, PASSWORD, MIN_CONNS, MAX_CONNS, MAX_CONN_TIME, MAXCHECKOUTSECONDS, LOG_APPEND, LOG_FILE };

    /** Store the Reference/RefAddr values */
    private Properties properties = null;

    /**
     * This class should *not* be instanced (this constructor is mandatory for
     * EJB behavior).
     */
    public AwakeDataSourceFactory() {
	// Constructor declared.
	debug("AwakeDataSourceFactory() constructor");
    }

    /**
     * Creates and returns a new <code>AwakeDataSource</code> instance. If no
     * instance can be created, return <code>null</code> instead.</p>
     * 
     * @param obj
     *            The object, which may be null, that contains location or
     *            reference information to be used to create an object
     * 
     * @param name
     *            The name of this object relating to <code>nameCtx</code>
     * 
     * @param nameCtx
     *            The context relative to which the <code>name</code> parameter
     *            is specified, or <code>null</code> if <code>name</code>
     *            relates to the default initial context
     * 
     * @param environment
     *            The environment, which may be null, that is used in to create
     *            this object
     * 
     * @exception Exception
     *                if an exception occurs creating the instance
     */
    @Override
    public Object getObjectInstance(Object obj, Name name, Context nameCtx,
	    @SuppressWarnings("rawtypes")
	    Hashtable environment) throws Exception {

	debug("getObjectInstance() begin");

	if ((obj == null) || !(obj instanceof Reference)) {
	    System.out
		    .println(Tag.AWAKE_USER_CONFIG_FAIL
			    + "Invalid <Resource> configuration for Resource: " + name
			    +". type is null or not a Reference.");
	    return null;
	}

	Reference reference = (Reference) obj;
	String className = reference.getClassName();

	if (!className.equals(javax.sql.DataSource.class.getName())
		&& !className
			.equals(org.awakefw.commons.api.server.AwakeDataSource.class
				.getName())) {
	    System.out
		    .println(Tag.AWAKE_USER_CONFIG_FAIL
			    + "Invalid <Resource> configuration for Resource: " + name
			    +". The DataSource name is invalid: "
			    + className);
	    return null;
	}

	this.properties = new Properties();

	for (int i = 0; i < PROPERTIES_ARRAY.length; i++) {
	    String propertyName = PROPERTIES_ARRAY[i];
	    RefAddr refAddr = reference.get(propertyName);

	    if (refAddr != null) {
		String propertyValue = refAddr.getContent().toString();
		this.properties.setProperty(propertyName, propertyValue);
	    }
	}

	debug("obj    : " + obj);
	debug("name   : " + name);
	debug("nameCtx: " + nameCtx);
	
	return createAwakeDataSource(name);
    }

    /**
     * Creates a an AwakeDataSource instance (with the passed JNDI properties)
     * @param name
     *            The name of this object relating to <code>nameCtx</code>
     */
    private DataSource createAwakeDataSource(Name name) throws Exception {

	String driverClassName = properties.getProperty(DRIVER_CLASS_NAME);
	String url = properties.getProperty(URL);
	String username = properties.getProperty(USERNAME);
	String password = properties.getProperty(PASSWORD);
	String minConnsStr = properties.getProperty(MIN_CONNS);
	String maxConnsStr = properties.getProperty(MAX_CONNS);
	String maxConnTimeStr = properties.getProperty(MAX_CONN_TIME);
	String maxCheckoutSecondsStr = properties.getProperty(MAXCHECKOUTSECONDS);
	String logAppendStr = properties.getProperty(LOG_APPEND);
	String logFileStr = properties.getProperty(LOG_FILE);

	debug("In createAwakeDataSource():");
	debug("driverClassName: " + driverClassName);
	debug("url                : " + url);
	debug("username           : " + username);
	debug("password           : " + password);
	debug("minConnsStr        : " + minConnsStr);
	debug("maxConnsStr        : " + maxConnsStr);
	debug("maxConnTimeStr     : " + maxConnTimeStr);
	debug("maxCheckoutSeconds : " + maxCheckoutSecondsStr);
	debug("logAppendStr       : " + logAppendStr);	
	debug("logFileStr         : " + logFileStr);

	int minConns = 0;
	int maxConns = 0;
	double maxConnTime = 0;
	int maxCheckoutSeconds = 0;
	boolean logAppend = false;
	
	
	try {
	    minConns = Integer.parseInt(minConnsStr);
	} catch (NumberFormatException e) {
	    throw new IllegalArgumentException(
		    Tag.AWAKE_USER_CONFIG_FAIL
		    	    + "Invalid <Resource> parameter for Resource: " + name + ". " +
			    "Parameter minConns is not numeric: "
			    + minConnsStr);
	}

	try {
	    maxConns = Integer.parseInt(maxConnsStr);
	} catch (NumberFormatException e) {
	    throw new IllegalArgumentException(
		    Tag.AWAKE_USER_CONFIG_FAIL
	    	    + "Invalid <Resource> parameter for Resource: " + name + ". " +
			    "Parameter maxConns is not numeric: "
			    + maxConnsStr);
	}

	if (maxConnTimeStr == null || maxConnTimeStr.isEmpty()) {
	    maxConnTime = -1;
	} else {
	    try {
		maxConnTime = Double.parseDouble(maxConnTimeStr);
	    } catch (NumberFormatException e) {
		throw new IllegalArgumentException(
			Tag.AWAKE_USER_CONFIG_FAIL
		    	    + "Invalid <Resource> parameter for Resource: " + name + ". " +
				"Parameter maxConnTimeStr is not numeric: "
				+ maxConnTimeStr);
	    }
	}
		
	if (maxCheckoutSecondsStr == null || maxCheckoutSecondsStr.isEmpty()) {
	    maxCheckoutSeconds = -1;
	} else {
	    try {
		maxCheckoutSeconds = Integer.parseInt(maxCheckoutSecondsStr);
	    } catch (NumberFormatException e) {
		throw new IllegalArgumentException(
			Tag.AWAKE_USER_CONFIG_FAIL
		    	    + "Invalid <Resource> parameter for Resource: " + name + ". " +
				"Parameter maxCheckoutSecondsStr is not numeric: "
				+ maxCheckoutSecondsStr);
	    }
	}
	
	if (logAppendStr == null || logAppendStr.isEmpty()) {
	    logAppend = false;
	} else {
	    try {
		logAppend = Boolean.parseBoolean(logAppendStr);
	    } catch (NumberFormatException e) {
		throw new IllegalArgumentException(
			Tag.AWAKE_USER_CONFIG_FAIL
		    	    + "Invalid <Resource> parameter for Resource: " + name + ". " +
				"Parameter maxCheckoutSecondsStr is not numeric: "
				+ maxCheckoutSecondsStr);
	    }
	}
	
	
	// This is an AwakeDataSource!
	AwakeDataSource awakeDataSource = new AwakeDataSource();
	awakeDataSource.setDriverClassName(driverClassName);
	awakeDataSource.setUrl(url);
	awakeDataSource.setUsername(username);
	awakeDataSource.setPassword(password);
	awakeDataSource.setMinConns(minConns);
	awakeDataSource.setMaxConns(maxConns);
	
	// Non mandatory value
	if (maxConnTime != -1) {
	    awakeDataSource.setMaxConnTime(maxConnTime);
	}
	
	// Non mandatory value
	if (maxCheckoutSeconds != -1) {
	    awakeDataSource.setMaxCheckoutSeconds(maxCheckoutSeconds);
	}	
	
	// Non mandatory value, but no need to make a test
	awakeDataSource.setLogAppend(logAppend);

	if (logFileStr != null && !logFileStr.isEmpty()) {
	    awakeDataSource.setLogFile(new File(logFileStr));
	}

	// Return the configured AwakeDataSource instance!
	return awakeDataSource;
    }

    /**
     * debug tool
     */
    private void debug(String s) {
	if (DEBUG) {
	    //AwakeServerLogger.log(s);
	    System.out.println(new Date() + " " + AwakeDataSourceFactory.class.getSimpleName() + " " + s);
	}
    }

}
