/*
 * Awake File: Easy file upload & download through HTTP with Java
 * Awake SQL: Remote JDBC access through HTTP.                                    
 * Copyright (C) 2012, Kawan Softwares S.A.S.
 * (http://www.awakeframework.org). All rights reserved.                                
 *                                                                               
 * Awake File/SQL is free software; you can redistribute it and/or                 
 * modify it under the terms of the GNU Lesser General Public                    
 * License as published by the Free Software Foundation; either                  
 * version 2.1 of the License, or (at your option) any later version.            
 *                                                                               
 * Awake File/SQL is distributed in the hope that it will be useful,               
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU             
 * Lesser General Public License for more details.                               
 *                                                                               
 * You should have received a copy of the GNU Lesser General Public              
 * License along with this library; if not, write to the Free Software           
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 * 02110-1301  USA
 *
 * Any modifications to this file must keep this entire header
 * intact.
 */
 
package org.awakefw.commons.api.client;

import java.io.IOException;


/**
 * Signals that the Awake Server refused the (username, password) login or that
 * the user is not any more logged.
 * 
 * @author Nicolas de Pomereu
 * @since 1.0
 */
public class InvalidLoginException extends IOException {

    private static final long serialVersionUID = 4694166724488975743L;

    /**
     * Constructs an {@code InvalidLoginException} with {@code null} as its
     * error detail message.
     */
    public InvalidLoginException() {
	super();
    }

    /**
     * Constructs an {@code InvalidLoginException} with the specified detail message.
     *
     * @param message
     *        The detail message (which is saved for later retrieval
     *        by the {@link #getMessage()} method)
     */
    public InvalidLoginException(String message) {
	super(message);
	
    }

    
    

}
